﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using static System.Console;
using System.IO;

namespace oop
{
    class level7
    {
        public level7(string filename, string matcher)
        {
            StreamReader reader = new StreamReader(filename);
            string lines;
            //Created a string, which is a matcher to replace '*'
            //to a any A-Z letters
            string stars = matcher.Replace("*", "[A-Z]*");
            while ((lines = reader.ReadLine()) != null)
            {
                //Using the match function and regex, it allows you to 
                //Replace any * with a letter A-Z.
                Match match = Regex.Match(lines, stars);
                if (match.Success)
                {
                    WriteLine(match.Value);
                }
            }

        }
    }
}
