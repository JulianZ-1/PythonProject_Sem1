﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using static System.Console;

namespace oop
{
    class level5
    {
        public level5(string filename, string sequences)
        {
            StreamReader reader = new StreamReader(filename);
            //A string which contains lines from the file
            string lines;
            //a counter
            int counter = 0;
            bool found = false;
            while ((lines = reader.ReadLine()) != null)
            {
                counter++;
                //If the find the user input, write it on to the console
                if (lines.Contains(sequences))
                {   //Counter -1, because you want to get the ID,
                    //which is one line above the sequence
                    counter--;
                    found = true;
                    //Calling Level class and use the level 1 function.
                    Level level5 = new Level(filename, counter, counter);

                }
            }
            //closing the file
            reader.Close();
            //If the program couldnt find the  sequence, 
            //An error message will print out.
            if (found == false)
            {
                WriteLine("Please check the sequence that you entered");
            }
        }
    }
}
