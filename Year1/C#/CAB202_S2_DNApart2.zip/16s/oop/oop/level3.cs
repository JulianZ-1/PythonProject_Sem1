﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace oop
{   //Class only for level three (Need change in the future)
    class Level3
    {
        public Level3(string filename, string infile, string outfile)
        {   //Checking Error.
            if (File.Exists(filename))
            {
                if (File.Exists(infile))
                {   //Creating lists for adding the query file as well as a list to write out to
                    // the answer file.
                    List<string> query = new List<string>();
                    List<string> answer = new List<string>();
                    FileStream querryFile = new FileStream(infile, FileMode.Open, FileAccess.Read);
                    StreamReader reader = new StreamReader(querryFile);
                    FileStream resultFile = new FileStream(outfile, FileMode.Create, FileAccess.Write);
                    StreamWriter writer = new StreamWriter(resultFile);
                    //Creating two lines, one for query file and one for the fasta file.
                    string line;
                    string Line;
                    //Two Boolens, same as the one at class LEVEL
                    bool Finded = false;
                    bool unfinded;
                    //Adding whats in the querry file in to the list
                    while ((line = reader.ReadLine()) != null)
                    {
                        query.Add(line);
                    }
                    //Compareing the querry list to the fasta file.
                    for (int i = 0; i < query.Count(); i++)
                    {
                        unfinded = true;
                        StreamReader file = new StreamReader(filename);
                        while ((Line = file.ReadLine()) != null)
                        {
                            if (Finded)
                            {
                                answer.Add(Line);
                                Finded = false;
                                unfinded = false;
                            }
                            if (Line.Contains(query[i]))
                            {
                                answer.Add(Line);
                                Finded = true;
                            }
                        }
                        if (unfinded)
                        {
                            Console.WriteLine("{0} is not in the file", query[i]);
                        }

                    }
                    //Message when the serach has complete.
                    Console.WriteLine("Finished! please check the" +
                        " text file in the Debug folder");
                    answer.ForEach(writer.WriteLine);
                    reader.Close();
                    querryFile.Close();
                }
                else
                //Error when can not find the querry file.
                {
                    Console.WriteLine("Can not find" +
                        " the query file");
                }
            }
            else
            {   //Error when can not find the file.
                Console.WriteLine("The file name you entered " +
                    "can not be find");
            }
        }
    }
}
