﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.IO;

namespace oop
{
    class Level
    {   //This public level will be used for the first level
        public Level(string filename, int start, int end)
        {
            if (File.Exists(filename))
            {
                Readfiles read = new Readfiles();
                read.filereader(filename);
                //Error checking.

                using (FileStream fs = new FileStream(filename,
                    FileMode.Open, FileAccess.Read))
                {

                    for (int n = start - 1; n < end; n++)
                    {
                        byte[] bytes = new byte[read.Size[n]];
                        fs.Seek(read.Pos[n], SeekOrigin.Begin);
                        fs.Read(bytes, 0, read.Size[n]);
                        WriteLine(Encoding.Default.GetString(bytes));
                    }
                    fs.Close();

                }

            }
            else
            {   //Error echking for did not find the file.
                WriteLine("The file name you entered " +
                    "can not be find");
            }



        }
        //This Level is used for level 2
        public Level(string filename, string key)
        {   //Error checking.
            if (File.Exists(filename))
            {
                string Line;
                //two boolen once found it and one is did not find.
                bool finded = false;
                bool unfinded = true;
                StreamReader file = new StreamReader(filename);
                while ((Line = file.ReadLine()) != null)
                {
                    if (finded)
                    {   //Once found it, it will write the next line and end.
                        WriteLine(Line);
                        finded = false;
                        unfinded = false;
                    }
                    //If the find the user input, write it on to the console
                    if (Line.Contains(key))
                    {
                        WriteLine(Line);
                        finded = true;
                    }

                }
                //If did not find it, desplay this error message.
                if (unfinded)
                {
                    WriteLine("{0} is not in the file", key);
                }

                file.Close();

            }
            else //Error for not find the file.
            {
                WriteLine("The file name you entered " +
                    "can not be find");
            }


        }
        //This Level is used for level 4
        public Level(string filename, string indexfile, string queryfile, string result)
        {
            //Creating lists
            List<int> pos = new List<int>();
            List<string> query = new List<string>();
            List<int> h = new List<int>();
            //naming all the Stream functions
            FileStream querryFile = new FileStream(queryfile, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(querryFile);
            FileStream file = new FileStream(filename, FileMode.Open, FileAccess.Read);
            FileStream resultFile = new FileStream(result, FileMode.Create, FileAccess.Write);
            StreamWriter writer = new StreamWriter(resultFile);
            //calling the Reafiles class, where it will read the file.
            Readfiles read = new Readfiles();
            read.filereader(filename);
            //creating lines for each file to read
            string line;
            string Line;
            //Creating a boolen to check whats in the query file
            bool find = false;
            //creating counter to find out where the index is located
            int counter = 0;
            //reading the query file, and put it in to a list
            while ((line = reader.ReadLine()) != null)
            {
                query.Add(line);
            }
            //going though the quer file, and find out where it at, as well as getting the offset
            //from the index file to put it in to a new list.
            for (int i = 0; i < query.Count(); i++)
            {
                StreamReader indexf = new StreamReader(indexfile);
                while ((Line = indexf.ReadLine()) != null)
                {
                    counter++;
                    if (Line.Contains(query[i]))
                    {
                        pos.Add(Convert.ToInt32(Line.Split()[4]));
                        h.Add(counter);
                        find = true;
                    }
                }
                if (!find)
                {
                    WriteLine("{0} can not be find in the fasta file", query[i]);
                }

                //reset the counter, because this time is going though the next line in the query file.
                //reset the bool for the next line in the query file.
                counter = 0;
                find = false;
            }
            for (int j = 0; j < pos.Count(); j++)
            {
                //Since one line = two lines in the 16s file, by times by 2 and -1 will get the starting position
                //and -1 will get the end postion
                for (int n = h[j] * 2 - 1; n < h[j] * 2; n++)
                {
                    //creating a size for the bytes to hold
                    byte[] bytes = new byte[read.Size[n]];
                    file.Seek(pos[j], SeekOrigin.Begin);
                    file.Read(bytes, 0, read.Size[n]);
                    //writing it down by calling writer.
                    writer.WriteLine(Encoding.Default.GetString(bytes));
                }
            }
            WriteLine("Done! please check the Debug folder");

        }
    }
}
