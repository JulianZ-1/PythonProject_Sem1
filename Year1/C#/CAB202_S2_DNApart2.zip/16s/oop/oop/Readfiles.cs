﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.IO;

namespace oop
{
    class Readfiles
    {
        //Get set the lists, because it will be used out side of the class.
        
        private List<int> pos = new List<int>(); //A list fo keep positions
        public List<int> Pos
        {
            get { return pos; }
            set { pos = value; }
        }
        private List<int> size = new List<int>();   //A list to keep size in
        public List<int> Size
        {
            get { return size; }
            set { size = value; }
        }
        public int counter; //Line counter in the text file, public so everyone can access
        private string line; //Line of text
        public string Line
        {
            get { return line; }
            set { line = value; }
        }
        private int position { get; set; } //Position of the first line
        public void filereader (string fname)
        {
            //Keep reading the fill until reach the end.
            StreamReader file = new StreamReader(fname);
            
            while((Line = file.ReadLine()) != null)
            {  
                pos.Insert(counter, position);
                size.Insert(counter, Line.Length);
                counter++;
                position = position + Line.Length + 1;
            }
            file.Close();
        }
    }
}
