﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.IO;

namespace oop
{
    class level6
    {
        public level6(string filename, string sequences)
        {
            StreamReader reader = new StreamReader(filename);
            //A string to save each line from the given file
            string lines;
            int counter = 0;
            bool found = false;
            while ((lines = reader.ReadLine()) != null)
            {
                counter++;
                //If the find the user input, write it on to the console
                if (lines.Contains(sequences))
                {
                    found = true;
                    //Calling the Level class and use the level 1 commands
                    Level level5 = new Level(filename, counter, counter);

                }
            }
            reader.Close();
            if (found == false)
            {
                //Error message if the sequences can not be find in the file.
                WriteLine("Please check the sequence that you enter");
            }
        }
    }
}
