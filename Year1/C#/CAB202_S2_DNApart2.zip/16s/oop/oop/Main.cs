﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.IO;

namespace oop
{
    class Program
    {
        static void Main(string[] args)

        {   //Check user in puts.
            try
            {
                if (args[0] == "Search16s")
                {   //Checking which level did user selected
                    switch (args[1])
                    {
                        case "-level1":
                            int begin;
                            int finish;
                            //Error checking.
                            if (int.TryParse(args[3], out begin))
                            {
                                if (int.TryParse(args[4], out finish))
                                {
                                    Readfiles read = new Readfiles();
                                    read.filereader(args[2]);
                                    if (begin % 2 == 0)
                                    {
                                        Console.WriteLine("Please enter a odd number.");
                                    }
                                    else if (begin > read.counter || begin + finish > read.counter)
                                    {
                                        Console.WriteLine("There is only {0} lines in the file.", read.counter);
                                    }
                                    else
                                    {
                                        //Call the LEVEL class and.
                                        //To get which line is the 'end' at
                                        finish = (begin + finish * 2) - 1;
                                        Level level = new Level(args[2], begin, finish);
                                    }
                                }
                                else
                                {
                                    WriteLine("Please enter how many lines you want to see" +
                                        " (number)");
                                }

                            }
                            else
                            {
                                WriteLine("Please enter where you want to start(number)");
                            }


                            break;

                        case "-level2":
                            //Calling the level class.
                            Level level2 = new Level(args[2], args[3]);

                            break;

                        case "-level3":

                            //Calling the level 3 class.
                            Level3 level3 = new Level3(args[2], args[3], args[4]);

                            break;

                        case "-level4":
                            //Calling the level 4 class.
                            Level level4 = new Level(args[2], args[3], args[4], args[5]);

                            break;
                        case "-level5":
                            //Calling the level 5 class.
                            level5 level5 = new level5(args[2], args[3]);

                            break;
                        case "-level6":
                            //Calling the level 6 class.
                            level6 level6 = new level6(args[2], args[3]);

                            break;

                        case "-level7":
                            //Calling the level 7 class.
                            level7 level7 = new level7(args[2], args[3]);

                            break;
                        default:

                            Console.WriteLine("Please enter a level," +
                                "the level is start from 1 to 8");
                            break;
                    }
                }
                else
                {   //Checking user inputs.
                    Console.WriteLine("The only featuers that are builded in" +
                        "is 'Search16s'");
                }
            }
            catch (IndexOutOfRangeException)
            {   //Error for the format of the arguments
                WriteLine("Please enter the full arguments" +
                    " level 1 and 3 requires 3 arguments," +
                    " level 2, 5, 6 and 7 require 3 arguments," +
                    " and level 4 require 4 arguments");
            }
            catch (FileNotFoundException)
            {
                WriteLine("Sorry, the program can not find your file" +
                    " please check spelling as well as" +
                    " the locaiton of the file.");
            }
            ReadLine();
        }

    }
}