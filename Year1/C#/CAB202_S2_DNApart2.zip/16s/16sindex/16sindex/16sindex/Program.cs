﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.IO;

namespace _16sindex
{
    class Program
    {
        static void Main(string[] args)
        {   //Start by checking errors
            try
            {
                if (!args[2].Contains(".index"))
                {
                    WriteLine("Please put a '.index' at the end of the" +
                        " file you want to create");
                }
                else
                {
                    //Calling the list from the other class
                    elements list = new elements();
                    List<string> calledList = elements.list();
                    List<int> poslist = elements.numlist();
                    //A string to hold all the elements from the given file
                    string Indexlines;
                    //A counter
                    int oddNum = 0;
                    //A int to hold the offset bytes position for each line.
                    int position = 0;
                    //Reading given file from the user input
                    StreamReader fastafilename = new StreamReader(args[1]);
                    FileStream indexfile = new FileStream(args[2], FileMode.Create,
                        FileAccess.Write);
                    StreamWriter writeindex = new StreamWriter(indexfile);
                    while ((Indexlines = fastafilename.ReadLine()) != null)
                    {
                        //The counter goes up after reading each line.
                        //If the counter is a odd number, store that line to a list
                        //As well as the position of that line.
                        oddNum++;
                        if (oddNum % 2 == 1)
                        {

                            calledList.Add(Indexlines.Split(' ')[0]);
                            poslist.Add(position);

                        }
                        position = position + Indexlines.Length + 1;
                    }
                    //Putting two list in to one list by using the zip function.
                    //Print them out on to a file that user has put in.
                    foreach (var e in calledList.Zip(poslist, (t, w) => new { t, w }))
                    {
                        writeindex.WriteLine(e.t + "    " + e.w);
                    }
                    //Message to tell the user the program is finished.
                    WriteLine("Done! please check the Debug folder," +
                        " if you would like to use the file" +
                        ", please put it in to the " +
                        "oop's folder's Debug folder");
                    ReadLine();
                }

            }
            //Catching erros and print the error message to tell the user.
            catch (IndexOutOfRangeException)
            {
                WriteLine("Please enter the full arguments as" +
                    "'IndexSequence16s' + name of the fast file +" +
                    " name the index file you want to create");
            }
            catch (FileNotFoundException)
            {
                WriteLine("The program can not find you fasta file, " +
                    "please put it in the right folder!");
            }

            


        }
    }
}
