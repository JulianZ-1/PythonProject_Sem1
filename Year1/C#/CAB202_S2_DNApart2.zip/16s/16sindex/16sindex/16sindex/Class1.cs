﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16sindex
{
    //This is a class which contains all the privite lists.
    class elements
    {
        private static List<string> indexs = new List<string>();
        public static List<string> list()
        {
            return indexs;
        }
        private static List<int> indexsat = new List<int>();
        public static List<int> numlist()
        {
            return indexsat;
        }
    }
}
