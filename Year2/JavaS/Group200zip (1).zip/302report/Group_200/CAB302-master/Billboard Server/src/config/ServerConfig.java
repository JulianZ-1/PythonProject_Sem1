package config;

public class ServerConfig extends Config {

    private String address;
    private int port;

    public ServerConfig() throws ConfigException {

        super("./Server.props", "address = \nport = ");

        this.parse();
    }


    @Override
    protected void parse() throws ConfigException {

        super.parse();

        address = super.properties.getProperty("address");
        port = Integer.parseInt(super.properties.getProperty("port").equals("") ? "-1" : super.properties.getProperty("port"));

        verify();
    }


    @Override
    protected void verify() throws ConfigException {
        System.out.println("Address: " + address);
        System.out.println("Port: " + port);

        super.verifyAddress(address);
        super.verifyPort(port);
    }


    public String getAddress() {
        return this.address;
    }

    public int getPort() {
        return this.port;
    }
}
