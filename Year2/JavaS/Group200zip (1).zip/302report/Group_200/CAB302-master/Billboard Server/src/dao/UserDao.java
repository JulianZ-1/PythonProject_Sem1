package dao;
import model.User;
import utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;

/**
 * Class for retrieving data from the user table.
 */
public class UserDao {

    public static final String CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS UserTable ("
                    + "idx INTEGER PRIMARY KEY /*!40101 AUTO_INCREMENT */ NOT NULL UNIQUE," // from https://stackoverflow.com/a/41028314
                    + "name VARCHAR(30) NOT NULL UNIQUE,"
                    + "password VARCHAR(100),"
                    + "salt VARCHAR(50),"
                    + "createBillboard BOOLEAN,"
                    + "editAllBillboard BOOLEAN,"
                    + "editUsers BOOLEAN,"
                    + "scheduleBillboard BOOLEAN" + ");";

    private static final String SET_USERS = "REPLACE INTO UserTable (name, password, salt, createBillboard, editAllBillboard, editUsers,scheduleBillboard) VALUES ('Admin', '99d7684045d6165760396cbbe7027311f3117bf52bbd7b052a67edb6e74c1f14', '0b3e09a826b02032c6f1598fcadcc8da','1', '1', '1','1');";

    private static final String INSERT_USER = "INSERT IGNORE INTO UserTable (name, password, salt, createBillboard, editAllBillboard, editUsers,scheduleBillboard) VALUES (?, ?, ?, ?, ?, ?, ?);";

    private static final String GET_NAMES = "SELECT name FROM UserTable";

    private static final String GET_PASSWORD = "SELECT password FROM UserTable WHERE name=?";

    private static final String SET_PASSWORD = "UPDATE UserTable SET password=? WHERE name=?";

    private static final String GET_SALT = "SELECT salt FROM UserTable WHERE name=?";

    private static final String GET_USER = "SELECT * FROM UserTable WHERE name=?";

    private static final String DELETE_USER = "DELETE FROM UserTable WHERE name=?";

    private static final String COUNT_ROWS = "SELECT COUNT(*) FROM UserTable";

    private static final String GET_CREATE_BOARD_PERMISSION = "SELECT createBillboard FROM UserTable WHERE name=?";

    private static final String SET_CREATE_BOARD_PERMISSION = "UPDATE UserTable SET createBillboard=? WHERE name=?";

    private static final String GET_EDIT_BOARD_PERMISSION = "SELECT editAllBillboard FROM UserTable WHERE name=?";

    private static final String SET_EDIT_BOARD_PERMISSION  = "UPDATE UserTable SET editAllBillboard=? WHERE name=?";

    private static final String GET_EDIT_USERS_PERMISSION = "SELECT editUsers FROM UserTable WHERE name=?";

    private static final String SET_EDIT_USERS_PERMISSION  = "UPDATE UserTable SET editUsers=? WHERE name=?";

    private static final String GET_SCHEDULE_BOARD_PERMISSION = "SELECT scheduleBillboard FROM UserTable WHERE name=?";

    private static final String SET_SCHEDULE_BOARD_PERMISSION  = "UPDATE UserTable SET scheduleBillboard=? WHERE name=?";





    private Connection connection;

    private PreparedStatement addUser;

    private PreparedStatement getPassword;

    private PreparedStatement setPassword;

    private PreparedStatement getSalt;

    private PreparedStatement getNameList;

    private PreparedStatement getUser;

    private PreparedStatement deleteUser;

    private PreparedStatement rowCount;

    private PreparedStatement getCreateBillboardPermission;

    private PreparedStatement setCreateBillboardPermission;

    private PreparedStatement getEditAllBillboardPermission;

    private PreparedStatement setEditAllBillboardPermission;

    private PreparedStatement getEditUsersPermission;

    private PreparedStatement setEditUsersPermission;

    private PreparedStatement getScheduleBillboardPermission;

    private PreparedStatement setScheduleBillboardPermission;

    public UserDao() {
        connection = DBConnection.getInstance();
        try {
            Statement st = connection.createStatement();
            st.execute(CREATE_TABLE);

            addUser = connection.prepareStatement(INSERT_USER);
            getPassword = connection.prepareStatement(GET_PASSWORD);
            setPassword = connection.prepareStatement(SET_PASSWORD);
            getSalt = connection.prepareStatement(GET_SALT);
            getNameList = connection.prepareStatement(GET_NAMES);
            getUser = connection.prepareStatement(GET_USER);
            deleteUser = connection.prepareStatement(DELETE_USER);
            rowCount = connection.prepareStatement(COUNT_ROWS);
            getCreateBillboardPermission = connection.prepareStatement(GET_CREATE_BOARD_PERMISSION);
            setCreateBillboardPermission = connection.prepareStatement(SET_CREATE_BOARD_PERMISSION);
            getEditAllBillboardPermission = connection.prepareStatement(GET_EDIT_BOARD_PERMISSION);
            setEditAllBillboardPermission = connection.prepareStatement(SET_EDIT_BOARD_PERMISSION);
            getEditUsersPermission = connection.prepareStatement(GET_EDIT_USERS_PERMISSION);
            setEditUsersPermission = connection.prepareStatement(SET_EDIT_USERS_PERMISSION);
            getScheduleBillboardPermission = connection.prepareStatement(GET_SCHEDULE_BOARD_PERMISSION);
            setScheduleBillboardPermission = connection.prepareStatement(SET_SCHEDULE_BOARD_PERMISSION);

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     *
     * Add default user(Admin,password1)
     */
    public void addDefault() throws SQLException {

        Statement st = connection.createStatement();
        st.execute(SET_USERS);
    }

    /**
     * Use a username to get its password.
     * @param userName
     * @return
     */
    public String getPassword(String userName) throws SQLException {
        ResultSet rs = null;
        try {
            getPassword.setString(1,userName);
            rs = getPassword.executeQuery();
            rs.next();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs.getString("password");
    }

    /**
     * Get a username and new password to set a new password.
     * @param userName
     * @param password
     */
    public void setPassword(String userName, String password){
        ResultSet rs = null;
        try {
            setPassword.setString(1,password);
            setPassword.setString(2,userName);
            setPassword.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Use a user's name to get its stored salt
     * @param userName
     * @return
     */
    public String getSalt(String userName) throws SQLException {
        ResultSet rs = null;
        try {
            getSalt.setString(1,userName);
            rs = getSalt.executeQuery();
            rs.next();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs.getString("salt");
    }

    /**
     * Given a username check if it exists in table.
     * @param name
     * @return
     */
    public Boolean checkIfExist(String name) throws SQLException {
        ResultSet rs = null;
        try {
            getUser.setString(1,name);
            rs = getUser.executeQuery();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs.next();
    }


    /**
     * Add a user into table.
     * @param u
     */
    public void addUser(User u) {
        try {

            addUser.setString(1, u.getName());
            addUser.setString(2, u.getPassword());
            addUser.setString(3, u.getSalt());
            addUser.setString(4, u.getCreateBillboard());
            addUser.setString(5, u.getEditAllBillboard());
            addUser.setString(6, u.getEditUsers());
            addUser.setString(7, u.getScheduleBillboard());
            addUser.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Use a username to check 'Create Billboard' permission.
     * @param userName
     * @return
     */
    public String getCreateBoardPermission(String userName) throws SQLException {
        ResultSet rs = null;
        try {
            getCreateBillboardPermission.setString(1,userName);
            rs = getCreateBillboardPermission.executeQuery();
            rs.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs.getString("createBillboard");
    }

    /**
     * Set a user's permission, given username and new value of this permission.
     * @param userName
     * @param permission
     */
    public void setCreateBoardPermission(String userName, String permission) {
        ResultSet rs = null;
        try {
            setCreateBillboardPermission.setString(1,permission);
            setCreateBillboardPermission.setString(2,userName);
            setCreateBillboardPermission.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    /**
     * Use a username to check 'Edit All Billboard' permission.
     * @param userName
     * @return
     */
    public String getEditAllBillboardPermission(String userName) throws SQLException {
        ResultSet rs = null;
        try {
            getEditAllBillboardPermission.setString(1,userName);
            rs = getEditAllBillboardPermission.executeQuery();
            rs.next();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs.getString("editAllBillboard");
    }
    /**
     * Set a user's permission, given username and new value of this permission.
     * @param userName
     * @param permission
     */
    public void setEditAllBillboardPermission(String userName, String permission) {
        ResultSet rs = null;
        try {
            setEditAllBillboardPermission.setString(1,permission);
            setEditAllBillboardPermission.setString(2,userName);
            setEditAllBillboardPermission.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    /**
     * Use a username to check 'Edit Users' permission.
     * @param userName
     * @return
     */
    public String getEditUsersPermission(String userName) throws SQLException {
        ResultSet rs = null;
        try {
            getEditUsersPermission.setString(1,userName);
            rs = getEditUsersPermission.executeQuery();
            rs.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs.getString("editUsers");
    }
    /**
     * Set a user's permission, given username and new value of this permission.
     * @param userName
     * @param permission
     */
    public void setEditUsersPermission(String userName, String permission) {
        ResultSet rs = null;
        try {
            setEditUsersPermission.setString(1,permission);
            setEditUsersPermission.setString(2,userName);
            setEditUsersPermission.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    /**
     * Use a username to check 'Schedule Billboard' permission.
     * @param userName
     * @return
     */
    public String getScheduleBillboardPermission(String userName) throws SQLException {
        ResultSet rs = null;
        try {
            getScheduleBillboardPermission.setString(1,userName);
            rs = getScheduleBillboardPermission.executeQuery();
            rs.next();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs.getString("scheduleBillboard");
    }
    /**
     * Set a user's permission, given username and new value of this permission.
     * @param userName
     * @param permission
     */
    public void setScheduleBillboardPermission(String userName, String permission) {
        ResultSet rs = null;
        try {
            setScheduleBillboardPermission.setString(1,permission);
            setScheduleBillboardPermission.setString(2,userName);
            setScheduleBillboardPermission.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     *
     * @return a list of users' names stored
     */
    public ArrayList<String> nameSet() {
        ArrayList<String> names = new ArrayList<String>();
        ResultSet rs = null;
        try {
            rs = getNameList.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("name"));

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return names;
    }

    /**
     * Get user model by user's name.
     * @param name
     * @return
     */
    public User getUser(String name) {
        User u = new User();
        ResultSet rs = null;
        try {
            getUser.setString(1, name);
            rs = getUser.executeQuery();
            rs.next();
            u.setName(rs.getString("name"));
            u.setPassword(rs.getString("password"));
            u.setCreateBillboard(rs.getString("createBillboard"));
            u.setEditAllBillboard(rs.getString("editAllBillboard"));
            u.setEditUsers(rs.getString("editUsers"));
            u.setScheduleBillboard(rs.getString("scheduleBillboard"));
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return u;
    }

    /**
     * Delete a user by user's name.
     * @param name
     */
    public void deleteUser(String name) {

        try {
            deleteUser.setString(1, name);
            deleteUser.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }

    /**
     * Close DB connection.
     */
    public void close() {

        try {
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }
}
