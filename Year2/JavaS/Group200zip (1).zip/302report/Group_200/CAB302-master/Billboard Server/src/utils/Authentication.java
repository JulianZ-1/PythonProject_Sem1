package utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

/**
 * Methods for hash a password, make salt, and salt the password.
 */
public class Authentication {
    /**
     *
     * @param hashedPassword in byte
     * @return a string from byte
     */
    public String byteToString(byte[] hashedPassword){
        StringBuffer sb = new StringBuffer();
        for (byte b : hashedPassword) {
            sb.append(String.format("%02x", b & 0xFF));
        }
        return sb.toString();
    }

    /**
     *
     * @param input
     * @return 'SHA-256' bytes from a string
     */
    public byte[] stringToByte(String input) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashedInput = md.digest(input.getBytes());
        return hashedInput;
    }

    /**
     *
     * @param password
     * @return  Hash a password.
     */
    public String hashPassword(String password) throws NoSuchAlgorithmException {
        return byteToString(stringToByte(password));
    }

    /**
     *
     * @return make a salt string
     */
    public String makeSalt(){
        Random rng = new Random();
        byte[] saltBytes = new byte[16];
        rng.nextBytes(saltBytes);
        String saltString = byteToString(saltBytes);
        return saltString;
    }

    /**
     *
     * @param hashedPassword
     * @param saltString
     * @return salt a hashed password by two params
     */
    public String saltPassword(String hashedPassword, String saltString) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        String saltedPassword = byteToString(md.digest((hashedPassword +saltString).getBytes()));
        return saltedPassword;
    }

}
