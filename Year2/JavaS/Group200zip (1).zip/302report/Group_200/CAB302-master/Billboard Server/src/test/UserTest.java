package test;

import model.User;


import java.util.ArrayList;
import java.util.List;


public class UserTest {

    List<User> list = new ArrayList<>();

    @Before
    public void addDefault() {
        User user = new User();
        user.setName("jock");
        user.setPassword("jock");
        user.setCreateBillboard("createBillboard");
        user.setEditAllBillboard("editAllBillboard");
        user.setEditUsers("editUsers");
        user.setScheduleBillboard("scheduleBillboard");
        list.add(user);
    }

    @Test
    public void getPassword() {
        String password = null;
        for (User user : list) {
            if (user.getName().equals("jock")) {
                password = user.getPassword();
            }
        }
        System.out.println(password);
    }

    @Test
    public void addUser() {
        User user = new User();
        user.setName("jock1");
        user.setPassword("jock1");
        list.add(user);
    }


    @Test
    public void getCreateBoardPermission() {
        String createBoardPermission = null;
        for (User user : list) {
            if (user.getName().equals("jock")) {
                createBoardPermission = user.getCreateBillboard();
            }
        }
        System.out.println(createBoardPermission);
    }

    @Test
    public void getEditAllBillboardPermission() {
        String editAllBillboard = null;
        for (User user : list) {
            if (user.getName().equals("jock")) {
                editAllBillboard = user.getEditAllBillboard();
            }
        }
        System.out.println(editAllBillboard);
    }


    @Test
    public void getEditUsersPermission() {
        String editUsersPermission = null;
        for (User user : list) {
            if (user.getName().equals("jock")) {
                editUsersPermission = user.getEditUsers();
            }
        }
        System.out.println(editUsersPermission);
    }

    @Test
    public void getScheduleBillboardPermission() {
        String scheduleBillboardPermission = null;
        for (User user : list) {
            if (user.getName().equals("jock")) {
                scheduleBillboardPermission = user.getScheduleBillboard();
            }
        }
        System.out.println(scheduleBillboardPermission);
    }

    @Test
    public void getUser() {
        for (User user : list) {
            if (user.getName().equals("jock")) {
                System.out.println(user);
            }
        }
    }

    @Test
    public void deleteUser() {
        for (User user : list) {
            if (user.getName().equals("jock")) {
                list.remove(user);
            }
        }
    }


    @Test
    public void test() {
        User user = new User("name", "password", "salt", "createBillboard",
                "editAllBillboard", "editUsers", "scheduleBillboard");
        assertEquals("name", user.getName());
        assertEquals("password", user.getPassword());
        assertEquals("createBillboard", user.getCreateBillboard());
        assertEquals("editAllBillboard", user.getEditAllBillboard());
        assertEquals("editUsers", user.getEditUsers());
        assertEquals("scheduleBillboard", user.getName());

    }

    @Test
    public void test1() {
        User user = new User();
        user.setName("name");
        user.setPassword("password");
        user.setCreateBillboard("createBillboard");
        assertEquals("name", user.getName());
        assertEquals("password", user.getPassword());
        assertEquals("createBillboard", user.getCreateBillboard());

    }

    @Test
    public void test2() {
        User user = new User();
        user.setEditAllBillboard("editAllBillboard");
        user.setEditUsers("editUsers");
        user.setScheduleBillboard("scheduleBillboard");
        assertEquals("editAllBillboard", user.getEditAllBillboard());
        assertEquals("editUsers", user.getEditUsers());
        assertEquals("scheduleBillboard", user.getName());

    }


}
