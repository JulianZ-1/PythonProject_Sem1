//package model;
//
//
//public class Schedule {
//
//
//
//   private String billboard;
//
//   private String start_at;
//
//   private String end_at;
//
//   private Boolean scheduled;
//
//
//
//   /**
//    * No args constructor.
//    */
//   public Schedule() {
//   }
//
//
//   public Schedule(String billboard, String start_at, String end_at, Boolean scheduled) {
//      this.billboard = billboard;
//      this.start_at= start_at;
//      this.end_at = end_at;
//      this.scheduled= scheduled;
//
//   }
//
//
//
//   public String getStart_at() {
//      return start_at;
//   }
//
//   public void setStart_at(String start_at) {
//      this.start_at = start_at;
//   }
//
//   public String getEnd_at() {
//      return end_at;
//   }
//
//   public void setEnd_at(String end_at) {
//      this.end_at = end_at;
//   }
//
//   public Boolean getScheduled() {
//      return scheduled;
//   }
//
//   public void setScheduled(Boolean scheduled) {
//      this.scheduled = scheduled;
//   }
//
//   public String getBillboard() {
//      return billboard;
//   }
//
//   public void setBillboard(String billboard) {
//      this.billboard = billboard;
//   }
//
//
//   /**
//    * Compares this object with the specified object for order. Returns a
//    * negative integer, zero, or a positive integer as this object is less than,
//    * equal to, or greater than the specified object.
//    *
//    * @param other The other Person object to compare against.
//    * @return a negative integer, zero, or a positive integer as this object is
//    *         less than, equal to, or greater than the specified object.
//    * @throws ClassCastException if the specified object's type prevents it from
//    *            being compared to this object.
//    */
////   public int compareTo(Person other) {
////      return this.name.compareTo(other.name);
////   }
//
//   /**
//    * @see Object#toString()
//    */
//
//
//}
