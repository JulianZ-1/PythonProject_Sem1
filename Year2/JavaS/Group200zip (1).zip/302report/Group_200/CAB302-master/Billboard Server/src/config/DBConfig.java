package config;

public class DBConfig extends Config{

    private String url, username, password, schema;

    public DBConfig() throws ConfigException {

        super("./db.props", "jdbc.url = \njdbc.schema = \njdbc.username = \njdbc.password = ");

        this.parse();
    }

    @Override
    protected void parse() throws ConfigException {

        super.parse();

        url = super.properties.getProperty("jdbc.url");
        username = super.properties.getProperty("jdbc.username");
        password = super.properties.getProperty("jdbc.password");
        schema = super.properties.getProperty("jdbc.schema");

        verify();
    }

    @Override
    protected void verify() throws ConfigException {
        System.out.println("url: " + url);
        System.out.println("schema: " + schema);
        System.out.println("username: " + username);
        System.out.println("password: " + password);
    }


    public String getUrl() {
        return url;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getSchema() {
        return schema;
    }
}
