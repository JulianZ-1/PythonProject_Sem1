package network;

import java.io.Serializable;

public class Response implements Serializable {

    private boolean status;
    private String message;
    private Object data;


    /**
     * Construct a default message Response without data
     * @param _status status of the Response
     */
    public Response(boolean _status) {
        this(_status, null);
    }

    /**
     * Construct a default message Response with data
     * @param _status status of the Response
     * @param _data data attached to the Response
     */
    public Response(boolean _status, Object _data) {
        this(_status, (_status ? "Succeed" : "Failed"), _data);
    }

    /**
     * Construct a Response from two params
     * @param _status status of the Response
     * @param _message  message of the Response
     */
    public Response(boolean _status, String _message) {
        this.status = _status;
        this.message = _message;

    }

    /**
     * Construct a Response from three params
     * e.g.
     *      new Response(true, "ok", data));
     *      new Response(false, "Password not match", null)
     * @param _status status of the Response
     * @param _message  message of the Response
     * @param _data data attached to the Response
     */
    public Response(boolean _status, String _message, Object _data) {
        this.status = _status;
        this.message = _message;
        this.data = _data;
    }


    /**
     * Getter of status
     * @return status of Response
     */
    public boolean ok() {
        return this.status;
    }

    /**
     * Getter of message
     * @return message of Response
     */
    public String getMessage() {
        return this.message;
    }

    /**
     * Getter of data
     * @return data attached to Response
     */
    public Object getData() {
        return this.data;
    }


    /**
     * Return the response to a readable format
     * @return readable string of response
     */
    @Override
    public String toString() {
        return String.format("\nResponse: %s, %s, %s", this.ok(), this.getMessage(), this.getData());
    }
}
