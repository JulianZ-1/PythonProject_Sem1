package utils;

import config.ConfigException;
import config.DBConfig;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    /**
     * The singleton instance of the database connection.
     */
    private static Connection instance = null;

    /**
     * Constructor intializes the connection.
     */
    private DBConnection() {
        try {

            DBConfig config = new DBConfig();

            // specify the data source, username and password
            String url = config.getUrl();
            String username = config.getUsername();
            String password = config.getPassword();
            String schema = config.getSchema();

            // get a connection
            instance = DriverManager.getConnection(url + "/" + schema, username,
                    password);

        } catch (SQLException | ConfigException e) {
            e.printStackTrace();
        }
    }

    /**
     * Provides global access to the singleton instance of the UrlSet.
     *
     * @return a handle to the singleton instance of the UrlSet.
     */
    public static Connection getInstance() {
        if (instance == null) {
            new DBConnection();
        }
        return instance;
    }
}
