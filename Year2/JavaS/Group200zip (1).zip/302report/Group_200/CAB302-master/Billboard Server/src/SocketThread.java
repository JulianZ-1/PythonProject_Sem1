import dao.BillboardDao;
import dao.ScheduleDao;
import dao.UserDao;
import utils.Authentication;
import model.Billboard;
import model.User;
import network.*;

import java.io.IOException;
import java.net.Socket;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;


public class SocketThread implements Runnable {

    private Connection connection;
    private UserDao userDao;
    private BillboardDao billboardDao;
    private ScheduleDao scheduleDao;
    private String sessionToken;
    private String sessionUserName;


    /**
     * Construct new thread to handle a client socket
     * @param s a client socket
     */
    public SocketThread(Socket s) throws IOException {

        // setup an connection with the socket
        connection = new Connection(s);
    }

    /**
     * Return a boolean shows if the username and password match what has been stored in JDBC.
     * @param username
     * @param password
     * @return
     */
    private  boolean loginSucceeded(String username, String password) throws SQLException {
        String storedPassword = userDao.getPassword(username);
        if(storedPassword.equals(password)) return true;
        return false;
    }

    /**
     *
     * @return the current time.
     */
    private LocalDateTime getCurrentTime(){
        LocalDateTime now = LocalDateTime.now();
        return now;
    }

    private boolean verifyToken(String token) {
        System.out.println(token);
        boolean result = true;
        String[] t = token.split("[.]");
        if (t.length != 2) {
            result = false;
        }
        else {
            DateTimeFormatter dateTimeFormatter =  DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDateTime expireTime = LocalDateTime.parse(t[1], dateTimeFormatter);
            //If the token is not right or token is expired, it's not verified.
            if (!sessionToken.equals(t[0]) || getCurrentTime().isAfter(expireTime)) {
                result = false;
            }
        }
        return result;
    }

    /**
     * Run the thread to handle a Socket until it's closed
     */

    public void run() {
        try {
            //Initialize connections with 3 tables, and add in default settings.
            userDao = new UserDao();
            billboardDao = new BillboardDao();
            scheduleDao = new ScheduleDao();
            userDao.addDefault();
            Authentication authentication = new Authentication();
            // keep looping if stayed connected
            while (!connection.isClosed()) {

                // listen an Request
                Request request = connection.ListenRequest();
                // declare a Response to be set
                Response response = null;

                // verify token()
                boolean tokenVerified = true;
                //If it's not a login request, the session token is checked here
                if(request.getTarget() != null) {
                    if (!request.getTarget().equals("LoginRequest")) {
                        tokenVerified = verifyToken(request.getToken());
                    }
                }
                else if(!request.getType().equals("CLOSE") && !request.getType().equals("VIEWER")) {
                    tokenVerified = verifyToken(request.getToken());
                }

                if(!tokenVerified) {
                    response = new Response(false, "TokenExpired");
                    continue;
                }

                // process the request by type
                switch (request.getType()) {

                    // close the connection
                    case "CLOSE":
                        // send a response then close socket
                        connection.sendResponse(new Response(true, "connection closed", null));
                        connection.closeSocket();
                        break;

                    // TODO: CRUD
                    // In the case the request is a type of "CREATE".
                    case "CREATE":
                        switch (request.getTarget()) {
                            //If this is a "Create User" request.
                            case "CreateUser":
                                //Receive the user being created sent by client.
                                User user = (User) request.getData();
                                //Check if the user logged in has edit user permission.
                                if (userDao.getEditUsersPermission(sessionUserName).equals("1")) {
                                    //If yes, then make salt and mix with the hashed password sent,
                                    //and store the user ,salted password and salt into user table.
                                    String salt = authentication.makeSalt();
                                    user.setSalt(salt);
                                    String saltedPassword = authentication.saltPassword(user.getPassword(), salt);
                                    user.setPassword(saltedPassword);
                                    userDao.addUser(user);
                                    response = new Response(true, "New user: " + user.getName() + "is successfully created by"
                                            + sessionUserName);
                                }else{
                                    response = new Response(false, "You don't have 'Edit Users' permission to create user.");
                                }

                                break;

                            case "CreateBillboard":
                                //Get the billboard model sent by client.
                                Billboard billboard = (Billboard) request.getData();
                                //Check if the billboard is stored in schedule table.
                                if(scheduleDao.checkIfExist(billboard.getName())){
                                    //If it has, then check if the user has 'Edit all billboard' permission.
                                    //Replace the billboard with changes if yes.
                                    if(userDao.getEditAllBillboardPermission(sessionUserName).equals("1")){
                                        billboard.setCreator(sessionUserName);
                                        billboardDao.addBillboard(billboard);
                                        response = new Response(true, "Billboard name: " + billboard.getName() +
                                                "has been edited.");
                                        //Else, send a false response.
                                    }else{
                                        response = new Response(false, "Billboard name: " + billboard.getName() +
                                                "can not be edited by user without 'Edit all billboard' permission.");

                                    }
                                    //Or if it's not been scheduled, check user 'Create billboard' permission.
                                }else if (userDao.getCreateBoardPermission(sessionUserName).equals("1")) {

                                    billboard.setCreator(sessionUserName);

                                    billboardDao.addBillboard(billboard);

                                    response = new Response(true, "Billboard name: " + billboard.getName() +
                                            "has been created!");

                                }else {//If not, then this billboard cant not be edited.
                                    response = new Response(false, "Billboard name: " + billboard.getName() +
                                            "can not be created by user without 'Create billboard' permission.");
                                }
                                break;


                            case "ScheduleBillboard":
                                //Check if user has 'Schedule Billboard' permission.
                                if (userDao.getScheduleBillboardPermission(sessionUserName).equals("1")) {
                                    Billboard billboard1 = (Billboard) request.getData();
                                    //If yes, server list the billboard received.
                                    scheduleDao.addSchedule(billboard1);
                                    response = new Response(true, "Billboard name: " + billboard1.getName() +
                                            "has been scheduled between" + billboard1.getStart() + " and " + billboard1.getEnd());
                                }else{
                                    response = new Response(false, "Billboard can't be scheduled " +
                                            "by user without 'Schedule Billboard' permission.");
                                }

                                break;
                        }
                        break;

                    // In the case the request is a type of "READ".
                    case "READ":
                        switch (request.getTarget()){
                            case"LoginRequest":
                                //Read the user's name and password.
                                User user = (User) request.getData();
                                String username = user.getName();
                                //Check if the user is registered.
                                if(userDao.checkIfExist(username)) {
                                    //If yes, get ready of the hashed password sent by client
                                    //and the salt of this user stored in user table.
                                    String hashPassword = user.getPassword();
                                    String storedSalt = userDao.getSalt(username);
                                    //Salt the hashed password and check if it match the record.
                                    if (loginSucceeded(username, authentication.saltPassword(hashPassword, storedSalt))) {
                                        //If ok, generate a random unique string as session token,
                                        //also store the time at the moment as login time and add by 24 hours
                                        //so it can be used to check the login time and expire the session token
                                        //if it exceeds 24 hours.
                                        String generatedToken = UUID.randomUUID().toString();
                                        LocalDateTime loginTime = getCurrentTime().plusHours(24);
                                        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                                        //Save the session token in memory as well as the user's user name of this token.
                                        sessionToken = generatedToken;
                                        sessionUserName = username;
                                        //Format the session token with login time.
                                        generatedToken += "." + loginTime.format(dateTimeFormatter);
//                                        System.out.println("Generated Token is : " + generatedToken + "at time " + loginTime);
                                        //Send it to the client.
                                        //Note that once the token is sent back to client, it will be stored globally and
                                        // saved in Request model field "token", so that after first login, the token
                                        // is checked at the top of this while loop, see 'token verify'.
                                        response = new Response(true, generatedToken);

                                    }else{
                                        response = new Response(false, "User's password invalid.");
                                    }
                                }else{//If user is not registered before, send this back.
                                    response = new Response(false, "User's name not exist.");
                                }
                                break;

                            case"GetUserPermissions":
                                //Receive user model.
                                User user1 = (User) request.getData();
                                //Check if the user is after its own permissions, or the user has "Edit User" permission.
                                if (sessionUserName.equals(user1.getName()) || userDao.getEditUsersPermission(sessionUserName).equals("1")) {
                                    //If ok, get all permissions from table
                                    String editUsersPermission = userDao.getEditUsersPermission(user1.getName());
                                    String editAllBillboardPermission = userDao.getEditAllBillboardPermission(user1.getName());
                                    String createBoardPermission = userDao.getCreateBoardPermission(user1.getName());
                                    String scheduleBillboardPermission = userDao.getScheduleBillboardPermission(user1.getName());
                                    //Add them into a list and send it
                                    ArrayList<String> permissions = new ArrayList<String>();
                                    permissions.add(editUsersPermission);
                                    permissions.add(editAllBillboardPermission);
                                    permissions.add(createBoardPermission);
                                    permissions.add(scheduleBillboardPermission);
                                    response = new Response(true, permissions);
                                }else{
                                    response = new Response(false, "You don't have permission to get " +
                                            "this user's permissions");
                                }
                                break;

                            case"ListBillboard":
                                //Create a list saves all billboard name
                                ArrayList<String> billboardNameList;
                                billboardNameList = billboardDao.billboardNameList();

                                //Use each billboard name to find the billboard model, and
                                //append them into a new list of billboards.
                                ArrayList<Billboard> savedBillboards = new ArrayList<>();
                                for(String name : billboardNameList){
                                    savedBillboards.add(billboardDao.getSavedBillboard(name));
                                }
                                response = new Response(true, savedBillboards);

                                break;

                            case"ViewSchedule":
                                //Check if user has 'Schedule Billboard' permission.
                                if (userDao.getScheduleBillboardPermission(sessionUserName).equals("1")) {
                                    //If ok, get all scheduled billboard names
                                    ArrayList<String> names;
                                    names = scheduleDao.getAllName();
                                    for(String name: names){
                                        System.out.println(name);
                                    }
                                    //Get schedule lists by each billboard name
                                    ArrayList<Billboard> scheduledBillboards = new ArrayList<>();
                                    for(String name : names){
                                        scheduledBillboards.add(scheduleDao.getScheduledBillboard(name));
                                    }
                                    //Send the list of scheduled billboard
                                    response = new Response(true, scheduledBillboards);
                                }else{
                                    response = new Response(false, "You need 'Schedule Billboard' permission" +
                                            "to do this.");
                                }
                                break;

                            case"ListUsers":
                                //Check if user has 'Edit User' permission.
                                if (userDao.getEditUsersPermission(sessionUserName).equals("1")) {
                                    //If ok, add all user names into a list and send it.
                                    ArrayList<String> users;
                                    users = userDao.nameSet();
                                    response = new Response(true, users);
                                }else{
                                    response = new Response(false, "You need 'Edit Billboard' permission" +
                                            "to do this.");
                                }
                                break;

                            case"GetBillboard":
                                //Receive billboard's name and use it to get its content then add it to the billboard model
                                Billboard billboard = (Billboard) request.getData();
                                String contents = billboardDao.getContentBYBillboardName(billboard.getName());
                                billboard.setContent(contents);
                                //Send the billboard back
                                response = new Response(true, billboard);

                                break;
                        }
                        break;

                    case "UPDATE":
                        switch (request.getTarget()) {
                            case "SetUserPermissions":
                                //Receive the user model and check if user requested has 'Edit User' permission.
                                User user1 = (User) request.getData();
                                if (userDao.getEditUsersPermission(sessionUserName).equals("1")) {
                                    //If ok, set user's permissions accordingly.
                                    userDao.setCreateBoardPermission(user1.getName(), user1.getCreateBillboard());
                                    userDao.setEditAllBillboardPermission(user1.getName(), user1.getEditAllBillboard());
                                    userDao.setEditUsersPermission(user1.getName(), user1.getEditUsers());
                                    userDao.setScheduleBillboardPermission(user1.getName(), user1.getScheduleBillboard());
                                    response = new Response(true, "User's permissions has been updated.");


                                } else {
                                    response = new Response(false, "You need 'Edit Users' permission to do this.");
                                }
                                break;


                            case "SetPassword":
                                User user = (User) request.getData();
                                //If user requested to change its own password
                                // or it has 'Edit Users' permission.
                                if (sessionUserName.equals(user.getName()) || userDao.getEditUsersPermission(sessionUserName).equals("1")) {
                                    //If ok, salt the hashed password and save it under the user name.
                                    String salt = userDao.getSalt(user.getName());
                                    String saltedPassword = authentication.saltPassword(user.getPassword(), salt);
                                    userDao.setPassword(user.getName(), saltedPassword);
                                    response = new Response(true, "User: " + user.getName() + " password is successfully updated by"
                                            + sessionUserName);
                                }else{
                                    response = new Response(false, "Only user of themselves or user with 'Edit User' " +
                                            "permission can set password, please recheck.");
                                }
                        }

                        break;

                    case "DELETE":
                        switch (request.getTarget()) {
                            case "RemoveSchedule":
                                //Check if user has 'Schedule Billboard' permission to remove schedule.
                                if (userDao.getScheduleBillboardPermission(sessionUserName).equals("1")) {
                                    //If ok, delete that billboard from schedule table.
                                    Billboard billboard = (Billboard) request.getData();
                                    scheduleDao.deleteByBillboardName(billboard.getName());
                                    response = new Response(true, "Billboard name: " + billboard.getName() +
                                            "has been unscheduled between");
                                }else{
                                    response = new Response(true, "You need 'Schedule Billboard' permission" +
                                            " to remove this schedule");
                                }

                                break;

                            case "DeleteBillboard":
                                //Get billboard name
                                String billboardName = (String) request.getData();
                                //A boolean to check if a billboard is scheduled.
                                Boolean Scheduled = scheduleDao.checkIfExist(billboardName);
                                //Get creator's name of this billboard.
                                String creator = billboardDao.getCreatorByBillboard(billboardName);
                                //if deleting user's own billboard and that billboard is not currently scheduled,
                                // must have “Create Billboards” permission.
                                if (sessionUserName.equals(creator) && !Scheduled ) {
                                    if(userDao.getCreateBoardPermission(sessionUserName).equals("1")){
                                        billboardDao.DeleteBillboard(billboardName);
                                        response = new Response(true, "Billboard name: " + billboardName +
                                                "has been deleted.");
                                    }else{
                                        response = new Response(false, "You need 'Create Billboard' permission" +
                                                " to do this.");
                                    }
                                }else{
                                    //To delete any other billboards, including those currently scheduled,
                                    // must have “Edit All Billboards” permission.)
                                    if(userDao.getEditAllBillboardPermission(sessionUserName).equals("1")){
                                        billboardDao.DeleteBillboard(billboardName);
                                        scheduleDao.deleteByBillboardName(billboardName);
                                        response = new Response(true, "Billboard name: " + billboardName +
                                                "has been deleted.");
                                    }else{
                                        response = new Response(false, "You need 'Edit All  Billboards' permission" +
                                                " to do this.");
                                    }
                                }

                                break;
                            case "DeleteUser":
                                User user = (User) request.getData();
                                //Check if user is deleting themselves.
                                if (!sessionUserName.equals(user.getName())) {
                                    //if not, then check if user has 'Edit users' permission
                                    if (userDao.getEditUsersPermission(sessionUserName).equals("1")) {
                                        //If ok, delete it.
                                        userDao.deleteUser(user.getName());
                                        response = new Response(true, "User: " + user.getName() +
                                                "has been deleted.");
                                    }else{
                                        response = new Response(false, "You need 'Edit User' permission" +
                                                " to do this.");
                                    }
                                }else{
                                    response = new Response(false, "Users are not allowed to delete themselves.");
                                }
                                break;
                        }
                        break;

                    // viewer
                    case "VIEWER":
                        //Get current time.
                        LocalDateTime now = LocalDateTime.now();
                        //Get each billboard's start time and end time
                        //and find the index of the billboard in schedule table that should be shown in viewer.
                        ArrayList<Integer> result = new ArrayList<Integer>();
                        for ( int i = 0 ; i < scheduleDao.getAllStart().size(); i++){
                            if(now.isAfter(LocalDateTime.parse(scheduleDao.getAllStart().get(i)))){
                                if(now.isBefore(LocalDateTime.parse((scheduleDao.getAllEnd().get(i))))){
                                    result.add(i);
                                }
                            }
                        }
                        //If there is no billboard needs to be playing, give false response
                        if(result.isEmpty()){
                            response = new Response(false,null,null);
                        }else{
                            //or if there are multiple schedule lining up, find the max index which is the last inserted
                            // and send this one back
                            int index = (result.get(0));
                            for (int j = 0; j < result.size(); j ++){

                                if (result.get(j) > index){
                                    index = result.get(j);
                                }
                            }
                            //Use the index to get the start time and end time, then use it to find billboard name from schedule
                            String billboardWanted = scheduleDao.getnamebytime(scheduleDao.getAllStart().get(index),scheduleDao.getAllEnd().get(index));
                            //Use the billboard name to find its content from billboard table
                            String content = billboardDao.getContentBYBillboardName(billboardWanted);
                            //Send the billboard content to viewer
                            response = new Response(true, content);
                        }


                        break;
                    // empty response received
                    case "EMPTY":
                        // empty request acceptable
                        response = new Response(true, "an empty request received", null);
                        break;

                    // unknown response received
                    default:
                        // unknown request not acceptable
                        response = new Response(false, "unknown type of request", null);
                        break;
                }

                // send back the response
                connection.sendResponse(response);
            }

            // socket disconnected, close all stream
            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        // thread finished, wait for GC
    }
}
