package config;

import java.io.*;
import java.util.Properties;

public abstract class Config {

    protected Properties properties;
    protected File file;

    public Config(String path, String empty_props) throws ConfigException {
        file = new File(path);

        if(!file.exists()) {
            createEmpty(file, empty_props);
        }
    }

    protected void createEmpty(File file, String empty_props) {

        try {
            file.createNewFile();

            FileWriter fileWriter = new FileWriter(file);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            bufferedWriter.write(empty_props);

            bufferedWriter.close();
            fileWriter.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    protected void parse() throws ConfigException {

        properties = new Properties();

        FileInputStream fileInputStream = null;

        try {
            fileInputStream = new FileInputStream(file);
            properties.load(fileInputStream);
            fileInputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    protected abstract void verify() throws ConfigException;

    protected void verifyAddress(String address) throws ConfigException {

        String regEx = "^(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|[1-9])\\."
                + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."
                + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."
                + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)$";

        if(address.isEmpty() || !address.matches(regEx)) {
            throw new ConfigException("Address not valid, please check the props file");
        }
    }

    protected void verifyPort(int port) throws ConfigException {

        if (port < 0 || port > 65535) {
            throw new ConfigException("Port not valid, please check the props file");
        }
    }

}
