package config;

// TODO: modify, see ServerConfig

public class PortConfig extends Config{

    private int port;
    private String host;

    public PortConfig() throws ConfigException {

        super("./port.props", "port = \nhost = ");

        this.parse();
    }

    @Override
    protected void parse() throws ConfigException {

        super.parse();

        port = Integer.parseInt(super.properties.getProperty("port").equals("") ? "-1" : super.properties.getProperty("port"));
        host = super.properties.getProperty("host");

        verify();
    }


    @Override
    protected void verify() throws ConfigException {
        System.out.println("Port: " + port);
        System.out.println("Host: " + host);

        super.verifyPort(port);
    }

    public int getPort() {
        return port;
    }

    public String getHost() {
        return host;
    }
}
