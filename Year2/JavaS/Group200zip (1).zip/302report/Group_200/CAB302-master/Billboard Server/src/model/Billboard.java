package model;

import java.io.Serializable;

public class Billboard implements Serializable {

    private String id;

    private String name;

    private String creator;

    private String content;

    private String start;

    private String end;

    private String created;

    /**
     * No args constructor.
     */
    public Billboard(){
    }

    /**
     *Constructor to set values for the Billboard's details.
     * @param name
     * @param creator
     * @param content
     * @param start
     * @param end
     * @param created
     */
    public Billboard(String name, String creator, String content, String start, String end, String created) {
        this.name = name;
        this.creator = creator;
        this.content = content;
        this.start = start;
        this.end = end;
        this.created = created;
    }

    /**
     *
     * @return get the Id
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param Id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return get the creator
     */
    public String getCreator() {
        return creator;
    }

    /**
     *
     * @param creator to set
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     *
     * @return the content of billboard
     */
    public String getContent() {
        return content;
    }

    /**
     *
     * @param content to set
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     *
     * @return the start time
     */
    public String getStart() {
        return start;
    }

    /**
     *
     * @param start time to set
     */
    public void setStart(String start) {
        this.start = start;
    }

    /**
     *
     * @return the end time
     */
    public String getEnd() {
        return end;
    }

    /**
     *
     * @param end to set
     */
    public void setEnd(String end) {
        this.end = end;
    }

    /**
     *
     * @return
     */
    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    /**
     *
     * @return name of billboard
     */
    public String getName() {
        return name;
    }

    /**
     * set name to billboard
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }


    // TODO: toString
    @Override
    public String toString() {
        return name + " " + creator + " " + content + " " + start + " " + end + " " + created;
    }
}
