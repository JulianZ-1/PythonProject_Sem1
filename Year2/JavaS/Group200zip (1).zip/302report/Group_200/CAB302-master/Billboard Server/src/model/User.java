package model;

import java.io.Serializable;


public class User implements Serializable {

    private String name;

    private String password;

    private String salt;

    private String createBillboard;

    private String editAllBillboard;

    private String editUsers;

    private String scheduleBillboard;

    /**
     * No args constructor.
     */
    public User() {
    }

    /**
     * Constructor to set values for the User's details.
     * @param name
     * @param password
     * @param salt
     * @param createBillboard
     * @param editAllBillboard
     * @param editUsers
     * @param scheduleBillboard
     */
    public User(String name, String password, String salt, String createBillboard, String editAllBillboard, String editUsers, String scheduleBillboard) {
        this.name = name;
        this.password= password;
        this.salt = salt;
        this.createBillboard = createBillboard;
        this.editAllBillboard= editAllBillboard;
        this.editUsers = editUsers;
        this.scheduleBillboard = scheduleBillboard;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCreateBillboard() {
        return createBillboard;
    }

    public void setCreateBillboard(String createBillboard) {
        this.createBillboard = createBillboard;
    }

    public String getEditAllBillboard() {
        return editAllBillboard;
    }

    public void setEditAllBillboard(String editAllBillboard) {
        this.editAllBillboard = editAllBillboard;
    }

    public String getEditUsers() {
        return editUsers;
    }

    public void setEditUsers(String editUsers) {
        this.editUsers = editUsers;
    }

    public String getScheduleBillboard() {
        return scheduleBillboard;
    }

    public void setScheduleBillboard(String scheduleBillboard) {
        this.scheduleBillboard = scheduleBillboard;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }


    @Override
    public String toString() {
        return name + " " + password + " " + createBillboard + " " + editAllBillboard + " " + editUsers + " " + scheduleBillboard;
    }

}
