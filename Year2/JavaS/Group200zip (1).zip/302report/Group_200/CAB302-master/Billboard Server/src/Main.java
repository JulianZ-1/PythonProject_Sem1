import config.*;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Main {

    public static void main(String[] args) {

        // TODO: add close condition
        boolean closeServer = false;

        System.out.println("--- Server Started ---");

        try {
            // Establish server socket
            ServerSocket ss = new ServerSocket(new PortConfig().getPort());

            System.out.println("Waiting for Connections ....");

            while (!closeServer) {
                // Listen for connections
                Socket socket = ss.accept();
                // Log the connection
                System.out.println("Client: " + socket.getInetAddress().getHostAddress() + " Connected");
                // New thread to process the connection
                new Thread(new SocketThread(socket)).start();
            }

        } catch (IOException | ConfigException e) {
            e.printStackTrace();
        }
        finally {
            System.out.println("--- Server Closed ---");
        }
    }
}
