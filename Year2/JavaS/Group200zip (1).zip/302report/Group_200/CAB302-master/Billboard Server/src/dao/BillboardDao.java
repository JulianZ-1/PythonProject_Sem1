package dao;



import model.Billboard;
import utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;


/**
 * Class for retrieving data from billboard table.
 */
public class BillboardDao {

    public static final String CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS BillboardTable ("
                    + "idx INTEGER PRIMARY KEY /*!40101 AUTO_INCREMENT */ NOT NULL UNIQUE,"
                    + "billboard VARCHAR(100) NOT NULL UNIQUE,"
                    + "creator VARCHAR(30),"
                    + "content TEXT(1000)"
                    + ");";

    private static final String INSERT_BILLBOARD = "REPLACE INTO BillboardTable (billboard, creator, content) VALUES (?, ?, ?);";

    private static final String DEFAULT_BILLBOARD1 = "INSERT IGNORE INTO BillboardTable (billboard, creator, content) VALUES ('Default', 'Admin', '-<billboard>\n" +
            "\n" +
            "<picture url=\"https://cloudstor.aarnet.edu.au/plus/s/62e0uExNviPanZE/download\"/>\n" +
            "\n" +
            "</billboard>');";

    private static final String DEFAULT_BILLBOARD2 = "INSERT IGNORE INTO BillboardTable (billboard, creator, content) VALUES ('TestBillboard', 'Shu', 'Hello!!!!!!!!!!!');";

    private static final String GET_ALL_CREATOR = "SELECT creator FROM BillboardTable";

    private static final String GET_CREATOR_BY_BILLBOARD = "SELECT creator FROM BillboardTable WHERE billboard=?";

    private static final String GET_ALL_BILLBOARD = "SELECT billboard FROM BillboardTable";

    private static final String GET_LIST_BILLBOARD = "SELECT * FROM BillboardTable";

    private static final String GET_BILLBOARD_BY_CREATOR = "SELECT billboard FROM BillboardTable WHERE creator=?";

    private static final String GET_CONTENT_BY_BILLBOARD = "SELECT content FROM BillboardTable WHERE billboard=?";

    private static final String GET_ALL_BY_BILLBOARD_NAME = "SELECT * FROM BillboardTable WHERE billboard=?";

    private static final String DELETE_BILLBOARD = "DELETE FROM BillboardTable WHERE BILLBOARD=?";

    private static final String COUNT_ROWS = "SELECT COUNT(*) FROM UserTable";

    private Connection connection;

    private PreparedStatement getListBillboards;

    private PreparedStatement addBillboard;

    private PreparedStatement getAllCreator;

    private PreparedStatement getAllBillboard;

    private PreparedStatement getBillboardBYCreator;

    private PreparedStatement getContentBYBillboardName;

    private PreparedStatement getAllByBillboardName;

    private PreparedStatement deleteByBillboardName;

    private PreparedStatement getCreatorByBillboard;

    private PreparedStatement rowCount;

    public BillboardDao() {
        connection = DBConnection.getInstance();
        try {
            Statement st = connection.createStatement();
            st.execute(CREATE_TABLE);

            addBillboard = connection.prepareStatement(INSERT_BILLBOARD);
            getListBillboards = connection.prepareStatement(GET_LIST_BILLBOARD);
            getAllCreator = connection.prepareStatement(GET_ALL_CREATOR);
            getAllBillboard = connection.prepareStatement(GET_ALL_BILLBOARD);
            getBillboardBYCreator = connection.prepareStatement(GET_BILLBOARD_BY_CREATOR);
            getContentBYBillboardName = connection.prepareStatement(GET_CONTENT_BY_BILLBOARD);
            deleteByBillboardName = connection.prepareStatement(DELETE_BILLBOARD);
            rowCount = connection.prepareStatement(COUNT_ROWS);
            getAllByBillboardName = connection.prepareStatement(GET_ALL_BY_BILLBOARD_NAME);
            getCreatorByBillboard = connection.prepareStatement(GET_CREATOR_BY_BILLBOARD);

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     *Add default billboards.
     */
    public void  addDefault() throws SQLException {
        Statement st1 = connection.createStatement();
        st1.execute(DEFAULT_BILLBOARD1);
        Statement st2 = connection.createStatement();
        st2.execute(DEFAULT_BILLBOARD2);
    }

    /**
     *
     * @param billboard
     * @return  get its creator by a billboard name.
     * @throws SQLException
     */
    public String getCreatorByBillboard(String billboard) throws SQLException {
        ResultSet rs = null;
        try {
            getCreatorByBillboard.setString(1,billboard);
            rs = getCreatorByBillboard.executeQuery();
            rs.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs.getString("creator");
    }


//       public String getBillboardInformationByCreator(String creator) throws SQLException {
//        ResultSet rs = null;
//        try {
//            getBillboardBYCreator.setString(1,creator);
//            rs = getBillboardBYCreator.executeQuery();
//            rs.next();
//
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        }
//        return rs.getString("content");
//    }

//    public Boolean checkIfExist(String billboardName) throws SQLException {
//        ResultSet rs = null;
//        try {
//            getAllByBillboardName.setString(1,billboardName);
//            rs = getAllByBillboardName.executeQuery();
//
//
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        }
//        return rs.next();
//    }

    /**
     *
     * @param billboardName
     * @return get a billboard's content by its name.
     */
    public String getContentBYBillboardName(String billboardName) throws SQLException {
        ResultSet rs = null;
        try {
            getContentBYBillboardName.setString(1,billboardName);
            rs = getContentBYBillboardName.executeQuery();
            rs.next();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs.getString("content");
    }

    /**
     * Delete a billboard by its name.
     * @param billboard
     */
    public void DeleteBillboard(String billboard) {

        try {
            deleteByBillboardName.setString(1, billboard);
            deleteByBillboardName.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Add a billboard(Create billboard) or replace it if the billboard's name is same(Edit billboard)
     * @param b Billboard model
     */
    public void addBillboard (Billboard b){
            try {
                addBillboard.setString(1, b.getName());
                addBillboard.setString(2, b.getCreator());
                addBillboard.setString(3, b.getContent());
                addBillboard.execute();

            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }


        public ArrayList<String> creatorSet () {
            ArrayList<String> creators = new ArrayList<String>();
            ResultSet rs = null;
            try {
                rs = getAllCreator.executeQuery();
                while (rs.next()) {
                    creators.add(rs.getString("creator"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            return creators;
        }

    /**
     *
     * @return get a list of billboard names
     */
    public  ArrayList<String> billboardNameList () {
            ArrayList<String> billboards = new ArrayList<String>();
            ResultSet rs = null;
            try {
                rs = getAllBillboard.executeQuery();
                while (rs.next()) {
                    billboards.add(rs.getString("billboard"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            return billboards;
        }


    public ArrayList<String> getListBillboards () {
            ArrayList<String> ListBillboards = new ArrayList<String>();
            ResultSet rs = null;
            try {
                rs = getListBillboards.executeQuery();
                while (rs.next()) {
                    ListBillboards.add(rs.getString("billboard"));
                    ListBillboards.add(rs.getString("creator"));
                    ListBillboards.add(rs.getString("content"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            return ListBillboards;
        }

    /**
     *
     * @param name
     * @return get a billboard model by its name.
     */
    public Billboard getSavedBillboard(String name) {
        Billboard billboard = new Billboard();
        ResultSet rs = null;
        try {
            getAllByBillboardName.setString(1, name);
            rs = getAllByBillboardName.executeQuery();
            rs.next();
            billboard.setName(rs.getString("billboard"));
            billboard.setCreator(rs.getString("creator"));
            billboard.setContent(rs.getString("content"));

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return billboard;
    }
    }

