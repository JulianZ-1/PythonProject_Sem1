package dao;



import model.Billboard;
import utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;



/**
 * Class for retrieving data from schedule table.
 */
public class ScheduleDao {

   public static final String CREATE_TABLE =
           "CREATE TABLE IF NOT EXISTS schedule ("
                   + "idx INTEGER PRIMARY KEY /*!40101 AUTO_INCREMENT */ NOT NULL UNIQUE," // from https://stackoverflow.com/a/41028314
                   + "billboard VARCHAR(30),"
                   + "start VARCHAR (30),"
                   + "end VARCHAR (30)"
                   + ");";

   private static final String INSERT_SCHEDULE = "INSERT INTO schedule (billboard, start, end) VALUES (?, ?, ?);";

   private static final String GET_START = "SELECT start FROM schedule WHERE billboard=?";

   private static final String GET_END = "SELECT end FROM schedule WHERE billboard=?";

    private static final String GET_BILLBOARD_BY_NAME = "SELECT * FROM schedule WHERE billboard=?";

   private static final String GET_NAME_BY_IDX = "SELECT billboard FROM schedule WHERE idx=?";

    private static final String GET_ALL_IDX = "SELECT idx FROM schedule";

    private static final String GET_ALL_NAME = "SELECT billboard FROM schedule";

    private static final String GET_ALL_START = "SELECT start FROM schedule";

    private static final String GET_ALL_END = "SELECT end FROM schedule";

   private static final String GET_ALL_BILLBOARD = "SELECT billboard FROM schedule";

   private static final String DELETE_SCHEDULE = "DELETE FROM schedule WHERE billboard=? AND start=? AND end=?";

    private static final String DELETE_SCHEDULE_BY_NAME = "DELETE FROM schedule WHERE billboard=?";

    private static final String GET_ALL_SCHEDULE = "SELECT * FROM schedule";

    private static final String GET_NAME_BY_TIME = "SELECT billboard FROM schedule WHERE start=? AND end=?";
    



   private static final String COUNT_ROWS = "SELECT COUNT(*) FROM schedule";

   private Connection connection;

   private PreparedStatement addSchedule;

   private PreparedStatement getBillboard;

   private PreparedStatement getStart;

   private PreparedStatement getEnd;

   private PreparedStatement getNameByidx;

    private PreparedStatement getAllName;

    private PreparedStatement getALLStart;

    private PreparedStatement getAllEnd;

    private PreparedStatement getAllidx;

    private PreparedStatement getAllSchedule;

    private PreparedStatement getBillboardByName;

    private PreparedStatement deleteByBillboardName;

   private PreparedStatement getScheduleList;

   private PreparedStatement getSchedule;


   private PreparedStatement deleteSchedule;

   private PreparedStatement getnamebytime;

   private PreparedStatement rowCount;

   public ScheduleDao() {
      connection = DBConnection.getInstance();
      try {
         Statement st = connection.createStatement();
         st.execute(CREATE_TABLE);

         addSchedule = connection.prepareStatement(INSERT_SCHEDULE);
         getBillboard =connection.prepareStatement(GET_ALL_BILLBOARD);
         getStart = connection.prepareStatement(GET_START);
         getEnd = connection.prepareStatement(GET_END);
         deleteSchedule = connection.prepareStatement(DELETE_SCHEDULE);
         getNameByidx = connection.prepareStatement(GET_NAME_BY_IDX);
         getAllidx = connection.prepareStatement(GET_ALL_IDX);
         getALLStart = connection.prepareStatement(GET_ALL_START);
         getAllEnd = connection.prepareStatement(GET_ALL_END);
         getAllSchedule = connection.prepareStatement(GET_ALL_SCHEDULE);
         getBillboardByName =  connection.prepareStatement(GET_BILLBOARD_BY_NAME);
         getAllName = connection.prepareStatement(GET_ALL_NAME);
         deleteByBillboardName = connection.prepareStatement(DELETE_SCHEDULE_BY_NAME);
         getnamebytime = connection.prepareStatement(GET_NAME_BY_TIME);

      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }

    /**
     * Add a billboard schedule with name, start and end time.
     * @param s
     */
   public void addSchedule(Billboard s) {
      try {

         addSchedule.setString(1, s.getName());
         addSchedule.setString(2, s.getStart());
         addSchedule.setString(3, s.getEnd());
         addSchedule.execute();

      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }

    /**
     * @param billboard
     * @return Get the start time of a billboard's schedule by its name.
     */
    public String getStart(String billboard) throws SQLException {
        ResultSet rs = null;
        try {
            getStart.setString(1,billboard);
            rs = getStart.executeQuery();
            rs.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs.getString("start");
    }
    /**
     * @param billboard
     * @return  Get the end time of a billboard's schedule by its name.
     */
    public String getEnd(String billboard) throws SQLException {
        ResultSet rs = null;
        try {
            getEnd.setString(1,billboard);
            rs = getEnd.executeQuery();
            rs.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs.getString("end");
    }

    /**
     * @param idx
     * @returnGet a scheduled billboard name by its index.
     */
    public String getNameByidx(Integer idx) throws SQLException {
        ResultSet rs = null;
        try {
            getNameByidx.setInt(1,idx);
            rs = getNameByidx.executeQuery();
            rs.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs.getString("billboard");
    }

    /**
     *
     * @param start
     * @param end
     * @return get billboard name given start and end time
     */
    public String getnamebytime(String start, String end) throws SQLException {
        ResultSet rs = null;
        try {
            getnamebytime.setString(1,start);
            getnamebytime.setString(2,end);

            rs = getnamebytime.executeQuery();
            rs.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs.getString("billboard");
    }

//    /**
////     *
////     * @return
////     */
////    public ArrayList<String> getAllSchedule () {
////        ArrayList<String> schedules = new ArrayList<String>();
////        ResultSet rs = null;
////        try {
////            rs = getAllSchedule.executeQuery();
////            while (rs.next()) {
////                schedules.add(rs.getString("billboard"));
////                schedules.add(rs.getString("start"));
////                schedules.add(rs.getString("end"));
////            }
////        } catch (SQLException ex) {
////            ex.printStackTrace();
////        }
////        return schedules;
////    }

    /**
     *
     * @param name
     * @return Get a billboard by its name
     */
    public Billboard getScheduledBillboard(String name) {
        Billboard billboard = new Billboard();
        ResultSet rs = null;
        try {
            getBillboardByName.setString(1, name);
            rs = getBillboardByName.executeQuery();
            rs.next();
            billboard.setName(rs.getString("billboard"));
            billboard.setStart(rs.getString("start"));
            billboard.setEnd(rs.getString("end"));

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return billboard;
    }

    /**
     *
     * @return a list of index of schedule table.
     */
    public ArrayList<Integer> idxList () {
        ArrayList<Integer> idx = new ArrayList<Integer>();
        ResultSet rs = null;
        try {
            rs = getAllidx.executeQuery();
            while (rs.next()) {
                idx.add(rs.getInt("idx"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return idx;
    }

    /**
     *
     * @return a list of scheduled billboard names.
     */
    public ArrayList<String> getAllName () {
        ArrayList<String> names = new ArrayList<String>();
        ResultSet rs = null;
        try {
            rs = getAllName.executeQuery();
            while (rs.next()) {
                names.add(rs.getString("billboard"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return names;
    }

    /**
     *
     * @return a list of all start time of each scheduled billboards.
     */
    public ArrayList<String> getAllStart () {
        ArrayList<String> starts = new ArrayList<String>();
        ResultSet rs = null;
        try {
            rs = getALLStart.executeQuery();
            while (rs.next()) {
                starts.add(rs.getString("start"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return starts;
    }

    /**
     *
     * @return a list of all end time of each scheduled billboards.
     */
    public ArrayList<String> getAllEnd () {
        ArrayList<String> ends = new ArrayList<String>();
        ResultSet rs = null;
        try {
            rs = getAllEnd.executeQuery();
            while (rs.next()) {
                ends.add(rs.getString("end"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return ends;
    }

    /**
     *
     * @return a list of all scheduled billboard names.
     */
    public ArrayList<String> billboardSet () {

        ArrayList<String> billboards = new ArrayList<String>();

        ResultSet rs = null;
        try {
            rs = getBillboard.executeQuery();
            while (rs.next()) {
                billboards.add(rs.getString("billboard"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return billboards;
    }


//   public int getSize() {
//      ResultSet rs = null;
//      int rows = 0;
//      try {
//         rs = rowCount.executeQuery();
//         rs.next();
//         rows = rs.getInt(1);
//      } catch (SQLException ex) {
//         ex.printStackTrace();
//      }
//      return rows;
//   }

    /**
     *
     * @param billboardName
     * @return  true if a billboard is stored in this schedule table.
     */
    public Boolean checkIfExist(String billboardName) throws SQLException {
        ResultSet rs = null;
        try {
            getBillboardByName.setString(1,billboardName);
            rs = getBillboardByName.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs.next();
    }

    /**
     * Delete a schedule by given a billboard model.
     * @param s
     */
   public void deleteSchedule(Billboard s) {

      try {
          deleteSchedule.setString(1, s.getName());
          deleteSchedule.setString(2, s.getStart());
          deleteSchedule.setString(3, s.getEnd());
          deleteSchedule.executeUpdate();

      } catch (SQLException ex) {
         ex.printStackTrace();
      }
   }

    /**
     * Delete a schedule by a billboard name.
     * @param billboardName
     */
    public void deleteByBillboardName(String billboardName) {

        try {
            deleteByBillboardName.setString(1, billboardName);
            deleteByBillboardName.executeUpdate();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Close DB connection.
     */
   public void close() {

      try {
         connection.close();
      } catch (SQLException ex) {
         ex.printStackTrace();
      }

   }
}
