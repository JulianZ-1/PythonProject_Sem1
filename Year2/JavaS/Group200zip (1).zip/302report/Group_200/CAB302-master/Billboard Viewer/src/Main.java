import config.ConfigException;
import model.Billboard;
import network.*;

import java.io.IOException;

public class Main {
    private static Viewer page;

    public static void main(String[] args) throws IOException, ConfigException, ClassNotFoundException {

       Connection connection;
        /* content to use when there is no given billboard. */

        try{
            /* ready to connect to the server */
            connection = new Connection();

            page = new Viewer();
            page.setConnection(connection);

            /* while the connection is not close */
            while(!connection.isClosed()){
                /* sending a request call "VIEWER" */
                connection.sendRequest(new Request("VIEWER"));
                /* wait for the repose from the server */
                Response res = connection.listenResponse();
                /* if the response is not ok, tell the billboard to draw a
                * default billboard, else draw what the server have send back.
                * this request will also sent every 15 seconds  */
                if(!res.ok()){
                    Billboard record = new Billboard();
                    record.setContent("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                            "<billboard background=\"#FFFFFF\">\n" +
                            "    <message colour=\"#FF9E3F\">No content</message>\n" +
                            "</billboard>");

                    page.setBillboard(record);
                }
                else{
                    Billboard record = new Billboard();
                    record.setContent(res.getMessage());
                    page.setBillboard(record);
                }
                Thread.sleep(1000);

            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
