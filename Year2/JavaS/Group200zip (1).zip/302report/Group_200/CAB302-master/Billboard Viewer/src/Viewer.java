import billboard.BillboardData;
import billboard.BillboardDrawer;
import billboard.BillboardView;
import model.Billboard;
import network.Connection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

/**
 * Page to Create new Billboards and edit existing ones
 */
public class Viewer extends JFrame {

    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

    private JPanel rootPanel;

    private BillboardView billboardView;
    private BillboardData billboardData;
    private BillboardDrawer billboardDrawer;
    private Billboard board;

    private Connection connection;

    /**
     * Constructor used to edit existing billboard
     */
    public Viewer() {
        board = new Billboard();
        board.setContent("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<billboard background=\"#FFFFFF\">\n" +
                "    <message colour=\"#FF9E3F\">No content</message>\n" +
                "</billboard>");

        billboardData = new BillboardData(board.getContent());

        initFrame();
    }

    private void initFrame() {

        billboardDrawer = new BillboardDrawer(0, 0, screenSize.width, screenSize.height);

        billboardView = billboardDrawer.draw(billboardData);

        setWindow();
    }

    private void setWindow(){

        setExtendedState(MAXIMIZED_BOTH);
        setDefaultCloseOperation(HIDE_ON_CLOSE);

        setUndecorated(true);
        setDefaultLookAndFeelDecorated(true);

        setTitle("Billboard Editer");

        setResizable(false);
        setVisible(true);

        rootPanel = new JPanel();

        addKeyListener(new KeyAdapter() {           //调节按键
            @Override
            public void keyPressed(KeyEvent e) {
                super.keyPressed(e);
                if(e.getKeyCode() == KeyEvent.VK_ESCAPE){
                    close();
                }
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if(e.getClickCount() == 1){
                    close();
                }
            }
        });

        paintFrame();
    }

    public void setConnection(Connection c) {
        connection = c;
    }

    public void close() {
        try {
            connection.closeClientSide();
        } catch (IOException | ClassNotFoundException ioException) {
            ioException.printStackTrace();
        }
        System.exit(1);
    }


    private void paintFrame() {
        rootPanel.add(billboardView);
        add(rootPanel);

        rootPanel.revalidate();
        revalidate();
    }

    private void repaintFrame() {
        rootPanel.remove(billboardView);
        remove(rootPanel);

        billboardView = billboardDrawer.draw(billboardData);

        paintFrame();
    }

    public void setBillboard(Billboard billboard) {
        board.setContent(billboard.getContent());
        billboardData = new BillboardData(board.getContent());
        repaintFrame();
    }
}
