package network;

import java.io.Serializable;

public class Request implements Serializable {

    private String type;
    private String target;
    private Object data;
    private String token;

    /**
     * Construct an empty Request
     */
    public Request() {
        this("EMPTY");
    }

    /**
     * Construct a Request from single param
     * e.g.
     *      EMPTY   - an empty request
     *      CLOSE   - close socket connection
     * @param _type type of the request
     */
    public Request(String _type) {
        this(_type, null, null);
    }

    // TODO: complete the comment
    /**
     * Construct a Request from three params
     * e.g.
     *      CRUD
     * @param _type type of the request
     * @param _target target of the request
     * @param _data date of the request
     */
    public Request(String _type, String _target, Object _data) {
        this.type = _type;
        this.target = _target;
        this.data = _data;
    }

    public Request(String _type, String _target) {
        this.type = _type;
        this.target = _target;
    }

    /**
     * Setter of token
     * @param _token token of the request
     */
    public void setToken(String _token) {
        this.token = _token;
    }

    /**
     * Getter of token
     * @return token of the request
     */
    public String getToken() {
        return this.token;
    }

    /**
     * Getter of type
     * @return type of the request
     */
    public String getType() {
        return this.type;
    }

    /**
     * Getter of target
     * @return target of the request
     */
    public String getTarget() {
        return this.target;
    }

    /**
     * Getter of data
     * @return data of the request
     */
    public Object getData() {
        return this.data;
    }


    /**
     * Return the request to a readable format
     * @return readable string of request
     */
    @Override
    public String toString() {
        return String.format("\nRequest: %s, %s, %s", this.getType(), this.getTarget(), this.getData());
    }

}


