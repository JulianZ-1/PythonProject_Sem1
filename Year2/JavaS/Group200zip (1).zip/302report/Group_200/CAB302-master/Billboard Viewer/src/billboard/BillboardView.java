package billboard;

import javax.swing.*;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.LinkedList;

public class BillboardView extends JPanel {

    private LinkedList<Object[]> elementsList;

    public BillboardView(int width, int height) {
        this.setPreferredSize(new Dimension(width, height));
    }

    public BillboardView(int x, int y, int width, int height) {
        this(width, height);
        this.setLocation(x, y);
    }


    public void setBGColor(Color color) {
        this.setBackground(color);
    }

    public void setElements(LinkedList<Object[]> elementsListPointer) {
        this.elementsList = elementsListPointer;
    }

    private void drawElements(Graphics2D g2d) {

        double elementWidth = getPreferredSize().getWidth();
        double elementHeight = getPreferredSize().getHeight() / elementsList.size();


        int nth = 0;

        Font font;
        Rectangle2D bounds = null;
        FontRenderContext fontRenderContext = null;

        // returned elementList format:
        // ["type", Attribute, Data]
        for(Object[] element: elementsList) {

            switch ((String) element[0]) {

                // ["message", Color, "content"]
                case "message":
                    // set color
                    g2d.setColor((Color) element[1]);

                    // draw content
                    // as big as possible, no line wrap

                    // calculate size
                    int messSize = 20;
                    double range = 0.9;
                    boolean sizeFound = false;

                    // I'm crying
                    while (!sizeFound) {
                        font = new Font("Sans Serif", Font.BOLD, messSize);
                        g2d.setFont(font);

                        fontRenderContext = g2d.getFontRenderContext();
                        bounds = font.getStringBounds((String) element[2], fontRenderContext);

                        if(bounds.getWidth() > elementWidth * range || bounds.getHeight() > elementHeight * range) {
                            sizeFound = true;
                        }

                        messSize ++;
                    }

                    // left top (x, y)
                    double x = (elementWidth - bounds.getWidth()) / 2;
                    double y = (elementHeight - bounds.getHeight()) / 2 + elementHeight * nth;
                    double ascent = bounds.getY();

                    // draw
                    g2d.drawString((String) element[2], (int) x, (int) (y - ascent));

                    break;

                // ["information", Color, "content"]
                case "information":
                    // set color
                    g2d.setColor((Color) element[1]);

                    // draw content
                    String info = (String) element[2];

                    // calculate size
                    int infoSize = 10;
                    double rangeX = 0.75, rangeY = 0.5;
                    sizeFound = false;

                    int strWidth, lines = 0, lineCharNum = 0, charHeight = 0, strHeight = 0;

                    // I'm crying
                    while (!sizeFound) {
                        font = new Font("Sans Serif", Font.BOLD, infoSize);
                        g2d.setFont(font);

                        // calculate total length of info
                        char[] chars = info.toCharArray();
                        strWidth = g2d.getFontMetrics().charsWidth(chars, 0, info.length() - 1);
                        // get char height
                        charHeight = g2d.getFontMetrics().getHeight();

                        if(strWidth > elementWidth * rangeX) {
                            lineCharNum = (int) ((elementWidth * rangeX) * info.length() / strWidth);
                            lines = 0;
                            if(strWidth % (elementWidth * rangeX) > 0) {
                                lines = (int) (strWidth / (elementWidth * rangeX) + 1);
                            }
                            else {
                                lines = (int) (strWidth / (elementWidth * rangeX));
                            }

                            strHeight = charHeight * lines;
                            if(strHeight > elementHeight * rangeY) {
                                sizeFound = true;
                            }
                        }
                        else {
                            lines = 1;
                            bounds = font.getStringBounds(info, fontRenderContext);

                            if(bounds.getWidth() > elementWidth * rangeX || bounds.getHeight() > elementHeight * rangeY) {
                                sizeFound = true;
                            }
                        }

                        infoSize ++;
                    }

                    // left top (x, y)
                    x = (elementWidth * (1 - rangeX)) / 2;
                    y = (elementHeight - strHeight) / 2 + elementHeight * nth;
                    ascent = 0;

                    // draw
                    String lineStr = "";
                    for (int i = 0; i < lines; i ++) {
                        // last line
                        if(i == lines - 1) {
                            lineStr = info.substring(i * lineCharNum, info.length());
                        }
                        else {
                            lineStr = info.substring(i * lineCharNum, (i + 1) * lineCharNum);
                        }

                        if (i > 0) {
                            y += charHeight;
                        }

                        g2d.drawString(lineStr, (int) x, (int) (y - ascent));
                    }
                    break;

                // ["picture", "type", image]
                case "picture":

                    BufferedImage image = (BufferedImage) element[2];

                    // calculate size
                    int imgWidth = image.getWidth(this);
                    int imgHeight = image.getHeight(this);

                    double ratio = 0.1;
                    range = 0.5;
                    sizeFound = false;

                    while (!sizeFound) {

                        if (imgWidth * ratio > elementWidth * range || imgHeight * ratio > elementHeight * range) {
                            sizeFound = true;
                        }

                        ratio += 0.05;
                    }

                    // left top (x, y)
                    x = (elementWidth - imgWidth * ratio) / 2;
                    y = (elementHeight - imgHeight * ratio) / 2 + elementHeight * nth;
                    ascent = 0;

                    g2d.drawImage(image, (int) x, (int) (y - ascent), (int) (imgWidth * ratio), (int) (imgHeight * ratio), this);

                    break;
            }

            nth ++;
        }

    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Color originalColor = g.getColor();

        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        drawElements(g2d);

        g2d.dispose();

        g.setColor(originalColor);
    }

}
