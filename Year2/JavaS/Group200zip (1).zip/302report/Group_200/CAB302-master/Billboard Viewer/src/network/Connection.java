package network;

import config.ConfigException;
import config.ServerConfig;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Connection {

    private Socket socket;
    private ObjectInputStream ois;
    private ObjectOutputStream oos;

    // target host name or address
    private String hostname;


    /**
     * Construct a connection on client side
     * @throws IOException Any of the usual Input/Output related exceptions
     * @throws ConfigException Server.props not valid
     */
    public Connection() throws IOException, ConfigException {

        // try read the config from Server.props
        ServerConfig config = new ServerConfig();

        // init with the config
        init(new Socket(config.getAddress(), config.getPort()));
    }

    /**
     * Construct a connection on server side
     * @param _socket a client socket
     * @throws IOException Any of the usual Input/Output related exceptions
     */
    public Connection(Socket _socket) throws IOException {
        init(_socket);
    }

    /**
     * Init the socket and stream
     * @param _socket the socket
     * @throws IOException
     */
    private void init(Socket _socket) throws IOException {

        this.socket = _socket;

        // set the io stream from socket
        oos = new ObjectOutputStream(socket.getOutputStream());
        ois = new ObjectInputStream(socket.getInputStream());

        // set the target host name from socket
        String _hostName = socket.getInetAddress().getHostName();
        hostname = "-" + _hostName + ": ";
    }


    // Server Side Method:

    /**
     * Listen a Request object from client
     * @return the Request from socket, return an EMPTY type if invalid Request received
     * @throws IOException Any of the usual Input/Output related exceptions
     * @throws ClassNotFoundException Class of a serialized object received cannot be found
     */
    public Request ListenRequest() throws IOException, ClassNotFoundException {

        Request request;

        // get object from stream
        Object o = ois.readObject();

        // check the object type

        // invalid type:
        if (!(o instanceof Request)) {
            // set an "EMPTY" type Request
            request =  new Request();
            // log the err
            System.out.println("-" + hostname + ": " + "invalid type of request recieved, converted to EMPTY request");
        }
        // valid type:
        else {
            // convert object to Request
            request = (Request) o;
        }

        // log the request
        System.out.println(hostname + request.toString());

        return request;
    }

    /**
     * Send a Response back to client
     * @param response the Response send back to client
     * @throws IOException Any of the usual Input/Output related exceptions
     */
    public void sendResponse(Response response) throws IOException {

        if(isClosed()) { return; }

        // sent object to stream
        oos.writeObject(response);
        oos.flush();
    }


    // Client Side Method:

    /**
     * Send a Request to Server
     * @param request the Request send to Server
     * @throws IOException Any of the usual Input/Output related exceptions
     */
    public void sendRequest(Request request) throws IOException {

        if(isClosed()) { return; }

        // sent object to stream
        oos.writeObject(request);
        oos.flush();
    }

    /**
     * Listen a Response object from server
     * @return the Response from socket, return an false Response if invalid Response received
     * @throws IOException  Any of the usual Input/Output related exceptions
     * @throws ClassNotFoundException Class of a serialized object received cannot be found
     */
    public Response listenResponse() throws IOException, ClassNotFoundException {

        Response response;

        // get object from stream
        Object o = ois.readObject();

        // check the object type

        // invalid type:
        if(!(o instanceof Response)) {
            // set a response with message
            response = new Response(false, "Invalid Response", null);
            // log the err
            System.out.println("Received object not type of Response");
        }
        // valid type
        else {
            // convert object to Response
            response = (Response) o;
        }

        // log the response
        System.out.println("Server: " + response.toString());

        return response;
    }


    /**
     * Getter of the hostname
     * @return the hostname
     */
    public String getHostname() {
        return this.hostname;
    }

    /**
     * Getter of the socket state
     * @return the state of socket
     */
    public boolean isClosed() {
        return socket.isClosed();
    }

    /**
     * Close the socket
     * @throws IOException Any of the usual Input/Output related exceptions
     */
    public void closeSocket() throws IOException {
        this.socket.close();
    }

    /**
     * Close the connection
     * @throws IOException Any of the usual Input/Output related exceptions
     */
    public void close() throws IOException {
        ois.close();
        oos.close();
    }

    /**
     * Close procedures on client side
     * @throws IOException Any of the usual Input/Output related exceptions
     * @throws ClassNotFoundException Class of a serialized object received cannot be found
     */
    public void closeClientSide() throws IOException, ClassNotFoundException {
        sendRequest(new Request("CLOSE"));
        listenResponse();
        closeSocket();
        close();
    }
}
