package billboard;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class BillboardData {


    public final String DEFAULT_BG_COLOR = "#FFFFFF";
    public final String DEFAULT_MESSAGE_COLOR = "#000000";
    public final String DEFAULT_INFO_COLOR = "#000000";
    public final boolean DO_PRINT_LOG = true;

    private String bgColor;
    // TODO: delete
    private Map<String,String> messages, pictures, informations;
    LinkedList<Object[]> elements;


    public BillboardData() {
        // TODO: delete
        messages = new HashMap<String, String>();
        pictures = new HashMap<String, String>();
        informations = new HashMap<String, String>();

        elements = new LinkedList<>();
    }

    public BillboardData(Document xmlDoc) {
        this();
        this.parse(xmlDoc);
    }

    public BillboardData(String xmlStr) {
        this();
        this.parse(xmlStr);
    }


    //------------Start Getter and setters

    public Color getBGColor() {
        return hexToColor(bgColor);
    }

    public void setBGColor(String bgColor) {
        this.bgColor = bgColor;
    }

    public LinkedList<Object[]> getElements() { return elements; }


    // TODO: ReDo add() and remove()
    public void addMessage(String color, String content) {}

    public boolean removeMessage(String color, String content) {
        // TODO:
        return false;
    }


    //------------End of getter and setters

    public void parse(String xmlStr) {

        try {
            InputStream is = new ByteArrayInputStream(xmlStr.getBytes());

            DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();

            Document document = documentBuilder.parse(is);

            this.parse(document);

            is.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void parse(Document xmlDoc) {


        // Creating NodeLists.
        Node rootNode = xmlDoc.hasChildNodes() ? xmlDoc.getChildNodes().item(0) : xmlDoc.createTextNode("billboard");
        NodeList elementNodes = rootNode.getChildNodes();

        //Getting XML's background colour
        String bgColor = rootNode.getAttributes().getLength() != 0 ? rootNode.getAttributes().item(0).getTextContent() : DEFAULT_BG_COLOR;
        this.bgColor = bgColor;

        if(DO_PRINT_LOG) System.out.println("\nBG color : " + bgColor);

        // Iterating Elements
        for (int i = 0; i < elementNodes.getLength(); i ++) {

            Node node = elementNodes.item(i);

            if(node instanceof Element) {

                Element element = (Element) node;

                String elementName = element.getTagName();
                String elementAttrName = element.getAttributes().getLength() != 0 ?
                    element.getAttributes().item(0).getNodeName() : "none";
                String elementAttr = element.getAttributes().getLength() != 0 ?
                        element.getAttributes().item(0).getTextContent() : "none";
                String elementContent = element.getTextContent();

                switch (elementName) {
                    // ["message", Color, "content"]
                    case "message":
                        elements.add(new Object[]{"message", hexToColor(elementAttr), elementContent});
                        if(DO_PRINT_LOG) System.out.println("message color : " + (elementAttr.equals("none") ? DEFAULT_MESSAGE_COLOR : elementAttr)  + "\nmessage content : " + elementContent);
                        break;
                    // ["information", Color, "content"]
                    case "information":
                        elements.add(new Object[]{"information", hexToColor(elementAttr), elementContent});
                        if(DO_PRINT_LOG) System.out.println("information color : " + (elementAttr.equals("none") ? DEFAULT_INFO_COLOR : elementAttr) + "\ninformation content : " + elementContent);
                        break;
                    // ["picture", "type", image]
                    case "picture":

                        BufferedImage image = null;
                        String imgType = elementAttrName;
                        if(imgType.equals("url")) {
                            try {
                                image = ImageIO.read(new URL(elementAttr));
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                        else if(imgType.equals("data")){
                            byte[] imgBytes = Base64.getDecoder().decode(elementAttr);
                            try {
                                image = ImageIO.read(new ByteArrayInputStream(imgBytes));
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                        elements.add(new Object[]{"picture", elementAttrName, image});
                        if(DO_PRINT_LOG) System.out.println("picture type : " +  elementAttrName + "\npicture data : " + elementAttr);
                        break;
                }

            }
        }

    }

    private Color hexToColor(String hexColor) {

        Color result = Color.black;

        try {
            result = new Color(Integer.parseInt(hexColor.substring(1), 16));
        }
        catch (NumberFormatException e) {
            // TODO: throw billboard exception
            System.out.println(e.getStackTrace());
        }

        return result;
    }



    //Method when call clear all the data.
    public void reset(){
        messages.clear();
        pictures.clear();
        informations.clear();
        bgColor = null;
    }

}