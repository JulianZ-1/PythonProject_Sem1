import config.ConfigException;
import network.Connection;
import pages.HomePage;

import javax.swing.*;
import java.io.IOException;


public class Main {

    public static void main(String[] args) {

        // set looks
        try{
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

        } catch (Exception e) {
            e.printStackTrace();
        }


        // run
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new HomePage();
            }
        });

    }
}