package pages;

import billboard.BillboardData;
import billboard.BillboardDrawer;
import billboard.BillboardView;
import model.Billboard;
import network.Connection;
import network.Request;
import network.Response;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

/**
 * Page to Create new Billboards and edit existing ones
 */

//        Create/edit billboard: the Control Panel will send the Server a billboard’s name,
//        contents and a valid session token. The Server will then either create a new billboard
//        (if the name is not already in use) or replace the contents of that billboard with the new one.
//        (Permissions required: to create a billboard, must have “Create Billboards” permission. To edit own billboard,
//        as long as it is not currently scheduled, must have “Create Billboards” permission. To edit another
//        user’s billboard or edit a billboard that is currently scheduled, must have “Edit All Billboards” permission.)
public class CreatePage extends JFrame {

    public final int DEFAULT_WIDTH = 900;
    public final int DEFAULT_HEIGHT = 600;
    public final double VIEWER_SCALE = 0.7;
    private final String DEFAULT_XML = "<billboard background=\"#ffffff\">\n    <message colour=\"#000000\">Create your own billboard.</message>\n</billboard>";

    private JPanel rootPanel;

    private BillboardView billboardView;
    private BillboardData billboardData;
    private BillboardDrawer billboardDrawer;
    private Billboard record;

    private JButton deleteButton, addButton, editButton, exportButton, importButton, sendButton, button, testButton1, testButton2;
    private JLabel nameLabel, testLabel, errLabel;
    private JList<String> jList;
    private DefaultListModel<String> listModel;

    private Box topBox, rightBox, buttomBox, middleBox, buttomMiddleBox;

    private FileExplorerPage fileExplorerPage;

    private Connection connection;

    /**
     * Constructor used to create new billboard
     */
    public CreatePage() {
        record = new Billboard("Untitled",
                "",
                "<billboard background=\"#ffffff\">\n    <message colour=\"#000000\">Create your own billboard.</message>\n</billboard>",
                "",
                "",
                "0");

        billboardData = new BillboardData(record.getContent());

        initFrame();
    }

    private void initFrame() {

        int viewerW = (int)Math.floor(DEFAULT_WIDTH * VIEWER_SCALE),
                viewerH = (int)Math.floor(DEFAULT_HEIGHT * VIEWER_SCALE);

        billboardDrawer = new BillboardDrawer(100, 100, viewerW, viewerH);

        billboardView = billboardDrawer.draw(billboardData);

        setWindow();

        fileExplorerPage = new FileExplorerPage(this);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
    }

    // setters and getters

    public void setConnection(Connection c) {
        connection = c;
    }

    public void setBoard(Billboard board) {
        record.setContent(board.getContent());
        record.setCreator(connection.getUser().getName());
        record.setName(board.getName());
        billboardData = new BillboardData(record.getContent());
        repaintFrame();
    }

    public void addElement(Object[] _element) {
        billboardData.addElement(_element);
        repaintFrame();
    }

    public void setElementByIndex(Object[] _element, int index) {
        billboardData.setElementByIndex(_element, index);
        repaintFrame();
    }

    public void setXML(String xml) {
        billboardData = new BillboardData(xml);
        repaintFrame();
    }

    public void setBackground(Object color) {
        billboardData.setBGColor((String) color);
        repaintFrame();
    }

    public void setName(String _name) {
        record.setName(_name);
        repaintFrame();
    }

    public Object[] getElementByIndex(int index) {
        return billboardData.getElementByIndex(index);
    }

    private void setWindow(){
        setLocation(400, 300);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);

        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setTitle("Billboard Editer");

        setResizable(false);
        setVisible(false);


        rootPanel = new JPanel();

        nameLabel = new JLabel();
        nameLabel.setFont(new Font("Sans Serif", Font.BOLD, 20));

        topBox = Box.createHorizontalBox();
        topBox.add(nameLabel);
        topBox.add(Box.createHorizontalStrut(DEFAULT_WIDTH * 6 / 7));
        topBox.add(Box.createVerticalStrut(DEFAULT_WIDTH / 15));

        listModel = new DefaultListModel<String>();

        jList = new JList<>();
        jList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        jList.setPreferredSize(new Dimension(DEFAULT_WIDTH / 6, DEFAULT_HEIGHT / 2));
        jList.setModel(listModel);
        jList.setBorder(BorderFactory.createTitledBorder("Elements"));
        jList.setFont(new Font("Sans Serif", Font.PLAIN, 12));
        jList.setFixedCellWidth(DEFAULT_WIDTH / 6);
        jList.setFixedCellHeight(DEFAULT_HEIGHT / 23);
        jList.setBackground(new Color(255, 255, 255));

        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(this::actionPerformed);
        //deleteButton.setLocation(0,0);
//        deleteButton.setVerticalAlignment((int) CENTER_ALIGNMENT);
//        deleteButton.setPreferredSize(new Dimension(DEFAULT_WIDTH / 6, DEFAULT_HEIGHT / 20));
//        deleteButton.setBounds(0, 0, DEFAULT_WIDTH / 6, DEFAULT_HEIGHT / 20);
//        deleteButton.setMinimumSize(new Dimension(DEFAULT_WIDTH / 6, DEFAULT_HEIGHT / 20));

        addButton = new JButton("Add");
        addButton.addActionListener(this::actionPerformed);
//        addButton.setPreferredSize(new Dimension(DEFAULT_WIDTH / 6, DEFAULT_HEIGHT / 20));
//        addButton.setBounds(0, 0, DEFAULT_WIDTH / 6, DEFAULT_HEIGHT / 20);
//        addButton.setMinimumSize(new Dimension(DEFAULT_WIDTH / 6, DEFAULT_HEIGHT / 20));

        editButton = new JButton("Edit");
        editButton.addActionListener(this::actionPerformed);
//        editButton.setPreferredSize(new Dimension(DEFAULT_WIDTH / 6, DEFAULT_HEIGHT / 20));

        rightBox = Box.createVerticalBox();
        rightBox.add(jList);
        rightBox.add(Box.createHorizontalStrut(DEFAULT_WIDTH / 15));
        rightBox.add(Box.createVerticalStrut(DEFAULT_HEIGHT / 40));
        rightBox.add(addButton);
        rightBox.add(Box.createVerticalStrut(DEFAULT_HEIGHT / 40));
        rightBox.add(editButton);
        rightBox.add(Box.createVerticalStrut(DEFAULT_HEIGHT / 40));
        rightBox.add(deleteButton);

        middleBox = Box.createVerticalBox();
        middleBox.add(Box.createHorizontalStrut(DEFAULT_WIDTH / 70));

        importButton = new JButton("Import");
        importButton.addActionListener(this::actionPerformed);
//        importButton.setEnabled(false);

        exportButton = new JButton("Export");
        exportButton.addActionListener(this::actionPerformed);
//        exportButton.setEnabled(false);

        // for testing
        testLabel = new JLabel("Examples: ");

        button = new JButton("Base64");
        button.addActionListener(this::actionPerformed);

        testButton1 = new JButton("URLIMG");
        testButton1.addActionListener(this::actionPerformed);

        testButton2 = new JButton("TestInfo");
        testButton2.addActionListener(this::actionPerformed);
        // end testing

        buttomBox = Box.createHorizontalBox();
        buttomBox.add(importButton);
        buttomBox.add(exportButton);
        buttomBox.add(Box.createHorizontalStrut(DEFAULT_WIDTH / 50));
        buttomBox.add(testLabel);
        buttomBox.add(button);
        buttomBox.add(testButton1);
        buttomBox.add(testButton2);
        buttomBox.add(Box.createHorizontalStrut(DEFAULT_WIDTH / 5));

        errLabel = new JLabel("Err");
        errLabel.setForeground(new Color(255, 100, 122));
        errLabel.setVisible(false);

        buttomMiddleBox = Box.createVerticalBox();
        buttomMiddleBox.add(Box.createHorizontalStrut(DEFAULT_WIDTH));
        buttomMiddleBox.add(errLabel);
        buttomMiddleBox.add(Box.createVerticalStrut(DEFAULT_HEIGHT / 35));

        sendButton = new JButton("Send to Server");
        sendButton.addActionListener(this::actionPerformed);

        rootPanel.add(topBox);

        paintFrame();
    }

    private void paintFrame() {
        nameLabel.setText(record.getName());

        listModel.addElement("Name: " + record.getName());
        listModel.addElement("BG: " + billboardData.getBG());
        for(Object[] element: billboardData.getPureElements()) {
            listModel.addElement((String) element[0] + ": " + (String) element[2]);
        }

        rootPanel.add(billboardView);
        rootPanel.add(middleBox);
        rootPanel.add(rightBox);
        rootPanel.add(buttomMiddleBox);
        rootPanel.add(buttomBox);
        rootPanel.add(sendButton);
        add(rootPanel);

        rootPanel.revalidate();
        revalidate();
    }

    private void repaintFrame() {
        listModel.clear();

        rootPanel.remove(billboardView);
        rootPanel.remove(middleBox);
        rootPanel.remove(rightBox);
        rootPanel.remove(buttomMiddleBox);
        rootPanel.remove(buttomBox);
        rootPanel.remove(sendButton);
        remove(rootPanel);

        billboardView = billboardDrawer.draw(billboardData);

        paintFrame();
    }


    public void actionPerformed(ActionEvent e) {
        String eName = e.getActionCommand();
        int index = jList.getSelectedIndex();
//        System.out.println(index);
        errLabel.setVisible(false);

        switch (eName) {
            case "Base64":
                billboardData = new BillboardData(
                        "<billboard>\n" +
                                "    <message>Billboard with message and picture with data attribute</message>\n" +
                                "    <picture data=\"iVBORw0KGgoAAAANSUhEUgAAACAAAAAQCAIAAAD4YuoOAAAAKXRFWHRDcmVhdGlvbiBUaW1lAJCFIDI1IDMgMjAyMCAwOTowMjoxNyArMDkwMHlQ1XMAAAAHdElNRQfkAxkAAyQ8nibjAAAACXBIWXMAAAsSAAALEgHS3X78AAAABGdBTUEAALGPC/xhBQAAAS5JREFUeNq1kb9KxEAQxmcgcGhhJ4cnFwP6CIIiPoZwD+ALXGFxj6BgYeU7BO4tToSDFHYWZxFipeksbMf5s26WnAkJki2+/c03OzPZDRJNYcgVwfsU42cmKi5YjS1s4p4DCrkBPc0wTlkdX6bsG4hZQOj3HRDLHqh08U4Adb/zgEMtq5RuH3Axd45PbftdB2wO5OsWc7pOYaOeOk63wYfdFtL5qldB34W094ZfJ+4RlFldTrmW/ZNbn2g0of1vLHdZq77qSDCaSAsLf9kXh9w44PNoR/YSPHycEmbIOs5QzBJsmDHrWLPeF24ZkCe6ZxDCOqHcmxmsr+hsicahss+n8vYb8NHZPTJxi/RGC5IqbRwqH6uxVTX+5LvHtvT/V/R6PGh/iF4GHoBAwz7RD26spwq6Amh/AAAAAElFTkSuQmCC\" />\n" +
                                "</billboard>");
                nameLabel.setText("Base64");
                repaintFrame();
                break;
            case  "URLIMG":
                billboardData = new BillboardData(
                        "<billboard>\n" +
                                "    <picture url=\"https://cloudstor.aarnet.edu.au/plus/s/62e0uExNviPanZE/download\" />\n" +
                                "</billboard>");
                nameLabel.setText("URLIMG");
                repaintFrame();
                break;
            case  "TestInfo":
                billboardData = new BillboardData(
                        "<billboard>\n" +
                                "    <message>Billboard with message and info</message>\n" +
                                "    <information>Billboard with a message tag, an information tag, but no picture tag. The message is centred within the top half of the screen while the information is centred within the bottom half.</information>\n" +
                                "</billboard>");
                nameLabel.setText("TestInfo");
                repaintFrame();
                break;

            case "Delete":
                if (index > 1) {
                    try {
                        deleteButton.setEnabled(false);
                        billboardData.deleteElementByIndex(index - 2);
                    }
                    finally {
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                deleteButton.setEnabled(true);
                            }
                        });
                    }
                }
                else {
                    errLabel.setText("Choose an element to delete");
                    errLabel.setVisible(true);
                }
                repaintFrame();
                break;
            case  "Add":
                new EditElementPage(this);
                repaintFrame();
                break;
            case  "Edit":
                // Edit Name
                if (index == 0) {
                    new EditElementPage(this, "");
                }
                // Edit Bg
                else if (index == 1){
                    new EditElementPage(this, true);
                }
                // Edit Element
                else if (index > 1){
                    new EditElementPage(this, index - 2);
                }
                else {
                    errLabel.setText("Choose anything to edit");
                    errLabel.setVisible(true);
                }
                repaintFrame();
                break;

            case "Send to Server":
                record.setContent(billboardData.toXML());

                Billboard newBoard = new Billboard();
                newBoard.setName(record.getName());
                newBoard.setCreator(record.getCreator());
                newBoard.setContent(record.getContent());

                Response response = null;
                try {
                    connection.sendRequest(new Request("CREATE", "CreateBillboard", newBoard));
                    response = connection.listenResponse();
                } catch (IOException | ClassNotFoundException ioException) {
                    ioException.printStackTrace();
                }

                if (response.ok()) {
                    dispose();
                }
                else {
                    errLabel.setText(response.getMessage());
                    errLabel.setVisible(true);
                }

                repaintFrame();
                break;

            case  "Import":
                if(!fileExplorerPage.getAction().equals("Open File")) {
                    fileExplorerPage.dispose();
                    fileExplorerPage = new FileExplorerPage(this);
                }

                if(!fileExplorerPage.isVisible()) {
                    fileExplorerPage.setVisible(true);
                }
                else {
                    fileExplorerPage.toFront();
                }
                repaintFrame();
                break;
            case  "Export":
                if(!fileExplorerPage.getAction().equals("Save File")) {
                    fileExplorerPage.dispose();
                    fileExplorerPage = new FileExplorerPage(billboardData.toXML());
                }

                if(!fileExplorerPage.isVisible()) {
                    fileExplorerPage.setVisible(true);
                }
                else {
                    fileExplorerPage.toFront();
                }
                repaintFrame();
                break;
        }
    }


}
