package pages;

import model.User;
import network.Connection;
import network.Request;
import network.Response;
import utils.Authentication;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;


// Login request: the Control Panel will send the Server a username and hashed password (see: User Authentication).
// The Server will either send back an error or a valid session token. (Permissions required: none.)

// Get user permissions: the Control Panel will send the Server a username and valid session token.
// The Server will respond with a list of that user’s permissions.
// (Permissions required if a user is requesting their own details, none.
// To get details for other users, “Edit Users” permission is required.)

public class LoginPage extends JFrame{
    public final int DEFAULT_WIDTH = 450;
    public final int DEFAULT_HEIGHT = 350;
    public char[] password;
    public String username;


    private JPanel rootPanel;
    private JTextField UserName;
    private JPasswordField Password;
    private JButton button_Login;
    private JButton button_Cancel;
    private JLabel errLabel;

    private HomePage homePage;

    Connection connection;

    public LoginPage(HomePage frame){

        // set frame
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);

        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setLocationRelativeTo(null);    // set location to center
        setTitle("Control Panel Login");
        //Border thickBorder = new LineBorder(Color.Black, 1);
        //button_Login.setBorder(thickBorder);
        setResizable(false);
        setVisible(true);

        errLabel.setVisible(false);

        add(rootPanel);


        //
        // Send username and hashedPassword to the server and verified
        //

        // login button
        button_Login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Get the user name and password entered
                username = UserName.getText();
                password = Password.getPassword();

                // If username and password match the base, do the following
                User user = new User();
                Response response = null;

                try {
                    user.setName(username);
                    user.setPassword(Authentication.hash(String.valueOf(password)));
                    connection.sendRequest(new Request("READ", "LoginRequest", user));
                    response = connection.listenResponse();

                } catch (NoSuchAlgorithmException | IOException | ClassNotFoundException noSuchAlgorithmException) {
                    noSuchAlgorithmException.printStackTrace();
                }

                if(response.ok()) {
                    // set token first
                    connection.setToken(response.getMessage());
                    connection.setUser(user);

                    frame.setPermissions();
                    frame.setNameLabel(user.getName());
                    frame.setVisible(true);
                    setVisible(false);

                }
                else {
                    errLabel.setText("Please check you username or password");
                    errLabel.setVisible(true);
                }

            }
        });

        // cancel button
        button_Cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    connection.closeClientSide();
                } catch (IOException | ClassNotFoundException ioException) {
                    ioException.printStackTrace();
                }
                System.exit(0);
            }
        });

    }

    public void setConnection(Connection c) {
        connection = c;
    }


    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
