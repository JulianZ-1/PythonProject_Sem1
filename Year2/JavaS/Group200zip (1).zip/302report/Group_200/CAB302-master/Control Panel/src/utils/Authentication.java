package utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

//From Week 9 Assignment Q&A
public class Authentication {

    public static String bytesToString(byte[] hash){
        StringBuffer sb = new StringBuffer();
        for (byte b : hash){
            sb.append(String.format("%2x", b & 0xFF));
        }
        return sb.toString();
    }
    public static String hash(String Password) throws NoSuchAlgorithmException {
        MessageDigest md;
        md = MessageDigest.getInstance("SHA-256");
        byte[] hashedPassword = md.digest(Password.getBytes());
        return bytesToString(hashedPassword);
    }

    public static String Slated (String hashedPassword) throws NoSuchAlgorithmException {
        ////// Generate a slated string Haappens at the server
        MessageDigest md;
        md = MessageDigest.getInstance("SHA-256");
        Random rng = new Random();
        byte[] saltBytes = new byte[32];
        rng.nextBytes(saltBytes);
        String saltString = bytesToString(saltBytes);
        ////
        String saltedPassword = bytesToString(md.digest((hashedPassword + saltString).getBytes()));
        return saltedPassword;
    }
}
