package pages;

import model.User;
import network.Connection;
import network.Request;
import network.Response;
import utils.Authentication;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

// Set user password: the Control Panel will send the Server a username,
// hashed password. The Server will then change that user’s password and send back an acknowledgement.
// (Permissions required: if setting own password, none. To set the password of another user, “Edit Users”.)

public class ChangePasswordPage extends JFrame {
    // size of the page
    public final int DEFAULT_WIDTH = 300;
    public final int DEFAULT_HEIGHT = 350;

    private JPanel rootPanel;
    private JPasswordField confirmPassField;
    private JPasswordField newPassField;
    private JButton confirmButton;
    private JButton cancelButton;
    private JLabel usernameLabel;
    private JLabel errLabel;

    private Connection connection;

    private String username;

    public ChangePasswordPage() {

        // set frame
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);
        // set size
        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setLocationRelativeTo(null);    // set location to center
        setTitle("Change Password"); //title

        setResizable(false); // cannot be resized
        setVisible(false); //invisible unless be called

        add(rootPanel); // add the JPanel

        errLabel.setVisible(false);

        // cancel button to dispose the page
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        // confirm button to submit the info
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submit();
            }
        });
    }

    // set connection
    public void setConnection(Connection c) {
        connection = c;
    }

    // display the current user name
    public void setUser(String user) {
        username = user;
        usernameLabel.setText(username);
    }

    // function to pass the information
    private void submit() {
        errLabel.setVisible(false); //error label to display when error occur
        // if user has no permission
        if (username.toLowerCase().equals("admin") && username.toLowerCase().equals(connection.getUser().getName().toLowerCase())) {
            errLabel.setText("Cannot change yourself"); // error message label to warn the user
            errLabel.setVisible(true); //set the errorLabel to be visible
            return;
        }

        // string to get the password entered
        String new1 = String.valueOf(newPassField.getPassword());
        String new2 = String.valueOf(confirmPassField.getPassword());

        // if the passwords matches
        if (new1.equals(new2)) {
            Response response = null;
            User user = new User(); //create the user
            user.setName(username);
            try {
                user.setPassword(Authentication.hash(new1)); //hash the paswword

                connection.sendRequest(new Request("UPDATE", "SetPassword", user));
                response = connection.listenResponse();
            } catch (NoSuchAlgorithmException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
            if (response.ok()) {
                dispose();
            }
            else {
                errLabel.setText(response.getMessage());
                errLabel.setVisible(true);
            }
        }
        else {
            errLabel.setText("Please reconfirm your input");
            errLabel.setVisible(true);
        }
    }

}
