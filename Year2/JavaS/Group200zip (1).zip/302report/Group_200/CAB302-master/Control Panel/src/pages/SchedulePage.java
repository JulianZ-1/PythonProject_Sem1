package pages;

import model.Billboard;
import network.Connection;
import network.Request;
import network.Response;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;

// Schedule billboard: the Control Panel will send the Server a billboard name, time,
// duration and a valid session token (as well as any other information necessary, e.g. for handling recurrence.)
// The Server will then schedule
// the billboard to display at that time and send back an acknowledgement.
// (Permissions required: “Schedule Billboards”.)

// Remove billboard from schedule: the Control Panel will send the Server a billboard name,
// time and valid session token. The Server will then remove this showing of that billboard from
// the schedule and send back an acknowledgement. (Permissions required: “Schedule Billboards”.)
public class SchedulePage extends JFrame {

    public final int DEFAULT_WIDTH = 900;
    public final int DEFAULT_HEIGHT = 600;

    private JPanel rootPanel;
    //private JTable calenTable;
    private JPanel Calendar;
    private JList<String> displayJList;
    private JList<String> draftJList;
    private JButton confirmButton;
    private JButton cancelButton;
    private JComboBox comboBox1;
    private JComboBox<String> comboBox_mm;
    private JComboBox<String> comboBox_dd;
    private JComboBox comboBox_yy;
    private JComboBox comboBox_min;
    private JComboBox comboBox_hh;
    private JComboBox comboBox_yy_end;
    private JComboBox comboBox_min_end;
    private JComboBox<String> comboBox_mm_end;
    private JComboBox<String> comboBox_dd_end;
    private JComboBox comboBox_hh_end;
    private JTable table1;
    private JLabel boardNameLabel;
    private JLabel Start;
    private JLabel End;

    private boolean correct_time;
    private String startEntry, endEntry;
    private Connection connection;

    DefaultListModel<String> draftModel, displayModel;
    private ArrayList<Billboard> draftAList, displayAList;



    public void errorMess(){
        JOptionPane.showConfirmDialog(rootPanel,
                "Wrong time selection!",
                "Error",
                JOptionPane.CLOSED_OPTION);
    }

    public SchedulePage() {

        // set frame
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);

        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setLocationRelativeTo(null);    // set location to center
        setTitle("Billboard Scheduler");

        setResizable(false);
        setVisible(false);
        add(rootPanel);

        String[] date_S = {
                "01", "02", "03", "04", "05", "06", "07", "08", "09", "10",
                "11", "12", "12", "14", "15", "16", "17", "18", "19", "20",
                "21", "22", "23", "24", "25", "26", "27", "28", "29", "30",
                "31"
        };

        String[] date_E = {
                "01", "02", "03", "04", "05", "06", "07", "08", "09", "10",
                "11", "12", "12", "14", "15", "16", "17", "18", "19", "20",
                "21", "22", "23", "24", "25", "26", "27", "28", "29", "30",
                "31"
        };

        displayAList = new ArrayList<>();
        draftAList = new ArrayList<>();

        draftModel = new DefaultListModel<>();
        draftJList.setPreferredSize(new Dimension(DEFAULT_WIDTH / 4, DEFAULT_HEIGHT * 6 / 20));
        draftJList.setFixedCellWidth(DEFAULT_WIDTH /4);
        draftJList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        draftJList.setModel(draftModel);
        draftJList.addListSelectionListener(this::valueChanged);

        displayModel = new DefaultListModel<>();
        displayJList.setPreferredSize(new Dimension(DEFAULT_WIDTH / 4, DEFAULT_HEIGHT * 6 / 20));
        displayJList.setFixedCellWidth(DEFAULT_WIDTH /4);
        displayJList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        displayJList.setModel(displayModel);
        displayJList.addListSelectionListener(this::valueChanged);

        boardNameLabel.setText("");
        confirmButton.setEnabled(false);
        cancelButton.setEnabled(false);

        comboBox_mm.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {

                String selected_Mon = comboBox_mm.getItemAt(comboBox_mm.getSelectedIndex());
                comboBox_dd.removeAllItems();
                int numOfDays = 0;

                if (selected_Mon == "JAN" | selected_Mon == "MAR"| selected_Mon == "MAY"|
                        selected_Mon == "JUL"| selected_Mon == "AUG"| selected_Mon == "OCT"|
                        selected_Mon == "DEC") {
                    numOfDays = 31;

                }
                else if (selected_Mon == "FEB"){
                    numOfDays = 28;

                }
                else if(selected_Mon == "MM"){
                    comboBox_dd.addItem("DD");
                }

                else{
                    numOfDays = 30;
                }
                for (int i = 0; i < numOfDays; i++) {
                    comboBox_dd.addItem(date_S[i]);
                }

//                if (selected_Mon != "MM"){
//                    comboBox_mm_end.setSelectedItem(selected_Mon);
//                }
            }
        });

        comboBox_mm_end.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                String selected_Mon_end = comboBox_mm_end.getItemAt(comboBox_mm_end.getSelectedIndex());
                comboBox_dd_end.removeAllItems();

                int numOfDays = 0;

                if (selected_Mon_end == "JAN" | selected_Mon_end == "MAR"| selected_Mon_end == "MAY"|
                        selected_Mon_end == "JUL"| selected_Mon_end == "AUG"| selected_Mon_end == "OCT"|
                        selected_Mon_end == "DEC") {
                    numOfDays = 31;

                }
                else if (selected_Mon_end == "FEB"){
                    numOfDays = 28;

                }
                else if(selected_Mon_end == "MM"){
                    comboBox_dd_end.addItem("DD");
                }
                else{
                    numOfDays = 30;
                }
                for (int i = 0; i < numOfDays; i++) {
                    comboBox_dd_end.addItem(date_E[i]);
                }
            }
        });

        cancelButton.addActionListener(this::actionPerformed);
        confirmButton.addActionListener(this::actionPerformed);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowActivated(WindowEvent e) {
                freshData();
                super.windowActivated(e);
            }
        });
    }

    public void actionPerformed(ActionEvent e) {
        String eName = e.getActionCommand();
        int draftIndex = draftJList.getSelectedIndex();
        int displayIndex = displayJList.getSelectedIndex();

        switch (eName) {
            case "Confirm":

                if (!verifyTimeEntry()){
                    errorMess();
                }
                else{
                    Billboard billboard = new Billboard();
                    billboard.setName(draftAList.get(draftIndex).getName());
                    billboard.setCreated(draftAList.get(draftIndex).getCreated());
                    billboard.setStart(startEntry);
                    billboard.setEnd(endEntry);
                    Response response = null;

                    try {
                        connection.sendRequest(new Request("CREATE", "ScheduleBillboard", billboard));
                        response = connection.listenResponse();
                    } catch (IOException | ClassNotFoundException ioException) {
                        ioException.printStackTrace();
                    }

                    freshData();
                }

                break;
            case "Cancel":
                comboBox_mm.setSelectedIndex(0);
                comboBox_dd.setSelectedIndex(0);
                comboBox_yy.setSelectedIndex(0);
                comboBox_min.setSelectedIndex(0);
                comboBox_hh.setSelectedIndex(0);
                comboBox_yy_end.setSelectedIndex(0);
                comboBox_min_end.setSelectedIndex(0);
                comboBox_mm_end.setSelectedIndex(0);
                comboBox_dd_end.setSelectedIndex(0);
                comboBox_hh_end.setSelectedIndex(0);

                Billboard billboard = new Billboard();
                billboard.setName(displayAList.get(displayIndex).getName());
                Response response = null;

                try {
                    connection.sendRequest(new Request("DELETE", "RemoveSchedule", billboard));
                    response = connection.listenResponse();
                } catch (IOException | ClassNotFoundException ioException) {
                    ioException.printStackTrace();
                }
                freshData();
                break;
        }
    }

    public void valueChanged(ListSelectionEvent e) {
        int draftIndex = draftJList.getSelectedIndex();
        int displayIndex = displayJList.getSelectedIndex();


        if (draftIndex >= 0) {
            boardNameLabel.setText(draftAList.get(draftIndex).getName());
            confirmButton.setEnabled(true);
            cancelButton.setEnabled(false);
        }
        else if (displayIndex >= 0) {
            boardNameLabel.setText(displayAList.get(displayIndex).getName());
            confirmButton.setEnabled(false);
            cancelButton.setEnabled(true);
        }
        else {
            boardNameLabel.setText("");
            confirmButton.setEnabled(false);
            cancelButton.setEnabled(false);
        }
    }


    public void setConnection(Connection c) {
        connection = c;
    }

    private void freshData() {
        // clear
        draftModel.clear();
        draftAList.clear();
        displayModel.clear();
        displayAList.clear();
        // fetch
        Response boardResponse = null;
        ArrayList<Billboard> billboardList;
        // get whole list
        try {
            connection.sendRequest(new Request("READ", "ListBillboard"));
            boardResponse = connection.listenResponse();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        // gotten
        if(boardResponse.ok()) {
            billboardList = (ArrayList<Billboard>) boardResponse.getData();

            // get schedule list
            Response scheduleRes = null;
            ArrayList<Billboard> scheduleList;
            try {
                connection.sendRequest(new Request("READ", "ViewSchedule"));
                scheduleRes = connection.listenResponse();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
            // gotten
            if (scheduleRes.ok()) {
                scheduleList = (ArrayList<Billboard>) scheduleRes.getData();
                // compare and set listModels
                for (Billboard billboard : billboardList) {
                    boolean has = false;
                    for (Billboard cillboard : scheduleList) {
                        if (cillboard.getName().equals(billboard.getName())) {
                            has = true;
                        }
                    }
                    if (has) {
                        displayModel.addElement(billboard.getName());
                        displayAList.add(billboard);
                        continue;
                    }
                    else {
                        draftModel.addElement(billboard.getName());
                        draftAList.add(billboard);
                        continue;
                    }
                }
            }
            else {
                // TODO:
            }
        }
        else {
            // TODO:
        }
    }

    private boolean verifyTimeEntry() {
        int selected_yy_start = comboBox_yy.getSelectedIndex();
        int selected_yy_end = comboBox_yy_end.getSelectedIndex();
        int selected_Mon_start = comboBox_mm.getSelectedIndex();
        int selected_Mon_end = comboBox_mm_end.getSelectedIndex();
        int selected_dd_start = comboBox_dd.getSelectedIndex();
        int selected_dd_end = comboBox_dd_end.getSelectedIndex();
        int selected_hour_start = comboBox_hh.getSelectedIndex();
        int selected_hour_end = comboBox_hh_end.getSelectedIndex();
        int selected_min_start = comboBox_min.getSelectedIndex();
        int selected_min_end = comboBox_min_end.getSelectedIndex();

        if (selected_Mon_start == 0 |selected_Mon_end == 0 | selected_hour_start == 0 |
                selected_hour_end== 0 |selected_min_start == 0 |selected_min_end==0){
            //errorMess();
            correct_time = false;
        }
        if (selected_yy_start == selected_yy_end){
            if(selected_Mon_start == selected_Mon_end){
                if (selected_dd_start==selected_dd_end){
                    if(selected_hour_start==selected_hour_end){
                        if(selected_min_start>=selected_min_end){
                            correct_time = false;
                        }
                        else{
                            correct_time = true;
                        }

                    }
                    else if(selected_hour_start > selected_hour_end) {
                        correct_time = false;
                    }
                    else{
                        correct_time = true;
                    }

                }
                else if (selected_dd_start > selected_dd_end){
                    correct_time = false;
                }
                else{
                    correct_time = true;
                }

            }
            else if (selected_Mon_start > selected_Mon_end){
                correct_time = false;
            }

            else{
                correct_time = true;
            }
        }
        else if (selected_yy_start >selected_yy_end){
            correct_time = false;
        }
        else{
            correct_time = true;
        }

        if(correct_time) {
            String[] mm = new String[]{"MM", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};

            String mm_start = mm[selected_Mon_start];
            String mm_end = mm[selected_Mon_end];

            String start_time = comboBox_yy.getItemAt(selected_yy_start) + "-" + mm_start
                    + "-" + comboBox_dd.getItemAt(selected_dd_start)+ "T" + comboBox_hh.getItemAt(selected_hour_start) +
                    "-" +comboBox_min.getItemAt(selected_min_start) + "-00";

            String end_time = comboBox_yy_end.getItemAt(selected_yy_end) + "-" + mm_end
                    + "-" + comboBox_dd_end.getItemAt(selected_dd_end)+ "T" + comboBox_hh_end.getItemAt(selected_hour_end) +
                    "-" +comboBox_min_end.getItemAt(selected_min_end) + "-00";

            startEntry = start_time;
            endEntry = end_time;
        }

        return correct_time;
    }


}
