package pages;


import network.Connection;
import network.Request;
import network.Response;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;

// List users: the Control Panel will send the Server a valid session
// token and the Server will respond with a list of usernames
// (and any other information your team feels is appropriate.) (Permissions required: “Edit Users”.)

public class EditPage extends JFrame {
    public final int DEFAULT_WIDTH = 900;
    public final int DEFAULT_HEIGHT = 600;

    private JPanel rootPanel;
    private JButton editPermissionButton;
    private JButton createNewUserButton;
    private JButton changePasswordButton;
    private JList<String> userJList;
    private JLabel errLabel;

    CreateUserPage createUserPage;
    ChangePasswordPage changePasswordPage;
    EditPermissionPage editPermissionPage;

    DefaultListModel<String> model;

    Connection connection;

    public EditPage(CreateUserPage createUserPage, ChangePasswordPage changePasswordPage, EditPermissionPage editPermissionPage) {

        // pass in page ref
        this.createUserPage = createUserPage;
        this.changePasswordPage = changePasswordPage;
        this.editPermissionPage = editPermissionPage;

        // set frame
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);

        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setLocationRelativeTo(null);    // set location to center
        setTitle("User Editor");


        setResizable(false);
        setVisible(false);

        editPermissionButton.setPreferredSize(new Dimension(40, 40));
        changePasswordButton.setPreferredSize(new Dimension(40, 40));
        createNewUserButton.setPreferredSize(new Dimension(40, 40));

        add(rootPanel);

        model = new DefaultListModel<>();
        userJList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        userJList.setModel(model);

        // add listener
        editPermissionButton.addActionListener(this::actionPerformed);
        changePasswordButton.addActionListener(this::actionPerformed);
        createNewUserButton.addActionListener(this::actionPerformed);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowActivated(WindowEvent e) {
                freshData();
                super.windowActivated(e);

            }
        });

    }

    public void setConnection(Connection c) {
        connection = c;
    }

    private void freshData() {
        try {
            connection.sendRequest(new Request("READ", "ListUsers"));
            Response response = connection.listenResponse();
            if (response.ok()) {
                errLabel.setVisible(false);
                // update list
                ArrayList<String> users = (ArrayList<String>) response.getData();
                model.clear();
                for (String u : users) {
                    model.addElement(u);
                }
            }
            else {
                model.clear();
                errLabel.setText("Failed to get list");
                errLabel.setVisible(true);
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    public void actionPerformed(ActionEvent e) {
        String eName = e.getActionCommand();
        int index = userJList.getSelectedIndex();
        System.out.println(index);
        System.out.println(eName);

        errLabel.setVisible(false);

        switch (eName) {
            case "Edit Permission":
                if (index < 0) {
                    errLabel.setText("Please select a user");
                    errLabel.setVisible(true);
                }
                if (index >= 0) {
                    if (editPermissionPage.isVisible()) {
                        editPermissionPage.toFront();
                    } else {
                        editPermissionPage.setUser(userJList.getSelectedValue());
                        editPermissionPage.setVisible(true);
                    }
                }
                break;
            case "Change Password":
                if (index < 0) {
                    errLabel.setText("Please select a user");
                    errLabel.setVisible(true);
                }
                if (index >= 0) {
                    if (changePasswordPage.isVisible()) {
                        changePasswordPage.toFront();
                    } else {
                        changePasswordPage.setUser(userJList.getSelectedValue());
                        changePasswordPage.setVisible(true);
                    }
                }
                break;
            case "Create New User":
                if (createUserPage.isVisible()) {
                    createUserPage.toFront();
                } else {
                    createUserPage.setVisible(true);
                }
                break;

        }
    }


}
