package pages;

import model.User;
import network.Connection;
import network.Request;
import network.Response;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

// Get user permissions: the Control Panel will send the Server a username and valid session token.
// The Server will respond with a list of that user’s permissions.
// (Permissions required if a user is requesting their own details, none.
// To get details for other users, “Edit Users” permission is required.)

// the Control Panel will send the Server a username, a list of permissions and a valid session token.
// The Server will then change that user’s permissions to match the new list and send back an acknowledgement.
// (Permissions required: “Edit Users”. Note that no user has the ability to remove their own “Edit Users” permission.)

public class EditPermissionPage extends JFrame {
    public final int DEFAULT_WIDTH = 450;
    public final int DEFAULT_HEIGHT = 350;
    private JButton cancelButton;
    private JPanel rootPanel;
    private JCheckBox createBillboardsCheckBox;
    private JCheckBox scheduleBillboardsCheckBox;
    private JCheckBox editBillboardsCheckBox;
    private JCheckBox editUsersCheckBox;
    private JButton confirmButton;
    private JLabel usernameLabel;
    private JLabel errLabel;

    private Connection connection;

    private String username;

    public EditPermissionPage() {

        // set frame
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);

        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setLocationRelativeTo(null);    // set location to center
        setTitle("Edit Permissions");

        setResizable(false);
        setVisible(false);

        add(rootPanel);

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submit();
            }
        });

    }

    public void setConnection(Connection c) {
        connection = c;
    }

    public void setUser(String u) {
        username = u;
        usernameLabel.setText(username);
        freshData();
    }

    private void freshData() {
        Response response = null;
        User user = new User();
        user.setName(username);
        try {
            connection.sendRequest(new Request("READ", "GetUserPermissions", user));
            response = connection.listenResponse();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        if (response.ok()) {
            errLabel.setVisible(false);
            ArrayList<String> permissions = (ArrayList<String>) response.getData();
            createBillboardsCheckBox.setSelected(permissions.get(2).equals("1"));
            editBillboardsCheckBox.setSelected(permissions.get(1).equals("1"));
            editUsersCheckBox.setSelected(permissions.get(0).equals("1"));
            scheduleBillboardsCheckBox.setSelected(permissions.get(3).equals("1"));
        }
        else {
            errLabel.setText("Failed to get permissions");
            errLabel.setVisible(true);
        }
    }

    private void submit() {
        // not allowed to change yourself
        if (username.toLowerCase().equals("admin") && username.toLowerCase().equals(connection.getUser().getName().toLowerCase())) {
            errLabel.setText("Cannot change yourself");
            errLabel.setVisible(true);
        }
        else {
            User user = new User();
            user.setName(username);
            user.setCreateBillboard(createBillboardsCheckBox.isSelected() ? "1" : "0");
            user.setEditAllBillboard(editBillboardsCheckBox.isSelected() ? "1" : "0");
            user.setEditUsers(editUsersCheckBox.isSelected() ? "1" : "0");
            user.setScheduleBillboard(scheduleBillboardsCheckBox.isSelected() ? "1" : "0");

            Response response = null;

            try {
                connection.sendRequest(new Request("UPDATE", "SetUserPermissions", user));
                response = connection.listenResponse();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }

            if(response.ok()){
                dispose();
            }
            else {
                errLabel.setText("Failed to update, please retry");
                errLabel.setVisible(true);
            }
        }
    }

}
