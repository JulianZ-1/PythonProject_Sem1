package pages;

import utils.ColorConverter;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

public class EditElementPage extends JFrame{
    public final int DEFAULT_WIDTH = 300;
    public final int DEFAULT_HEIGHT = 350;

    private JPanel rootPanel;
    private Box topBox, secondBox, thirdBox, fourthBox, buttomBox;

    private JLabel typeLabel, contentLabel, colorLabel, dataTypeLabel;
    private JComboBox<String> typeComboBox, dataTypeComboBox;
    private JScrollPane contentScrollArea;
    private JTextArea contentArea;
    private JButton cancelButton, confirmButton, colorButton;

    private String action;
    private Object[] element;
    int index;
    private Color color;

    CreatePage parentPage;
    ColorPickingPage childPage;

    // ADD
    public EditElementPage(CreatePage createPage) {
        parentPage = createPage;
        action = "Add elements";
        element = new Object[] {"message", "", ""};
        color = Color.BLACK;
        setWindow();
    }

    // EDIT ELEMENT
    public EditElementPage(CreatePage createPage, int _index) {
        parentPage = createPage;
        action = "Edit elements";
        element = parentPage.getElementByIndex(_index);
        index = _index;
        setWindow();
    }

    // EDIT BG
    public EditElementPage(CreatePage createPage, boolean abc) {
        parentPage = createPage;
        action = "Edit background";
        element = new Object[] {"background", "", ""};
        setWindow();
    }

    // Edit Name
    public EditElementPage(CreatePage createPage, String abc) {
        parentPage = createPage;
        action = "Edit Name";
        element = new Object[] {"billboard name", "", ""};
        setWindow();
    }


    private void setWindow() {

        // set childPage
        childPage = new ColorPickingPage(this);

        // set frame
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);

        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setLocationRelativeTo(null);    // set location to center
        setTitle(action);

        setResizable(false);
        setVisible(true);

        rootPanel = new JPanel();
        add(rootPanel);

        typeLabel = new JLabel("Type: ");

        typeComboBox = new JComboBox<>();
        typeComboBox.addItem("message");
        typeComboBox.addItem("information");
        typeComboBox.addItem("picture");
        typeComboBox.addActionListener(this::actionPerformed);

        topBox = Box.createHorizontalBox();
        topBox.add(typeLabel);
        typeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        if (action.equals("Add elements")) {
            topBox.add(typeComboBox);
        }
        else {
            topBox.add(new JLabel((String) element[0]));
        }

        contentLabel = new JLabel("Content: ");
        contentArea = new JTextArea();
        contentArea.setPreferredSize(new Dimension(DEFAULT_WIDTH * 7 / 12, DEFAULT_HEIGHT / 4));
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);
        contentArea.setText((String) element[2]);

//        contentScrollArea = new JScrollPane(contentArea);
//        contentScrollArea.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
//        contentScrollArea.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        secondBox = Box.createHorizontalBox();
        secondBox.add(contentLabel);
        secondBox.add(contentArea);

        colorLabel = new JLabel("Color: ");
        colorButton = new JButton("Pick a color");
        colorButton.addActionListener(this::actionPerformed);

        thirdBox = Box.createHorizontalBox();
        thirdBox.add(colorLabel);
        thirdBox.add(colorButton);

        dataTypeLabel = new JLabel("Data Type: ");
        dataTypeComboBox = new JComboBox<>();
        dataTypeComboBox.addItem("url");
        dataTypeComboBox.addItem("base64");
        dataTypeComboBox.addActionListener(this::actionPerformed);

        fourthBox = Box.createHorizontalBox();
        fourthBox.add(dataTypeLabel);
        fourthBox.add(dataTypeComboBox);

        confirmButton = new JButton("Confirm");
        confirmButton.addActionListener(this::actionPerformed);

        cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(this::actionPerformed);

        buttomBox = Box.createHorizontalBox();
        buttomBox.add(confirmButton);
        buttomBox.add(Box.createHorizontalStrut(DEFAULT_WIDTH / 40));
        buttomBox.add(cancelButton);

        rootPanel.add(Box.createVerticalStrut(DEFAULT_HEIGHT / 20));
        rootPanel.add(Box.createHorizontalStrut(DEFAULT_WIDTH));
        rootPanel.add(topBox);
        rootPanel.add(Box.createHorizontalStrut(DEFAULT_WIDTH));
        rootPanel.add(Box.createVerticalStrut(DEFAULT_HEIGHT / 20));
        rootPanel.add(secondBox);
        rootPanel.add(Box.createHorizontalStrut(DEFAULT_WIDTH));
        rootPanel.add(Box.createVerticalStrut(DEFAULT_HEIGHT / 20));
        rootPanel.add(thirdBox);
        rootPanel.add(Box.createHorizontalStrut(DEFAULT_WIDTH));
        rootPanel.add(Box.createVerticalStrut(DEFAULT_HEIGHT / 20));
        rootPanel.add(fourthBox);
        rootPanel.add(Box.createHorizontalStrut(DEFAULT_WIDTH));
        rootPanel.add(Box.createVerticalStrut(DEFAULT_HEIGHT / 20));
        rootPanel.add(buttomBox);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                childPage.dispose();
                dispose();
            }
        });


        freshComp();
    }

    private void freshComp() {
        // TODO:
        switch ((String) element[0]) {
            case "message":
            case "information":
                colorLabel.setEnabled(true);
                colorButton.setEnabled(true);
                dataTypeLabel.setEnabled(false);
                dataTypeComboBox.setEnabled(false);
                break;
            case "picture":
                colorLabel.setEnabled(false);
                colorButton.setEnabled(false);
                dataTypeLabel.setEnabled(true);
                dataTypeComboBox.setEnabled(true);
                break;
            case "background":
                dataTypeLabel.setEnabled(false);
                dataTypeComboBox.setEnabled(false);
                contentLabel.setEnabled(false);
                contentArea.setEnabled(false);
                break;
            case "billboard name":
                colorLabel.setEnabled(false);
                colorButton.setEnabled(false);
                dataTypeLabel.setEnabled(false);
                dataTypeComboBox.setEnabled(false);
        }
    }

    private void freshData() {
        if(element[0].equals("picture")) {
            element[1] = dataTypeComboBox.getSelectedItem();
        }
        else if (element[0].equals("billboard name")) {

        }
        else {
            if (color != null) {
                element[1] = ColorConverter.colorToHex(color);
            }
        }
        element[2] = contentArea.getText();
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public void actionPerformed(ActionEvent e) {
        String eName = e.getActionCommand();
//        System.out.println(eName);

        switch (eName) {
            case "comboBoxChanged":
                if(action.equals("Add elements")) {
                    element[0] = typeComboBox.getSelectedItem();
                    freshComp();
                }
                freshData();
                break;
            case "Pick a color":
                if(!childPage.isVisible()) {
                    childPage.setVisible(true);
                }
                else {
                    childPage.toFront();
                }
                break;
            case "Cancel":
                childPage.dispose();
                dispose();
                break;

            case "Confirm":
                freshData();
                switch (action) {
                    case "Edit elements":
                        parentPage.setElementByIndex(element, index);
                        break;
                    case "Add elements":
                        parentPage.addElement(element);
                        break;
                    case "Edit background":
                        parentPage.setBackground(element[1]);
                        break;
                    case "Edit Name":
                        parentPage.setName((String) element[2]);
                        break;
                }
                childPage.dispose();
                dispose();
                break;
        }

//        System.out.println(element[0] + " " + element[1] + " " + element[2]);
    }

}
