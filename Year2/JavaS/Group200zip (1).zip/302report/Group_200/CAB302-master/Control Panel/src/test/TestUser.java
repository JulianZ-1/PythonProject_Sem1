package test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import model.User;
import org.junit.jupiter.api.Test;

public class TestUser {

    @Test
    public void test(){
        User user = new User("name","password","salt","createBillboard",
                "editAllBillboard","editUsers","scheduleBillboard");
        assertEquals("name", user.getName());
        assertEquals("password", user.getPassword());
        assertEquals("createBillboard", user.getCreateBillboard());
        assertEquals("editAllBillboard", user.getEditAllBillboard());
        assertEquals("editUsers", user.getEditUsers());
        assertEquals("scheduleBillboard", user.getName());

    }

    @Test
    public void test1(){
        User user = new User();
        user.setName("name");
        user.setPassword("password");
        user.setCreateBillboard("createBillboard");
        assertEquals("name", user.getName());
        assertEquals("password", user.getPassword());
        assertEquals("createBillboard", user.getCreateBillboard());

    }

    @Test
    public void test2(){
        User user = new User();
        user.setEditAllBillboard("editAllBillboard");
        user.setEditUsers("editUsers");
        user.setScheduleBillboard("scheduleBillboard");
        assertEquals("editAllBillboard", user.getEditAllBillboard());
        assertEquals("editUsers", user.getEditUsers());
        assertEquals("scheduleBillboard", user.getName());

    }



}
