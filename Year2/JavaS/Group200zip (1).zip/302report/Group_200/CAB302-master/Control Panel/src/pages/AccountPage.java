package pages;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class AccountPage extends JFrame {
    // size of the page
    public final int DEFAULT_WIDTH = 400;
    public final int DEFAULT_HEIGHT = 500;
    public boolean logout = false;

    private JButton logOutButton;
    private JPanel rootPanel;
    private JButton changePasswordButton;
    private JLabel usernameLabel;
    private JLabel expireLabel;
    private JLabel p1Label;
    private JLabel p2Label;
    private JLabel p3Label;
    private JLabel p4Label;
    private LoginPage loginPage;


    public AccountPage(HomePage frame, ChangePasswordPage changePasswordPage) {

        // set frame
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);
        //set the size
        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setLocationRelativeTo(null);    // set location to center
        setTitle("Account detail"); //title

        setResizable(false); //cannot be resized
        setVisible(false); //cannot be visible unless called

        logOutButton.setPreferredSize(new Dimension(40, 40)); // change the size of the button

        add(rootPanel); //add the JPanel to the frame

        // add a listener to the log out button
        logOutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Set the frame to be not visible
                frame.setVisible(false);

                // modern style of the GUI
                try{
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (IllegalAccessException | UnsupportedLookAndFeelException | ClassNotFoundException | InstantiationException ex) {
                    ex.printStackTrace();
                }
                // TODO: login
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        frame.close(); // Close the existing pages when log out
                        new HomePage(); // Call a new homepage to restart
                    }
                });

            }
        });
    }

    //set the username to be occurred in the billboard
    public void setUsername(String username) {
        usernameLabel.setText(username);
    }

    // Reveal the permission of the user
    public void setPermissions(boolean[] booleans) {
        p1Label.setEnabled(booleans[2]);
        p2Label.setEnabled(booleans[1]);
        p3Label.setEnabled(booleans[0]);
        p4Label.setEnabled(booleans[3]);
    }

    //set a label to display expire time
    public void setExpire(String expire) {
        expireLabel.setText(expire);
    }
}
