package billboard;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import utils.ColorConverter;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class BillboardData {


    public final String DEFAULT_BG_COLOR = "#FFFFFF";
    public final String DEFAULT_MESSAGE_COLOR = "#000000";
    public final String DEFAULT_INFO_COLOR = "#000000";
    public final boolean DO_PRINT_LOG = false;

    private String bgColor;

    LinkedList<Object[]> elements, pureElements;


    public BillboardData() {
        elements = new LinkedList<>();
        pureElements = new LinkedList<>();
    }

    public BillboardData(Document xmlDoc) {
        this();
        this.parse(xmlDoc);
    }

    public BillboardData(String xmlStr) {
        this();
        this.parse(xmlStr);
    }


    //------------Start Getter and setters

    public String getBG() {
        return bgColor;
    }

    public Color getBGColor() {
        return ColorConverter.hexToColor(bgColor);
    }

    public void setBGColor(String bgColor) {
        this.bgColor = bgColor;
    }

    public LinkedList<Object[]> getElements() { return elements; }

    public LinkedList<Object[]> getPureElements() { return pureElements; }

    public Object[] getElementByIndex(int index) {
        return pureElements.get(index);
    }

    public void setElementByIndex(Object[] _element, int index) {
        String type = (String) _element[0];
        String attr = (String) _element[1];
        String content = (String) _element[2];
        switch (type) {
            case "message":
                setMessageByIndex(attr, content, index);
                break;
            case "information":
                setInfoByIndex(attr, content, index);
                break;
            case "picture":
                setPictureByIndex(attr, content, index);
                break;
        }
    }

    public void deleteElementByIndex(int index) {
        pureElements.remove(index);
        elements.remove(index);
    }

    public void addElement(Object[] element) {
        String type = (String) element[0];
        String attr = (String) element[1];
        String content = (String) element[2];
        switch (type) {
            case "message":
                addMessage(attr, content);
                break;
            case "information":
                addInfo(attr, content);
                break;
            case "picture":
                addPicture(attr, content);
                break;
        }

    }


    public void addMessage(String color, String content) {
        elements.add(new Object[]{"message", ColorConverter.hexToColor(color), content});
        pureElements.add(new Object[] {"message", color, content});
    }

    public void addInfo(String color, String content) {
        elements.add(new Object[]{"information", ColorConverter.hexToColor(color), content});
        pureElements.add(new Object[] {"information", color, content});
    }

    public void addPicture(String type, String data) {
        BufferedImage image = null;
        if(type.equals("url")) {
            try {
                image = ImageIO.read(new URL(data));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else if(type.equals("data")){
            byte[] imgBytes = Base64.getDecoder().decode(data);
            try {
                image = ImageIO.read(new ByteArrayInputStream(imgBytes));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        elements.add(new Object[]{"picture", type, image});
        pureElements.add(new Object[]{"picture", type, data});
    }

    public void setMessageByIndex(String color, String content, int index) {
        elements.set(index, new Object[]{"message", ColorConverter.hexToColor(color), content});
        pureElements.set(index, new Object[] {"message", color, content});
    }

    public void setInfoByIndex(String color, String content, int index) {
        elements.set(index, new Object[]{"information", ColorConverter.hexToColor(color), content});
        pureElements.set(index, new Object[] {"information", color, content});
    }

    public void setPictureByIndex(String type, String data, int index) {
        BufferedImage image = null;
        if(type.equals("url")) {
            try {
                image = ImageIO.read(new URL(data));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else if(type.equals("data")){
            byte[] imgBytes = Base64.getDecoder().decode(data);
            try {
                image = ImageIO.read(new ByteArrayInputStream(imgBytes));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        elements.set(index, new Object[]{"picture", type, image});
        pureElements.set(index, new Object[]{"picture", type, data});
    }

    //------------End of getter and setters

    public void parse(String xmlStr) {

        try {
            InputStream is = new ByteArrayInputStream(xmlStr.getBytes());

            DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();

            Document document = documentBuilder.parse(is);

            this.parse(document);

            is.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void parse(Document xmlDoc) {


        // Creating NodeLists.
        Node rootNode = xmlDoc.hasChildNodes() ? xmlDoc.getChildNodes().item(0) : xmlDoc.createTextNode("billboard");
        NodeList elementNodes = rootNode.getChildNodes();

        //Getting XML's background colour
        String bgColor = rootNode.getAttributes().getLength() != 0 ? rootNode.getAttributes().item(0).getTextContent() : DEFAULT_BG_COLOR;
        this.bgColor = bgColor;

        if(DO_PRINT_LOG) System.out.println("\nBG color : " + bgColor);

        // Iterating Elements
        for (int i = 0; i < elementNodes.getLength(); i ++) {

            Node node = elementNodes.item(i);

            if(node instanceof Element) {

                Element element = (Element) node;

                String elementName = element.getTagName();
                String elementAttrName = element.getAttributes().getLength() != 0 ?
                    element.getAttributes().item(0).getNodeName() : "none";
                String elementAttr = element.getAttributes().getLength() != 0 ?
                        element.getAttributes().item(0).getTextContent() : "none";
                String elementContent = element.getTextContent();

                switch (elementName) {
                    // ["message", Color, "content"]
                    case "message":
                        addMessage(elementAttr, elementContent);
                        if(DO_PRINT_LOG) System.out.println("message color : " + (elementAttr.equals("none") ? DEFAULT_MESSAGE_COLOR : elementAttr)  + "\nmessage content : " + elementContent);
                        break;
                    // ["information", Color, "content"]
                    case "information":
                        addInfo(elementAttr, elementContent);
                        if(DO_PRINT_LOG) System.out.println("information color : " + (elementAttr.equals("none") ? DEFAULT_INFO_COLOR : elementAttr) + "\ninformation content : " + elementContent);
                        break;
                    // ["picture", "type", image]
                    case "picture":
                        addPicture(elementAttrName, elementAttr);
                        if(DO_PRINT_LOG) System.out.println("picture type : " +  elementAttrName + "\npicture data : " + elementAttr);
                        break;
                }
            }
        }

    }

    public String toXML() {
        String xml = "";


        try {
            // build
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.newDocument();

            Element root = document.createElement("billboard");
            root.setAttribute("background", bgColor);
            for (Object[] obj: pureElements) {
                String type = (String) obj[0];
                String attr = (String) obj[1];
                String content = (String) obj[2];
                Element e = document.createElement(type);
                if(type.equals("picture")){
                    e.setAttribute(attr, content);
                }
                else {
                    e.setAttribute("color", attr);
                    e.setTextContent(content);
                }
                root.appendChild(e);
            }
            document.appendChild(root);

            // write
            TransformerFactory ttf = TransformerFactory.newInstance();
            Transformer tf = ttf.newTransformer();
            tf.setOutputProperty(OutputKeys.INDENT, "yes");
            StringWriter sw = new StringWriter();
            tf.transform(new DOMSource(document), new StreamResult(sw));

            xml = sw.toString();

            sw.close();
        } catch (ParserConfigurationException | TransformerException | IOException e) {
            e.printStackTrace();
        }

        return xml;
    }


    // Method when call clear all the data.
    public void reset(){
        elements.clear();
        pureElements.clear();
        bgColor = null;
    }

}