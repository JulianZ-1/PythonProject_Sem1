package utils;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class FileUtil {

    public static String fileToString(File file) {

        String str = "";

        try {
            FileInputStream in = new FileInputStream(file);

            int size = in.available();

            byte[] buffer = new byte[size];

            in.read(buffer);

            in.close();

            str = new String(buffer, StandardCharsets.UTF_8);

        } catch (IOException e) {
            e.printStackTrace();
        }

        return str;
    }

    public static void saveStringToFile(String str, File file) {
        try {
            FileWriter fileWriter = new FileWriter(file.getAbsoluteFile() + ".xml");
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(str);
            bufferedWriter.close();
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
