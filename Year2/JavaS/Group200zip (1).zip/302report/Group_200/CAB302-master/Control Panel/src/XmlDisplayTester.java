import model.Billboard;
import pages.CreatePage;

import javax.swing.*;

public class XmlDisplayTester {

    private static CreatePage page;

    public static void main(String[] args) {

        String a = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<billboard background=\"#6800C0\">\n" +
                "    <message colour=\"#FF9E3F\">All custom colours</message>\n" +
                "    <information colour=\"#3FFFC7\">All custom colours</information>\n" +
                "</billboard>";

        Billboard record = new Billboard("test", "Jerry", a, "never", "never", "0");

        SwingUtilities.invokeLater(new Runnable() {
            @Override
                public void run() {
                    // TODO: pass in user
                page = new CreatePage();
                page.setBoard(record);
                page.setVisible(true);
            }
        });
    }
}