import billboard.BillboardData;

import org.w3c.dom.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import java.io.InputStream;

public class XmlParseTester {

    public static void main(String[] args){


        BillboardData testXML = new BillboardData();

        try {

            // 4.xml 多节点 base64
            // 6.xml 多节点 url
            // 11.xml bg message info 带颜色
            // 16.xml base64 big data

            InputStream inputStream = XmlParseTester.class.getResourceAsStream("billboards/6.xml"); //使用时，请将res mark成resources
            //InputStream stream = new FileInputStream()

            DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();

            Document document = documentBuilder.parse(inputStream);

            testXML.parse(document);

            inputStream.close();

        }
        catch (Exception e) {
            e.printStackTrace();
        }



    }
}