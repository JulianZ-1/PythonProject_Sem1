package utils;

import java.awt.*;

public class ColorConverter {

    public static Color hexToColor(String hexColor) {

        Color result = Color.black;

        try {
            result = new Color(Integer.parseInt(hexColor.substring(1), 16));
        }
        catch (StringIndexOutOfBoundsException | NumberFormatException e) {
            System.out.println("Bad Color, set to default.");
        }

        return result;
    }

    public static String colorToHex(Color color) {
        String hex = "#"+Integer.toHexString(color.getRGB()).substring(2);
        return hex;
    }
}
