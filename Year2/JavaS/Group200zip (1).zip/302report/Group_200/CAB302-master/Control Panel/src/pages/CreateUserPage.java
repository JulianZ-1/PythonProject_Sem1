package pages;

import model.User;
import network.Connection;
import network.Request;
import network.Response;
import utils.Authentication;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

// Create user: the Control Panel will send the Server a username, a list of permissions,
// a hashed password and a valid session token.
// The Server will then create that user and respond with an acknowledgement. (Permissions required: “Edit Users”.)
public class CreateUserPage extends JFrame {

    public final int DEFAULT_WIDTH = 350;
    public final int DEFAULT_HEIGHT = 300;

    private JPanel rootPanel;
    private JTextField usernameField;
    private JPasswordField passwordField1;
    private JPasswordField passwordField2;
    private JButton createButton;
    private JButton cancelButton;
    private JLabel errLabel;

    private Connection connection;

    public CreateUserPage() {

        // set frame
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);

        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setLocationRelativeTo(null);    // set location to center
        setTitle("User Creation");

        setResizable(false);
        setVisible(false);

        add(rootPanel);

        errLabel.setVisible(false);

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        createButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submit();
            }
        });

    }

    public void setConnection(Connection c) {
        connection = c;
    }


    private void submit() {
        errLabel.setVisible(false);
        String username = usernameField.getText();
        String pass1 = String.valueOf(passwordField1.getPassword());
        String pass2 = String.valueOf(passwordField2.getPassword());
        if (pass1.equals(pass2) && !username.isEmpty()) {
            Response response = null;
            User user = new User();
            user.setName(username);
            try {
                user.setPassword(Authentication.hash(pass1));
                // no permissions, need to edit after create
                user.setCreateBillboard("0");
                user.setEditAllBillboard("0");
                user.setEditUsers("0");
                user.setScheduleBillboard("0");

                connection.sendRequest(new Request("CREATE", "CreateUser", user));
                response = connection.listenResponse();
            } catch (NoSuchAlgorithmException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }

            if (response.ok()) {
                dispose();
            }
            else {
                errLabel.setText(response.getMessage());
                errLabel.setVisible(true);
            }
        }
        else {
            errLabel.setText("Please reconfirm your input");
            errLabel.setVisible(true);
        }
    }
}
