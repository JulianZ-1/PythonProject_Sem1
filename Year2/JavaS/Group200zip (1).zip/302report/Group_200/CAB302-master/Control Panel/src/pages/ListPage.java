package pages;

import billboard.BillboardData;
import billboard.BillboardDrawer;
import billboard.BillboardView;
import model.Billboard;
import network.Connection;
import network.Request;
import network.Response;
import org.xml.sax.SAXParseException;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.ArrayList;

// List billboards: the Control Panel will send the Server a valid session token and the Server will respond with a list of billboards
// (including the name and creator of each, as well as any other information your team feels is appropriate.)
// (Permissions required: none.)

// Delete billboard: the Control Panel will send the Server a billboard’s name and a valid session token.
// The Server will then delete the billboard and any scheduled showings of it and send back an acknowledgement.
// (Permissions required: if deleting own billboard and that billboard is not currently scheduled,
// must have “Create Billboards” permission.
// To delete any other billboards, including those currently scheduled, must have “Edit All Billboards” permission.)
public class ListPage extends JFrame {

    public final int DEFAULT_WIDTH = 900;
    public final int DEFAULT_HEIGHT = 600;
    public final double VIEWER_SCALE = 0.7;

    private JPanel rootPanel;
    private JList<String> draftJList, displayJList;
    private JButton editButton, deleteButton;
    private Box listBox, buttonBox;

    DefaultListModel<String> draftModel, displayModel;

    private Connection connection;
    private boolean editPermission;

    private BillboardView billboardView;
    private BillboardData billboardData;
    private BillboardDrawer billboardDrawer;
    private Billboard record;

    private ArrayList<Billboard> draftAList, displayAList;

    private CreatePage createPage;

    public ListPage(CreatePage createPage) {

        // init data
        editPermission = false;
        this.createPage = createPage;
        draftAList = new ArrayList<>();
        displayAList = new ArrayList<>();

        // set frame
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);

        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setLocation(300, 450);
        setTitle("Billboard Lists");

        setResizable(false);
        setVisible(false);

        rootPanel = new JPanel();

        draftModel = new DefaultListModel<>();
        draftJList = new JList<>();
        draftJList.setPreferredSize(new Dimension(DEFAULT_WIDTH / 4, DEFAULT_HEIGHT * 6 / 20));
        draftJList.setFixedCellWidth(DEFAULT_WIDTH /4);
        draftJList.setBorder(BorderFactory.createTitledBorder("Drafts:"));
        draftJList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        draftJList.setModel(draftModel);
        draftJList.addListSelectionListener(this::valueChanged);

        displayModel = new DefaultListModel<>();
        displayJList = new JList<>();
        displayJList.setPreferredSize(new Dimension(DEFAULT_WIDTH / 4, DEFAULT_HEIGHT * 6 / 20));
        displayJList.setFixedCellWidth(DEFAULT_WIDTH /4);
        displayJList.setBorder(BorderFactory.createTitledBorder("Scheduled:"));
        displayJList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        displayJList.setModel(displayModel);
        displayJList.addListSelectionListener(this::valueChanged);

        listBox = Box.createVerticalBox();
        listBox.add(Box.createHorizontalStrut(DEFAULT_WIDTH / 4));
        listBox.add(Box.createVerticalStrut(DEFAULT_HEIGHT / 20));
        listBox.add(draftJList);
        listBox.add(Box.createHorizontalStrut(DEFAULT_WIDTH / 4));
        listBox.add(Box.createVerticalStrut(DEFAULT_HEIGHT / 20));
        listBox.add(displayJList);
        listBox.add(Box.createHorizontalStrut(DEFAULT_WIDTH / 4));
        listBox.add(Box.createVerticalStrut(DEFAULT_HEIGHT / 20));


        editButton = new JButton("Edit");
        editButton.addActionListener(this::actionPerformed);

        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(this::actionPerformed);

        buttonBox = Box.createHorizontalBox();
//        buttonBox.add(Box.createHorizontalStrut(DEFAULT_WIDTH * 2 / 4));
//        buttonBox.add(Box.createVerticalStrut(DEFAULT_HEIGHT / 10));
        buttonBox.add(editButton);
        buttonBox.add(deleteButton);

        listBox.add(buttonBox);


        initPreview();

        paintFrame();


        addWindowListener(new WindowAdapter() {
            @Override
            public void windowActivated(WindowEvent e) {
                freshData();
                repaintFrame();
                super.windowActivated(e);
            }
        });

    }

    private void initPreview() {

        record = new Billboard("Untitled",
                "",
                "<billboard background=\"#ffffff\">\n    <message colour=\"#000000\">Perview</message>\n</billboard>",
                "",
                "",
                "0");

        billboardData = new BillboardData(record.getContent());

        int viewerW = (int)Math.floor(DEFAULT_WIDTH * VIEWER_SCALE),
                viewerH = (int)Math.floor(DEFAULT_HEIGHT * VIEWER_SCALE);

        billboardDrawer = new BillboardDrawer(100, 100, viewerW, viewerH);

        billboardView = billboardDrawer.draw(billboardData);


    }

    public void actionPerformed(ActionEvent e) {
        String eName = e.getActionCommand();
        System.out.println(eName);
        int draftIndex = draftJList.getSelectedIndex();
        int displayIndex = displayJList.getSelectedIndex();
        System.out.println(draftIndex + " " + displayIndex);
//        errLabel.setVisible(false);

        switch (eName) {
            case "Edit":
                if (draftIndex >= 0) {
                    if (createPage.isVisible()) {
                        createPage.toFront();
                    } else {
                        createPage.setBoard(draftAList.get(draftIndex));
                        createPage.setVisible(true);
                    }
                }
                else if (displayIndex >= 0) {
                    if (createPage.isVisible()) {
                        createPage.toFront();
                    } else {
                        createPage.setBoard(displayAList.get(displayIndex));
                        createPage.setVisible(true);
                    }
                }

                break;
            case "Delete":
                if (draftIndex >= 0) {
                    Response response = null;
                    String name = draftAList.get(draftIndex).getName();
                    try {
                        connection.sendRequest(new Request("DELETE", "DeleteBillboard", name));
                        response = connection.listenResponse();

                    } catch (IOException | ClassNotFoundException ioException) {
                        ioException.printStackTrace();
                    }
                    if (response.ok()) {
                        freshData();
                        repaintFrame();
                    }
                }
                else if (displayIndex >= 0) {
                    Response response = null;
                    String name = displayAList.get(displayIndex).getName();
                    try {
                        connection.sendRequest(new Request("DELETE", "DeleteBillboard", name));
                        response = connection.listenResponse();

                    } catch (IOException | ClassNotFoundException ioException) {
                        ioException.printStackTrace();
                    }
                    if (response.ok()) {
                        freshData();
                        repaintFrame();
                    }
                }
                break;
        }
    }

    public void valueChanged(ListSelectionEvent e) {
        int draftIndex = draftJList.getSelectedIndex();
        int displayIndex = displayJList.getSelectedIndex();

        if (draftIndex >= 0) {
            billboardData = new BillboardData(draftAList.get(draftIndex).getContent());
            repaintFrame();
        }
        else if (displayIndex >= 0) {
            billboardData = new BillboardData(displayAList.get(displayIndex).getContent());
            repaintFrame();
        }
        else {
            billboardData = new BillboardData(record.getContent());
            repaintFrame();
        }
    }

    private void paintFrame() {

        rootPanel.add(listBox);
        rootPanel.add(billboardView);

        add(rootPanel);

        rootPanel.revalidate();
        revalidate();
    }

    private void repaintFrame() {

        rootPanel.remove(listBox);
        rootPanel.remove(billboardView);

        remove(rootPanel);

        billboardView = billboardDrawer.draw(billboardData);

        paintFrame();
    }

    public void setConnection(Connection c) {
        connection = c;
    }

    public void setEditPermission(boolean permission) {
        editPermission = permission;
        editButton.setEnabled(editPermission);
        deleteButton.setEnabled(editPermission);
    }

    private void freshData() {
        // clear
        draftModel.clear();
        draftAList.clear();
        displayModel.clear();
        displayAList.clear();
        // fetch
        Response boardResponse = null;
        ArrayList<Billboard> billboardList;
        // get whole list
        try {
            connection.sendRequest(new Request("READ", "ListBillboard"));
            boardResponse = connection.listenResponse();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        // gotten
        if(boardResponse.ok()) {
            billboardList = (ArrayList<Billboard>) boardResponse.getData();

            // get schedule list
            Response scheduleRes = null;
            ArrayList<Billboard> scheduleList;
            try {
                connection.sendRequest(new Request("READ", "ViewSchedule"));
                scheduleRes = connection.listenResponse();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
            // gotten
            if (scheduleRes.ok()) {
                scheduleList = (ArrayList<Billboard>) scheduleRes.getData();
                // compare and set listModels
                for (Billboard billboard : billboardList) {
                    boolean has = false;
                    for (Billboard cillboard : scheduleList) {
                        if (cillboard.getName().equals(billboard.getName())) {
                            has = true;
                        }
                    }
                    if (has) {
                        displayModel.addElement(billboard.getName());
                        displayAList.add(billboard);
                        continue;
                    }
                    else {
                        draftModel.addElement(billboard.getName());
                        draftAList.add(billboard);
                        continue;
                    }
                }
            }
            else {
                // TODO:
            }
        }
        else {
            // TODO:
        }
    }




}
