package pages;

import config.ConfigException;
import network.Connection;
import network.Request;

import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;

public class RequestTestingPage extends JFrame {
    private JPanel rootPanel;
    private JButton sendRequestButton;
    private JTextField actionField;
    private JTextField dataField;
    private JComboBox<String> typeCombo;

    private final String DEFAULT_TYPE = "EMPTY";
    private final String DEFAULT_ACTION = "";
    private final String DEFAULT_DATA = "";

    private Connection connection;

    public RequestTestingPage() {

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);

        setSize(450, 540);
        setLocationRelativeTo(null);
        setTitle("  Send to Server");
        setVisible(true);


        add(rootPanel);

        actionField.setText(DEFAULT_ACTION);
        dataField.setText(DEFAULT_DATA);
        typeCombo.setEditable(true);
        typeCombo.addItem("EMPTY");
        typeCombo.addItem("CREATE");
        typeCombo.addItem("READ");
        typeCombo.addItem("UPDATE");
        typeCombo.addItem("DELETE");
        typeCombo.addItem("CLOSE");
        typeCombo.addItem("");
        typeCombo.setSelectedItem("");

        try {
            connection = new Connection();
        } catch (IOException | ConfigException e) {
            e.printStackTrace();
        }

        typeCombo.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    boolean actionEnable = true, dataEnable = true;
                    switch (e.getItem().toString()) {
                        case "EMPTY":
                        case "CLOSE":
                            actionEnable = false;
                            dataEnable = false;
                            break;
                        case "CREATE":
                        case "READ":
                        case "DELETE":
                            dataEnable = false;
                            break;
                    }
                    actionField.setEnabled(actionEnable);
                    dataField.setEnabled(dataEnable);
                }
            }
        });


        sendRequestButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // send request
                try {
                    String type = (String) typeCombo.getSelectedItem();
                    String target = actionField.getText();
                    Object data = dataField.getText();

                    connection.sendRequest(new Request(type, target, data));
                    connection.listenResponse();
                } catch (IOException | ClassNotFoundException ioException) {
                    ioException.printStackTrace();
                }
            }
        });

        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // close connection
                try {
                    connection.closeClientSide();

                } catch (IOException | ClassNotFoundException ioException) {
                    ioException.printStackTrace();
                }
                finally {
                    super.windowClosing(e);
                }

            }
        });


    }



}
