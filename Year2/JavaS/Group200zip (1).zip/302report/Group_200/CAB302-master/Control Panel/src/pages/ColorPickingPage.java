package pages;

import javax.swing.*;
import javax.swing.colorchooser.AbstractColorChooserPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class ColorPickingPage extends JFrame {

    public final int DEFAULT_WIDTH = 650;
    public final int DEFAULT_HEIGHT = 350;

    private JPanel rootPanel;

    private EditElementPage parentPage;

    private Color color;

    public ColorPickingPage(EditElementPage page) {
        parentPage = page;
        setWindow();
    }

    private void setWindow() {
        // set frame
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);

        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setLocationRelativeTo(null);    // set location to center
        setTitle("Color Picker");

        setResizable(false);
        setVisible(false);

        rootPanel = new JPanel();
        add(rootPanel);

        LayoutManager layout = new FlowLayout();
        setLayout(layout);

        JLabel colorLabel = new JLabel("Your Text Color");
        colorLabel.setFont(new Font("Sans Serif", Font.BOLD, 20));

        JColorChooser colorChooser = new JColorChooser();
        // set preview panel empty
        colorChooser.setPreviewPanel(new JPanel());
        //Add border
        colorChooser.setBorder(BorderFactory.createTitledBorder("Choose a Color: "));
        AbstractColorChooserPanel[] panels = colorChooser.getChooserPanels();
        // rgb panel only
        for(int i = 0; i < panels.length; i++){
            if (i == panels.length - 2) {
                continue;
            }
            colorChooser.removeChooserPanel(panels[i]);
        }
        // listener
        colorChooser.getSelectionModel().addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                color = colorChooser.getColor();
                parentPage.setColor(color);
                colorLabel.setForeground(color);
            }
        });
        add(colorLabel);
        add(colorChooser);
        getContentPane().add(rootPanel, BorderLayout.CENTER);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                setVisible(false);
            }
        });
    }
}
