package pages;

import javax.swing.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;

public class Listeners {
    // create a function that show a dialog window when try to exit the control panel
    public static void Confirm_exit(HomePage frame){
        //add a window listener when close the window
        frame.addWindowListener(new WindowListener() {

            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            // Show the confirmation message when the user try to close the window
            public void windowClosing(WindowEvent e) {
                int returnValue = JOptionPane.showConfirmDialog(frame,
                        "Are you sure to exit?",
                        "Exit confirmation",
                        JOptionPane.YES_NO_OPTION);
                if (returnValue == JOptionPane.YES_OPTION){
                    frame.close();
                    System.exit('0');
                }
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }


            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
    }
}
