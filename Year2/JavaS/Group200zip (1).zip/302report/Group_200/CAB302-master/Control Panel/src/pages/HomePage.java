package pages;

import config.ConfigException;
import model.Billboard;
import network.Connection;
import network.Request;
import network.Response;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import static pages.Listeners.Confirm_exit;

//import java.imageIcon;

public class HomePage extends JFrame{
    //JFrame frame = new JFrame("Homepage");

    public final int DEFAULT_WIDTH = 900;
    public final int DEFAULT_HEIGHT = 600;
    //JFrame frame = new JFrame();

    private JPanel rootPanel;
    private JButton button_Create;
    private JButton button_List;
    private JButton button_Schedule;
    private JButton button_Edit;
    private JButton button_logout;
    private JButton logoutButton;
    private JLabel label_profile_img;
    private JLabel usernameLabel;

    private CreatePage createPage;
    private ListPage listPage;
    private SchedulePage schedulePage;
    private EditPage editPage;
    private AccountPage accountPage;
    private LoginPage loginPage;
    private ChangePasswordPage changePasswordPage;
    private CreateUserPage createUserPage;
    private EditPermissionPage editPermissionPage;

    private Connection connection;

    private boolean[] permissions;
    private Billboard emptyBoard;

    public HomePage(){

        // init network
        try {
            connection = new Connection();
        } catch (IOException | ConfigException e) {
            e.printStackTrace();
        }

        // createB, editB, editU, scheduleB
        permissions = new boolean[]{false, false, false, false};
        // default empty board
        emptyBoard = new Billboard("Untitled",
                "",
                "<billboard background=\"#ffffff\">\n    <message colour=\"#000000\">Create your own billboard.</message>\n</billboard>",
                "",
                "",
                "0");

        // set frame
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);

        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setLocationRelativeTo(null);    // set location to center
        setTitle("  Billboard Control Panel");

        // set icon
        BufferedImage icon = null;
        try {
            icon = ImageIO.read(getClass().getResource("/imgs/icon.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        setIconImage(icon);


        setResizable(false);
        setVisible(false);

        add(rootPanel);
        //this.setIcon(new ImageIcon(getClass().getResource("frame.png"));
        button_Create.setPreferredSize(new Dimension(40, 80));
        button_List.setPreferredSize(new Dimension(40, 80));
        button_Edit.setPreferredSize(new Dimension(40, 80));
        button_Schedule.setPreferredSize(new Dimension(40, 80));

        HomePage frame = this;

        // instantlize pages
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                loginPage = new LoginPage(frame);
                loginPage.setConnection(connection);

                createPage = new CreatePage();
                createPage.setConnection(connection);

                listPage = new ListPage(createPage);
                listPage.setConnection(connection);

                editPermissionPage = new EditPermissionPage();
                editPermissionPage.setConnection(connection);

                changePasswordPage = new ChangePasswordPage();
                changePasswordPage.setConnection(connection);

                createUserPage = new CreateUserPage();
                createUserPage.setConnection(connection);

                schedulePage = new SchedulePage();
                schedulePage.setConnection(connection);

                editPage = new EditPage(createUserPage, changePasswordPage, editPermissionPage);
                editPage.setConnection(connection);

                accountPage = new AccountPage(frame, changePasswordPage);

            }
        });


        // create-billboards button
        button_Create.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (createPage.isVisible()) {
                    createPage.toFront();
                }
                else {
                    createPage.setBoard(emptyBoard);
                    createPage.setVisible(true);
                }
            }
        });


        // list-billboards button
        button_List.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                // TODO: check user access
                if (listPage.isVisible()) {
                    listPage.toFront();
                }
                else {
                    listPage.setVisible(true);
                }
            }
        });

        // list-billboards button
        button_Schedule.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                // TODO: check user access
                if (schedulePage.isVisible()) {
                    schedulePage.toFront();
                }
                else {
                    schedulePage.setVisible(true);
                }
            }
        });

        // list-billboards button
        button_Edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (editPage.isVisible()) {
                    editPage.toFront();
                }
                else {
                    editPage.setVisible(true);
                }
            }
        });

        label_profile_img.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // TODO: check user access
                if (accountPage.isVisible()) {
                    accountPage.toFront();
                }
                else {
                    accountPage.setVisible(true);
                }
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowActivated(WindowEvent e) {
                setPermissions();
                super.windowActivated(e);
            }
        });

          Confirm_exit(this);
    }

    public void setNameLabel(String name) {
        usernameLabel.setText(name);
        accountPage.setUsername(name);
        String expire = connection.getToken().split("[.]")[1];
        accountPage.setExpire(expire);
    }

    public void setPermissions() {
        // get permission
        Response getPermissionRes = null;
        try {
            connection.sendRequest(new Request("READ", "GetUserPermissions", connection.getUser()));
            getPermissionRes = connection.listenResponse();
        } catch (IOException | ClassNotFoundException ioException) {
            ioException.printStackTrace();
        }

        if (getPermissionRes.ok()) {
            ArrayList<String> strings = (ArrayList<String>) getPermissionRes.getData();

            try{
                for(int i = 0; i < 4; i ++) {
                    permissions[i] = strings.get(i).equals("1");
                }
                // createB, editB, editU, scheduleB
                button_Create.setEnabled(permissions[2]);
                listPage.setEditPermission(permissions[1]);
                button_Edit.setEnabled(permissions[0]);
                button_Schedule.setEnabled(permissions[3]);
                accountPage.setPermissions(permissions);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public void close(){

        try {
            connection.closeClientSide();
        } catch (IOException | ClassNotFoundException ioException) {
            ioException.printStackTrace();
        }

        loginPage.dispose();
        createPage.dispose();
        listPage.dispose();
        schedulePage.dispose();
        editPage.dispose();
        accountPage.dispose();
        changePasswordPage.dispose();
        editPermissionPage.dispose();
        createUserPage.dispose();
    }
}
