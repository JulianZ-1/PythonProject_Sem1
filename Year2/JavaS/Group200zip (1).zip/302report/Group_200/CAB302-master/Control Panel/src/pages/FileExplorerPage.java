package pages;

import utils.FileUtil;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;

public class FileExplorerPage extends JFrame {

    public final int DEFAULT_WIDTH = 700;
    public final int DEFAULT_HEIGHT = 500;

    private JPanel rootPanel;
    private JFileChooser chooser;

    private CreatePage parentPage;
    private String action;
    private String xml;

    // Import
    public FileExplorerPage(CreatePage page) {
        action = "Open File";
        parentPage = page;
        xml = "";
        setWindow();
    }

    // Export
    public FileExplorerPage(String _xml) {
        action = "Save File";
        xml = _xml;
        setWindow();
    }

    public String getAction() {
        return action;
    }

    private void setWindow() {

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setDefaultLookAndFeelDecorated(true);

        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setLocationRelativeTo(null);    // set location to center
        setTitle(action);

        setResizable(false);
        setVisible(false);

        rootPanel = new JPanel();

        chooser = new JFileChooser();
        chooser.addActionListener(this::actionPerformed);

        FileNameExtensionFilter filter = new FileNameExtensionFilter(".xml","xml");
        chooser.setFileFilter(filter);
        chooser.setMultiSelectionEnabled(false);

        rootPanel.add(chooser);

        add(rootPanel);


    }

    public void actionPerformed(ActionEvent e){
        String eName = e.getActionCommand();
        System.out.println(eName);

        switch (eName) {
            case "ApproveSelection":
                // import
                if (action.equals("Open File")) {
                    File file = chooser.getSelectedFile();
                    parentPage.setXML(FileUtil.fileToString(file));
                    setVisible(false);
                }
                // export
                else if (action.equals("Save File")){
                    File file = chooser.getSelectedFile();
                    FileUtil.saveStringToFile(xml, file);
                    setVisible(false);
                }
                break;
            case "CancelSelection":
                setVisible(false);
                break;
        }
    }
}
