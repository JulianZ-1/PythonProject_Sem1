package test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import model.Billboard;
import org.junit.jupiter.api.Test;

public class TestBillboard {

    @Test
    public void test(){
        Billboard billboard = new Billboard("name","creator","content"
        ,"start","end","scheduled");
        assertEquals("name", billboard.getName());
        assertEquals("creator", billboard.getCreator());
        assertEquals("content", billboard.getContent());
        assertEquals("start", billboard.getStart());
        assertEquals("end", billboard.getEnd());
//        assertEquals("scheduled", billboard.getScheduled());

    }

    @Test
    public void test1(){

        Billboard billboard = new Billboard("name","creator","content"
                ,null,null,null);
        assertEquals("name", billboard.getName());
        assertEquals("creator", billboard.getCreator());
        assertEquals("content", billboard.getContent());

    }

    @Test
    public void test2(){
        Billboard billboard = new Billboard(null,null,null
                ,"start","end","scheduled");
        assertEquals("start", billboard.getStart());
        assertEquals("end", billboard.getEnd());
//        assertEquals("scheduled", billboard.getScheduled());


    }

}
