package billboard;

import java.awt.*;
import java.util.LinkedList;

public class BillboardDrawer {

    private int windowX, windowY, windowWidth, windowHeight;

    /**
     * Constructor
     * @param width Width of the window that you would like the drawer to draw
     * @param height Height of the window that you would like the drawer to draw
     */
    public BillboardDrawer(int x, int y, int width, int height) {
        this.windowX = x;
        this.windowY = y;
        this.windowWidth = width;
        this.windowHeight = height;
    }


    public BillboardView draw(BillboardData data) {

        BillboardView view = new BillboardView(windowX, windowY, windowWidth, windowHeight);

        view.setBackground(data.getBGColor());

        view.setElements(data.getElements());

        return view;
    }

}
