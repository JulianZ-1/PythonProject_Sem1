function [total_distance] = distance_travelled_int(vel_points, step_size, velocity_plot)
%Function that takes the step size and the velocity points and returns
%the total distance travelled by the jumper through the trapezoidal
%integration of the function

%Finding absolute values of the jumper points
vel_Points_Abs = abs(vel_points);

%Variables used for plotting
axis_Text_Size = 14;
title_Text_Size = 20;

%Variables usedfor setting up the time array
time_start = 0;
time_finish = 60;
time_array = time_start:step_size:time_finish;

sum_vel = 0; %Summation of all the velocity data points

%The numeric integration of the absolute velocity of the jumper
for i = 1:(length(vel_Points_Abs)-1)
    sum_vel = sum_vel + vel_Points_Abs(i) + vel_Points_Abs(i+1);
end
    total_distance = step_size/2 * sum_vel;

%Error checking with actual function
traps = trapz(time_array, vel_Points_Abs);
error = traps - total_distance;


if (exist('velocity_plot', 'var') && isnumeric(velocity_plot)) %Checks if plots are wanted
    if velocity_plot == 0 %Plots the velocity of the jumper
        figure;
        hold on
        plot(time_array,vel_points) 
        xlabel('Time (Seconds)', 'fontsize', axis_Text_Size)
        ylabel("Jumper's velocity (Meters/second)", 'fontsize', axis_Text_Size)
        title('Velocity of Jumper vs time', 'fontsize', title_Text_Size)
        hold off
    elseif velocity_plot == 1 %Plots the absolute velocity of the jumper
        figure;
        hold on
        plot(time_array,vel_Points_Abs) 
        xlabel('Time (Seconds)', 'fontsize', axis_Text_Size)
        ylabel("Jumper's Absolute Velocity (Meters/second)", 'fontsize', axis_Text_Size)
        title('Absolute velocity of Jumper vs time', 'fontsize', title_Text_Size)
        hold off
    else %error message in case none of the inputs are applicable
        error("Error in user input, please enter either '0'(zero) for a velocity plot or '1'(one) for the absolute velocity plot")
    end
end
end

