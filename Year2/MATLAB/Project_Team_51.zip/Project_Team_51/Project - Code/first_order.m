function [accelaration] = first_order(f,i,h)
%first_order outputs the acceleration
%   f is the velocity function
%   i is the current index value
%   h is the h value, in this case the step_size
    accelaration = (f(i + 1) - f(i))./h;    
end