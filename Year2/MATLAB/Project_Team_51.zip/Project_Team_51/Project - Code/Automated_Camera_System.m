function camera_Time = Automated_Camera_System(position,h)
%Automated_Camera_System outputs the approximate time that the jumpers position intersects "H - D"
%   position is an array of the jumpers position
%   h is the step size of the ODEs

%Adjusting position array so that camera is at y=0
H = 74; %Height of jump point
D = 31; %Deck height
position = position - (H - D);

%Number of points to look at each side of "H - D"
points_Num = 2;

%Amount of decimal places the solution should be accurate to
accuracy = 10;

%Finding the first place where the jumper crosses the camera
%Note: Point found is one less than 0 (place < 0 < place(i+1)
place = find((position(2:end) >= 0) & (position(1:(end - 1)) < 0));
place = place(1);

%Constructing array of points to look at
x_Points = (place - (points_Num - 1)):(place + points_Num);
y_Points = position(x_Points);

%Generate interpolating polynomial of points
poly = Newton_Forward_Difference(x_Points, y_Points);

%Finding root of function
root = Newtons_Method(poly, x_Points, accuracy);
    
%Converting "place in array" to time
camera_Time = (root - 1) * h;

%Testing
figure;
hold on
plot(linspace(x_Points(1), x_Points(end)),poly(linspace(x_Points(1), x_Points(end))), 'b'); 
plot(x_Points, y_Points, 'r.', 'MarkerSize', 20);
xlabel('Position in array', 'fontsize', 14)
ylabel('Jumper Position (Meters)', 'fontsize', 14)
title('Position of Jumper vs position in array', 'fontsize', 20)
hold off


end