function ODEs = Get_ODEs(L, k)
%Get_ODEs outputs the ODE's (ordinary differential equation) for the jumpers velocity and position
%   L is an optional input for the rope length
%   k is an optional input for the spring co-efficient of the rope

%%Set up and defining ODE constants
c = 0.9; %Drag co-efficient
m = 80; %Jumper weight
g = 9.8; %Acceleration due to gravity

%Setting default values for L and k if they were not defined as positive numbers
if (~(exist('L', 'var') && isnumeric(L) && L > 0))
    L = 25;
end
if (~(exist('k', 'var') && isnumeric(k) && k > 0))
    k = 90;
end

%ODE of the jumpers velocity
dvdt = @(v, y) g... %Force on the jumper due to gravity
    - c/m * abs(v) * v... %Force on the jumper due to drag
    - max([k/m * (y - L), 0]); %Force on the jumper due to tension

dydt = @(y, v) v; %ODE of the jumpers position

ODEs = {dvdt, dydt}; %Combining ODE's into a cell array for later use

end