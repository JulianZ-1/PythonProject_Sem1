function [L, k, water_Distance, bounce_Time_Touch, jumper_Position_from_water] = Water_Touch(time_Array, h, L, k, jumper_Height, tolerance)
%Water_Touch outputs the ropes length and spring constant as well as how
%close the jumper gets to the water and the time it takes for ten bounces
%to occur under these parameters
%   time_Array is an array of times for the ODEs to have values at 
%   h is the step size of the ODEs
%   L is the initial length of the rope
%   k is the initial spring co-efficient of the rope
%   Jumper height is the height of the jumper
%   tolerance is the relative error that is acceptable for the output

%Graphing position with given constants
rope_and_jumper = L + jumper_Height;
[~, jumper_Position_Close] = Numerical_Solution(h, time_Array, rope_and_jumper, k);

%Graphing position array for how close jumper gets to water
figure;
hold on
plot(time_Array, jumper_Position_Close);
xlabel('Time (Seconds)', 'fontsize', 14)
ylabel('Jumper Position (Meters)', 'fontsize', 14)
title("1.75 m tall jumper's position vs time")
hold off

%Returning how close jumper gets to the water with normal values
jumper_Position_from_water = (74 - jumper_Height) - max(jumper_Position_Close);

%Assigning initial step sizes for rope length and spring constant
[L_Step, k_Step] = deal(10);

%Defining tolerance as value instead of percentage
tolerance = tolerance / 100;

%From manual testing, increasing k decreases period and increasing L increases height

%Asuming the rope is attached at the jumpers feet
jumper_Height = jumper_Height/1;

%Obtaining initial values
[Grav_Con,bounces_Err, water_Distance_Err, submerged] = ...
    Water_Touch_Get_Info(time_Array, h, jumper_Height, L, k);

%Changing variables one at a time until jumper's position and time are within the
%specified tolerance and the maximum acceleration is less than 2g
while (Grav_Con || ... %Gravity condition
        tolerance/2 < bounces_Err || ... %Bounces condition (tolerance/2 because range is 2 sided)
        tolerance < water_Distance_Err || submerged) %Height condition
    
    %Cheking the maximum acceleration isn't exceeded or that jumper would go under the water and adjusting if so
    if(Grav_Con || submerged)
        if(last_Updated == 'L')
            L = L - L_Step;
        else
            k = k - k_Step;
        end
        
        %Forcibly leaving the loop if solution is accurate to 4 decimal
        %places and making smaller intervals if not
        if((log10(L_Step) == -4) || (log10(k_Step) == -4))
            break;
        else
            if(last_Updated == 'L')
                L_Step = L_Step / 10;
                L = L + L_Step;
            else
                k_Step = k_Step / 10;
                k = k + k_Step;
            end
        end
    else
        %Adjusting whichever variable is the most out if nothing's wrong
        if (water_Distance_Err > 2 * bounces_Err)
            L = L + L_Step;
            last_Updated = 'L';
        else
            k = k + k_Step;
            last_Updated = 'k';
        end
    end
    
    %Updating position and acceleration from change
    [Grav_Con,bounces_Err, water_Distance_Err, submerged] = ...
        Water_Touch_Get_Info(time_Array, h, jumper_Height, L, k);
end

%Graphing position with new constants
[jumper_Velocity_Touch, jumper_Position_Touch] = Numerical_Solution(h, time_Array, L, k);

%Graphing position array for water touch
figure;
hold on
plot(time_Array, jumper_Position_Touch);
xlabel('Time (Seconds)', 'fontsize', 14)
ylabel('Jumper Position (Meters)', 'fontsize', 14)
title({'Water touch: Jumper position vs time';['Rope length is ',num2str(L),' m and spring coefficent is ',num2str(k),' N/m']})
hold off

%Finding the height to the water and the bounce time for water touch
water_Distance = (74 - jumper_Height) - max(jumper_Position_Touch);
bounce_Time_Touch = Bounce_Time(jumper_Velocity_Touch, jumper_Position_Touch(end), h, L, k);

end