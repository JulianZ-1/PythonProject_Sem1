function [Grav_Con, bounces_Err, water_Distance_Err, submerged] = Water_Touch_Get_Info(time_Array, h, jumper_Height, L, k)
%Water_Touch_Get_Info outputs the necessary logical conditions needed for the function "Water_Touch"
%   time_Array is an array of times for the ODEs to have values at 
%   h is the step size of the ODEs
%   Jumper height is the height of the jumper
%   L is the length of the rope
%   k is the spring co-efficient of the rope

%Constants
g = 9.8; %Gravity
H = 74; %Height of jump point
bounce_Time_Ideal = 60; %Perfect bounce time
rel_Err = @(real, est) abs((real - est) / real); %Relative error function


[velocity, position] = Numerical_Solution(h, time_Array, L, k);

bounce_Time = Bounce_Time(velocity, position, h, L, k);
bounces_Err = rel_Err(bounce_Time_Ideal, bounce_Time);

submerged = max(position) > H - jumper_Height;
water_Distance_Err = rel_Err(H - jumper_Height, max(position)); 

Grav_Con = 2*g < max(abs(Numerical_Differentiation(velocity, h)));


end