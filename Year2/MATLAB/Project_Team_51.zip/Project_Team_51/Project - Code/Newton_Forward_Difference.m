function poly = Newton_Forward_Difference (x, y)
%Newton_Forward_Difference outputs a polynomial through defined abscisses
%   x is an array of the x abscisses
%   y is an array of the y abscisses

%Construct empty foward difference table
terms = length(y);
FDT = zeros(terms, terms);

%Filling in table as below:
% y0
% y1 Delta*y0
% y2 Delta*y1 Delta^2*y0
% etc.
%The rest of the array is zero.
FDT(:, 1) = y;
for j = 2:1:terms % j is the column index
    for i = j:1:terms % i is the row index
        FDT(i, j) = (FDT(i, j-1) - FDT(i-1, j-1));
    end 
end

%Formulating polynomial as a string array
poly = strings(size(y)); % initialise array
for i = 1:1:terms
    poly(i) = "(" + string(FDT(i, i)) + ... % Adding next co-efficient from table
        "/" + string(factorial(i - 1)) + ")"; % Dividing by the index factorial
    
    %Adding variable part to array (No need for h as it is 1)
    for j = 2:1:i
        poly(i) = poly(i) + "*((x - " + string(x(1)) + ") - " + string(j - 2) + ")";
    end
end

%Converting from a string array to a function and simplifying it
poly = matlabFunction(expand(str2sym(join(poly, " + "))));

end