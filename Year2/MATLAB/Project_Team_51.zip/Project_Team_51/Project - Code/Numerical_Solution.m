function [velocity, position] = Numerical_Solution(h, time_Array, L, k)
%Numerical_Solution outputs a numerical solution for the jumpers velocity and position
%   h is the step size
%   time_Array is an array of times for the ODEs to have values at 
%   L is an optional input for the rope length
%   k is an optional input for the spring co-efficient of the rope

%Setting up velocity and position arrays for performance
[velocity, position] = deal(zeros(size(time_Array)));

%Defining ODE's used
if (exist('L', 'var') && exist('k', 'var'))
    ODEs = Get_ODEs(L, k);
else
    ODEs = Get_ODEs();
end

%Solving for jumpers velocity and position using RK4
for i = 1:1:(length(time_Array) - 1)
    [velocity(i + 1), position(i + 1)] = ...
        RK4(ODEs, [velocity(i), position(i)], h);
end

end