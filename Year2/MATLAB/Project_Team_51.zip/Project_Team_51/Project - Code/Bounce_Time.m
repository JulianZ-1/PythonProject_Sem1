function bounce_Time = Bounce_Time(velocity, position, h, L, k)
%Bounce_Time outputs the time it would take for the jumper to compelete a set number of bounces
%   velocity is an array of the jumpers velocity
%   positition is the valuje of the position that the jumper was last at
%   h is the step size of the ODEs
%   L is an optional input for the rope length
%   k is an optional input for the spring co-efficient of the rope

%Finding all of the times a bounce occurs, note that a bounce is defined as
%the velocity changing from negative to positive or 0
all_Bounce_Times = find((velocity(2:end) >= 0) & (velocity(1:(end - 1)) < 0));
bounces_Needed = 10;

%Finding the time it takes for "bounces_Needed" bounces to occur
if (length(all_Bounce_Times) >= bounces_Needed)
    bounce_Place = all_Bounce_Times(10) + 1;
else
    bounce_Place = length(velocity);
    bounces = length(all_Bounce_Times);
    velocity = velocity(end);
    
    %Defining ODE's used
    if (exist('L', 'var') && exist('k', 'var'))
        ODEs = Get_ODEs(L, k);
    else
        ODEs = Get_ODEs();
    end
    
    %
    while(bounces < bounces_Needed)
        bounce_Place = bounce_Place + 1;
        last_Bounce_Neg = (velocity < 0);
        [velocity, position] = RK4(ODEs, [velocity, position], h);
        
        if ((velocity >= 0) && last_Bounce_Neg)
            bounces = bounces + 1;
        end
    end
end

%Converting "place in array" to time.
bounce_Time = (bounce_Place - 1) * h;

end