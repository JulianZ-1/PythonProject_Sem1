function [next_Velocity, next_Position] = RK4(ODEs, inputs, h)
%RK4 outputs the next value of a pair of ODE's using the Fourth Order Runge-Kutta method
%   ODEs is a cell array of the ODEs
%   inputs is an array of the current values for the jumpers velocity and position (In that order)
%   h is the step size of the function

%Seting up an array for next values of velocity and position
next_Data = zeros(1, 2);

%Generating next values for velocity and position
for i = 1:1:2
    j = mod(i, 2) + 1;
    
    k1 = ODEs{i}(inputs(i), inputs(j));
    k2 = ODEs{i}(inputs(i) + h/2, inputs(j) + k1/2);
    k3 = ODEs{i}(inputs(i) + h/2, inputs(j) + k2/2);
    k4 = ODEs{i}(inputs(i) + h, inputs(j) + k3);
    next_Data(i) = inputs(i) + h/6 * (k1 + 2*k2 + 2*k3 + k4);
end

%Seperating array into individual elements
next_Velocity = next_Data(1);
next_Position = next_Data(2);

end