function root = Newtons_Method(f, x_Points, accuracy)
%Newtons_Method outputts the root of a derivable function
%   f is the function to find the root of
%   x_Points is an array of the x abscisses
%   accuracy is the number of decimal places the root should be accurate to

%Getting the first derivative of the inputted function
%From Workshop 3
df = matlabFunction(diff(sym(f), 1));

%Guessing intial place for the root
root = mean(x_Points);

%Defining the tolerance of the solution
tol = 0.5 * 10^(-accuracy);

%Find root accurate to "accuracy" decimal places
while (f(root) > tol)
    root = root - f(root)/df(root);
end

end