function jumper_Acceleration = Numerical_Differentiation(jumper_Velocity, step_Size)
%Numerical_Differentiation finds the numerical derivative of an array given
%a constant step size
%   jumper_Velocity is an array of the jumpers velocity
%   step_Size is the step size of the time array

f = @(t) jumper_Velocity(t);
jumper_Acceleration = zeros(1, length(jumper_Velocity) - 1);


for i = 1:length(jumper_Acceleration)
    jumper_Acceleration(i) = first_order(f, i, step_Size);
end


end