%Ensuring stability of program by clearing all variables and closing all figures
clear all;
close all;
clc;

%Defining function variables that are critical to multiple sections
time_Start = 0;
time_End = 60;
step_Size = 0.001;

time_Array = time_Start:step_Size:time_End; %Array of times to look at

%Defining other useful Variables
axis_Text_Size = 14;
title_Text_Size = 20;

%Section 3
[jumper_Velocity, jumper_Position] = Numerical_Solution(step_Size, time_Array);

%Graphing position array
figure;
hold on
plot(time_Array, jumper_Position);
xlabel('Time (Seconds)', 'fontsize', axis_Text_Size)
ylabel('Jumper Position (Meters)', 'fontsize', axis_Text_Size)
title('Position of Jumper vs time', 'fontsize', title_Text_Size)
hold off

%Section 4.1
bounce_Time = Bounce_Time(jumper_Velocity, jumper_Position(end), step_Size);
disp("The jumper bounces 10 times in " + bounce_Time + " seconds.");

%Section 4.2
max_velocity = max(abs(jumper_Velocity));
max_velocity_time = time_Array(abs(jumper_Velocity) == max_velocity);
disp("The maximum speed will be " + max_velocity + "m/s at "+ max_velocity_time + " seconds.");

%Graphing velocity array
figure;
hold on
plot(time_Array, jumper_Velocity);
xlabel('Time (Seconds)', 'fontsize', axis_Text_Size)
ylabel('Jumper Velocity (m/s)', 'fontsize', axis_Text_Size)
title('Velocity overtime', 'fontsize', title_Text_Size)
hold off

%Section 4.3
jumper_Acceleration = Numerical_Differentiation(jumper_Velocity, step_Size);

max_acceleration = max(abs(jumper_Acceleration));
max_acceleration_time = time_Array(abs(jumper_Acceleration) == max_acceleration);
disp("The maximum acceleration will be " + max_acceleration + "m/s^2 at "+ max_acceleration_time +" seconds.");

%Graphing acceleration array
figure
plot(time_Array(1:end - 1), abs(jumper_Acceleration))
xlabel('Time (Seconds)')
ylabel('Jumper Acceleration (m/s^2)')
title('Acceleration vs Time')

%Section 4.4
total_distance = distance_travelled_int(jumper_Velocity, step_Size);
disp("The jumper travels a total of " + total_distance + "m in a standard bungee jump.")

%Section 4.5
camera_Time = Automated_Camera_System(jumper_Position, step_Size);
disp("The camera should trigger " + camera_Time + " seconds after the jumper jumps.");

%Section 4.6
L = 25;
k = 90;
jumper_Height = 1.75;
tolerance = 0.1;

[L, k, water_Distance, bounce_Time_Touch, jumper_Position_from_water] = ...
    Water_Touch(time_Array, step_Size, L, k, jumper_Height, tolerance);
disp("The jumper is " + jumper_Position_from_water + "m from the water with normal values")
disp("Rope length of " + L + "m and rope coefficient of " + k + "N/m is needed for a true water touch experience")