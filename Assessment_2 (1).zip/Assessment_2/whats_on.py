
#-----Statement of Authorship----------------------------------------#
#
#  This is an individual assessment item.  By submitting this
#  code I agree that it represents my own work.  I am aware of
#  the University rule that a student must not act in a manner
#  which constitutes academic dishonesty as stated and explained
#  in QUT's Manual of Policies and Procedures, Section C/5.3
#  "Academic Integrity" and Section E/2.1 "Student Code of Conduct".
#
#    Student no: n10415483
#    Student name: Jiyan Zhu
#
#  NB: Files submitted without a completed copy of this statement
#  will not be marked.  Submitted files will be subjected to
#  software plagiarism analysis using the MoSS system
#  (http://theory.stanford.edu/~aiken/moss/).
#
#--------------------------------------------------------------------#



#-----Assignment Description-----------------------------------------#
#
#  What's On?: Online Entertainment Planning Application
#
#  In this assignment you will combine your knowledge of HTMl/XML
#  mark-up languages with your skills in Python scripting, pattern
#  matching, and Graphical User Interface design to produce a useful
#  application for planning an entertainment schedule.  See
#  the instruction sheet accompanying this file for full details.
#
#--------------------------------------------------------------------#



#-----Imported Functions---------------------------------------------#
#
# Below are various import statements for helpful functions.  You
# should be able to complete this assignment using these
# functions only.  Note that not all of these functions are
# needed to successfully complete this assignment.

# The function for opening a web document given its URL.
# (You WILL need to use this function in your solution,
# either directly or via our "download" function.)
from urllib.request import urlopen

# Import the standard Tkinter functions. (You WILL need to use
# these functions in your solution.  You may import other widgets
# from the Tkinter module provided they are ones that come bundled
# with a standard Python 3 implementation and don't have to
# be downloaded and installed separately.)
from tkinter import *

# Functions for finding all occurrences of a pattern
# defined via a regular expression, as well as
# the "multiline" and "dotall" flags.  (You do NOT need to
# use these functions in your solution, because the problem
# can be solved with the string "find" function, but it will
# be difficult to produce a concise and robust solution
# without using regular expressions.)
from re import findall, finditer, MULTILINE, DOTALL

# Import the standard SQLite functions (just in case they're
# needed one day).
from sqlite3 import *

#
#--------------------------------------------------------------------#



#-----Downloader Function--------------------------------------------#
#
# This is our function for downloading a web page's content and both
# saving it as a local file and returning its source code
# as a Unicode string. The function tries to produce
# a meaningful error message if the attempt fails.  WARNING: This
# function will silently overwrite the target file if it
# already exists!  NB: You should change the filename extension to
# "xhtml" when downloading an XML document.  (You do NOT need to use
# this function in your solution if you choose to call "urlopen"
# directly, but it is provided for your convenience.)
#
def download(url = 'http://www.wikipedia.org/',
             target_filename = 'download',
             filename_extension = 'html'):

    # Import an exception raised when a web server denies access
    # to a document
    from urllib.error import HTTPError

    # Open the web document for reading
    try:
        web_page = urlopen(url)
    except ValueError:
        raise Exception("Download error - Cannot find document at URL '" + url + "'")
    except HTTPError:
        raise Exception("Download error - Access denied to document at URL '" + url + "'")
    except:
        raise Exception("Download error - Something went wrong when trying to download " + \
                        "the document at URL '" + url + "'")

    # Read its contents as a Unicode string
    try:
        web_page_contents = web_page.read().decode('UTF-8')
    except UnicodeDecodeError:
        raise Exception("Download error - Unable to decode document at URL '" + \
                        url + "' as Unicode text")

    # Write the contents to a local text file as Unicode
    # characters (overwriting the file if it
    # already exists!)
    try:
        text_file = open(target_filename + '.' + filename_extension,
                         'w', encoding = 'UTF-8')
        text_file.write(web_page_contents)
        text_file.close()
    except:
        raise Exception("Download error - Unable to write to file '" + \
                        target_file + "'")

    # Return the downloaded document to the caller
    return web_page_contents

#
#--------------------------------------------------------------------#



#-----Student's Solution---------------------------------------------#
#
# Put your solution at the end of this file.
#

#Websites that will be used

url_1 = 'https://www.queensland.com/en-au/events/arts-and-culture'
url_2 = 'https://concreteplayground.com/brisbane/events'
url_3 = 'https://www.qso.com.au/events/all-events'




#Command for main windownx

main_windown = Tk()
main_windown.title('The Weekend Planner')

#Creating all the lists
art_event_list = []
art_time_list = []
art_img_list =[]

events_event_list = []
events_time_list = []
events_img_list = []

music_event_list = []
music_time_list = []
music_img_list = []

selected_list = []
selected_img = []
selected_time = []


#Creating different Var
offline_var = IntVar()
#Seting the value to "Unchecked" so it doesnt check as soon as you open it
var = StringVar(value= "Unchecked")
var2 = StringVar(value= "Unchecked")
var3 = StringVar(value= "Unchecked")
var4 = StringVar(value= "Unchecked")
var5 = StringVar(value= "Unchecked")
var6 = StringVar(value= "Unchecked")

var_e = StringVar(value= "Unchecked")
var_e2 = StringVar(value= "Unchecked")
var_e3 = StringVar(value= "Unchecked")
var_e4 = StringVar(value= "Unchecked")
var_e5 = StringVar(value= "Unchecked")
var_e6 = StringVar(value= "Unchecked")

var_m = StringVar(value= "Unchecked")
var_m2 = StringVar(value= "Unchecked")
var_m3 = StringVar(value= "Unchecked")
var_m4 = StringVar(value= "Unchecked")
var_m5 = StringVar(value= "Unchecked")
var_m6 = StringVar(value= "Unchecked")

#-------------------------------------------------
#End of creating list, var and websites

#Start of creating def
#-------------------------------------------------

#Def for the print html button
def generate_html():


    html_file=open("planner" + ".html", 'w', encoding = 'UTF-8')
    html_file.write("""<!DOCTYPE html>
     <html>

        <head>
            <title>
            The Weekend Planner
            </title>
        </head>

        <body>
            <h1 align = "center" style= "color: purple; font-size:100px">
            The Weekend Planner 
            </h1>
            <h2 align= "center">
            <img src="https://cdn.racenet.com.au/images/news/news_images/504w/weekend-loading.jpg"
            width = "500" height = "500">
            </h2>
            <h3 align= "center" style= "color: light yellow; font-size:30px">
            Belows are you selected events! :3
            </h3>
            """)
    if len(selected_img)<= 0 and len(selected_list)<= 0 and len(selected_time)<= 0:
        html_file.write('<p align= "center" style= "color: red; font-size: 70px"> You have nothing planned for you weekend :(</p>')
    else:
        zip(selected_img, selected_list, selected_time)     #The zip() function take iterables, 
                                                            #makes iterator that aggregates elements based on the iterables passed, 
                                                            # and returns an iterator of tuples. 
        for (a,b,c) in zip(selected_img, selected_list, selected_time):
            html_file.write ('''<p align= "center"><img src ="'''+ str(a) +'"' + 'width = "500" height = "500"></p>'
            '<p align= "center">' + str(b) + '</p>'
            '<p align= "center">' + str(c) + '</p>')     

    html_file.write("""
            <h2>References</h2>
            <ol>
             <li><a href="https://www.queensland.com/en-au/events/arts-and-culture"><em>Queensland Art and Cultural Events</em></a></li>
             <li><a href="https://concreteplayground.com/brisbane/events"><em>Concrete Playground</em></a></li>
             <li><a href="https://www.qso.com.au/events/all-events"><em>Queensland Symphony Orchestra</em></a></li>

            
        </body>

     </html>""")
    html_file.close
    

#Defs for all the var, add to the list, remove from the list as well as makes the print button text number same as
#amount selected
def adding_art():
    if var.get() == "Checked":
        selected_list.append(art_event_list[0])
        selected_time.append(art_time_list[0])
        selected_img.append(art_img_list[0])
        amount_select()

    elif var.get() == "Unchecked":
        selected_list.remove(art_event_list[0])
        selected_time.remove(art_time_list[0])
        selected_img.remove(art_img_list[0])
        amount_select()

def adding_art2():
    if var2.get() == "Checked":
        selected_list.append(art_event_list[1])
        selected_time.append(art_time_list[1])
        selected_img.append(art_img_list[1])
        amount_select()

    elif var2.get() == "Unchecked":
        selected_list.remove(art_event_list[1])
        selected_time.remove(art_time_list[1])
        selected_img.remove(art_img_list[1])
        amount_select()

def adding_art3():
    if var3.get() == "Checked":
        selected_list.append(art_event_list[2])
        selected_time.append(art_time_list[2])
        selected_img.append(art_img_list[2])
        amount_select()

    elif var3.get() == "Unchecked":
        selected_list.remove(art_event_list[2])
        selected_time.remove(art_time_list[2])
        selected_img.remove(art_img_list[2])
        amount_select()

def adding_art4():
    if var4.get() == "Checked":
        selected_list.append(art_event_list[3])
        selected_time.append(art_time_list[3])
        selected_img.append(art_img_list[3])
        amount_select()

    elif var4.get() == "Unchecked":
        selected_list.remove(art_event_list[3])
        selected_time.remove(art_time_list[3])
        selected_img.remove(art_img_list[3])
        amount_select()

def adding_art5():
    if var5.get() == "Checked":
        selected_list.append(art_event_list[4])
        selected_time.append(art_time_list[4])
        selected_img.append(art_img_list[4])
        amount_select()

    elif var5.get() == "Unchecked":
        selected_list.remove(art_event_list[4])
        selected_time.remove(art_time_list[4])
        selected_img.remove(art_img_list[4])
        amount_select()

def adding_art6():
    if var6.get() == "Checked":
        selected_list.append(art_event_list[5])
        selected_time.append(art_time_list[5])
        selected_img.append(art_img_list[5])
        amount_select()

    elif var6.get() == "Unchecked":
        selected_list.remove(art_event_list[5])
        selected_time.remove(art_time_list[5])
        selected_img.remove(art_img_list[5])
        amount_select()

def adding_event():
    if var_e.get() == "Checked":
        selected_list.append(events_event_list[0])
        selected_time.append(events_time_list[0])
        selected_img.append(events_img_list[0])
        amount_select()

    elif var_e.get() == "Unchecked":
        selected_list.remove(events_event_list[0])
        selected_time.remove(events_time_list[0])
        selected_img.remove(events_img_list[0])
        amount_select()

def adding_event2():
    if var_e2.get() == "Checked":
        selected_list.append(events_event_list[1])
        selected_time.append(events_time_list[1])
        selected_img.append(events_img_list[1])
        amount_select()
    elif var_e2.get() == "Unchecked":
        selected_list.remove(events_event_list[1])
        selected_time.remove(events_time_list[1])
        selected_img.remove(events_img_list[1])
        amount_select()

def adding_event3():
    if var_e3.get() == "Checked":
        selected_list.append(events_event_list[2])
        selected_time.append(events_time_list[2])
        selected_img.append(events_img_list[2])
        amount_select()

    elif var_e3.get() == "Unchecked":
        selected_list.remove(events_event_list[2])
        selected_time.remove(events_time_list[2])
        selected_img.remove(events_img_list[2])
        amount_select()

def adding_event4():
    if var_e4.get() == "Checked":   
        selected_list.append(events_event_list[3])
        selected_time.append(events_time_list[3])
        selected_img.append(events_img_list[3])
        amount_select()

    elif var_e4.get() == "Unchecked":
        selected_list.remove(events_event_list[3])
        selected_time.remove(events_time_list[3])
        selected_img.remove(events_img_list[3])
        amount_select()

def adding_event5():
    if var_e5.get() == "Checked":
        selected_list.append(events_event_list[4])
        selected_time.append(events_time_list[4])
        selected_img.append(events_img_list[4])
        amount_select()

    elif var_e5.get() == "Unchecked":
        selected_list.remove(events_event_list[4])
        selected_time.remove(events_time_list[4])
        selected_img.remove(events_img_list[4])
        amount_select()

def adding_event6():
    if var_e6.get() == "Checked":
        selected_list.append(events_event_list[5])
        selected_time.append(events_time_list[5])
        selected_img.append(events_img_list[5])
        amount_select()

    elif var_e6.get() == "Unchecked":
        selected_list.remove(events_event_list[5])
        selected_time.remove(events_time_list[5])
        selected_img.remove(events_img_list[5])
        amount_select()

def adding_music():
    if var_m.get() == "Checked":
        selected_list.append(music_event_list[0])
        selected_time.append(music_time_list[0])
        selected_img.append(music_img_list[0])
        amount_select()

    elif var_m.get() == "Unchecked":
        selected_list.remove(music_event_list[0])
        selected_time.remove(music_time_list[0])
        selected_img.remove(music_img_list[0])
        amount_select()

def adding_music2():
    if var_m2.get() == "Checked":
        selected_list.append(music_event_list[1])
        selected_time.append(music_time_list[1])
        selected_img.append(music_img_list[1])
        amount_select()

    elif var_m2.get() == "Unchecked":
        selected_list.remove(music_event_list[1])
        selected_time.remove(music_time_list[1])
        selected_img.remove(music_img_list[1])
        amount_select()

def adding_music3():
    if var_m3.get() == "Checked":
        selected_list.append(music_event_list[2])
        selected_time.append(music_time_list[2])
        selected_img.append(music_img_list[2])
        amount_select()

    elif var_m3.get() == "Unchecked":
        selected_list.remove(music_event_list[2])
        selected_time.remove(music_time_list[2])
        selected_img.remove(music_img_list[2])
        amount_select()

def adding_music4():
    if var_m4.get() == "Checked":
        selected_list.append(music_event_list[3])
        selected_time.append(music_time_list[3])
        selected_img.append(music_img_list[3])
        amount_select()

    elif var_m4.get() == "Unchecked":
        selected_list.remove(music_event_list[3])
        selected_time.remove(music_time_list[3])
        selected_img.remove(music_img_list[3])
        amount_select()

def adding_music5():
    if var_m5.get() == "Checked":
        selected_list.append(music_event_list[4])
        selected_time.append(music_time_list[4])
        selected_img.append(music_img_list[4])
        amount_select()

    elif var_m5.get() == "Unchecked":
        selected_list.remove(music_event_list[4])
        selected_time.remove(music_time_list[4])
        selected_img.remove(music_img_list[4])
        amount_select()

def adding_music6():
    if var_m6.get() == "Checked":
        selected_list.append(music_event_list[5])
        selected_time.append(music_time_list[5])
        selected_img.append(music_img_list[5])
        amount_select()
    elif var_m6.get() == "Unchecked":
        selected_list.remove(music_event_list[5])
        selected_time.remove(music_time_list[5])
        selected_img.remove(music_img_list[5])
        amount_select()

#Def for save to the database
def save_data():
    planner_db = connect(database='entertainment_planner.db')
    sql_cursor = planner_db.cursor()
    sql_cursor.execute('DELETE FROM events')
    insert_command = "INSERT INTO events (event_name, event_date) VALUES("
    zip(selected_list, selected_time)
    for (a,b) in zip(selected_list, selected_time):
        planner_db.execute( insert_command + '"'+str(a)+'"' + "," + '"'+str(b)+'"' + ");")
        planner_db.commit()
        


#Function for opening a new window
def new_w_button_art():
    # If the offline button is unchecked on the main window, it will open url and find source online
    if offline_var.get() == 0:
        url_art = urlopen(url_1)
        html_code_art = url_art.read().decode("UTF-8")
        #After read websites and decode, and run the findall command to get the thins I want
        art_title_list = findall('<h3>(.*)<', html_code_art)
        art_date_list = findall('</h3>\W\s\W*p>(.*)<', html_code_art)
        art_pic_list = findall('</a>\W*<img\W*src="(.*)"', html_code_art)
        #Adding 3 different elements from same website and append them to a list.
        for title in art_title_list:
            art_event_list.append(title)
        for date in art_date_list:
            art_time_list.append(date)
        for pic in art_pic_list:
            art_img_list.append(pic)
    # If the offline button is checked on the main window, it will open the html file that I already downloaded
    elif offline_var.get() == 1:
        off_art = open("Archive/Art.html", encoding="utf8")
        off_html_code_art = off_art.read()
        art_title_list = findall('<h3>(.*)<', off_html_code_art)
        art_date_list = findall('</h3>\W\s\W*p>(.*)<', off_html_code_art)
        art_pic_list = findall('</a>\W*<img\W*src="(.*)"', off_html_code_art)
        for title in art_title_list:
            art_event_list.append(title)
        for date in art_date_list:
            art_time_list.append(date)
        for pic in art_pic_list:
            art_img_list.append(pic)
    #After adding the elements to the list, belows are the commands for creating the windown for Art
    art_win = Toplevel()
    art_win.configure(background="light yellow")    
    banner_art = Label(art_win, text="Belows are what's in the Art Gallery", bg="grey",
    font=("fixedsys",30))
    banner_art.grid(column=2, pady=20)
    #Adding checkbuttons to the windown, the text is what's the finall command found on the web or downloaded html.
    #Adding different var, on, offvalue as well as the commands will helps when it comes to print the events
    a_c_1 = Checkbutton(art_win, text=(art_event_list[0], (art_time_list[0])), font=("fixedsys",20),  variable=var, onvalue="Checked", offvalue="Unchecked", command= adding_art)
    a_c_1.grid(row=1, column=2, pady=10)
    a_c_2 = Checkbutton(art_win, text=(art_event_list[1], (art_time_list[1])), font=("fixedsys",20), variable=var2, onvalue="Checked", offvalue="Unchecked", command= adding_art2)
    a_c_2.grid(row=2, column=2, pady=10)
    a_c_3 = Checkbutton(art_win, text=(art_event_list[2], (art_time_list[2])), font=("fixedsys",20), variable=var3, onvalue="Checked", offvalue="Unchecked", command= adding_art3)
    a_c_3.grid(row=3, column=2, pady=10)
    a_c_4 = Checkbutton(art_win, text=(art_event_list[3], (art_time_list[3])), font=("fixedsys",20), variable=var4, onvalue="Checked", offvalue="Unchecked", command= adding_art4)
    a_c_4.grid(row=4, column=2, pady=10)
    a_c_5 = Checkbutton(art_win, text=(art_event_list[4], (art_time_list[4])), font=("fixedsys",20), variable=var5, onvalue="Checked", offvalue="Unchecked", command= adding_art5)
    a_c_5.grid(row=5, column=2, pady=10)
    a_c_6 = Checkbutton(art_win, text=(art_event_list[5], (art_time_list[5])), font=("fixedsys",20), variable=var6, onvalue="Checked", offvalue="Unchecked", command= adding_art6)
    a_c_6.grid(row=6, column=2, pady=10)
    website_source_a = Label(art_win, text= "The source is from https://www.queensland.com/en-au/events/arts-and-culture", font=('Comic Sans MS', 8))
    website_source_a.grid(row=7, column=2, pady=30)
    

def new_w_button_events():
    #Belows commands are alomost the same as the one above, the only differnets are the website, downloaded html, var and commands.
    if offline_var.get() == 0:
        url_events = urlopen(url_2)
        html_code_events = url_events.read().decode("UTF-8")
        events_title_list = findall("""  <a target="_blank".*\W*(.*)<""", html_code_events)
        events_date_list = findall('<p class="dates">([A-Za-z ,0-9-]*)', html_code_events)
        events_pic_list = findall('<noscript><img src="([A-Z a-z/:-_.0-9 -]+)', html_code_events)
        for title in events_title_list:
            events_event_list.append(title)
        for date in events_date_list:
            events_time_list.append(date)
        for pic in events_pic_list:
            events_img_list.append(pic)
    elif offline_var.get() == 1:
        off_events = open("Archive/events.html", encoding="utf8")
        off_html_code_events = off_events.read()
        events_title_list = findall("""  <a target="_blank".*\W*(.*)<""", off_html_code_events)
        events_date_list = findall('<p class="dates">([A-Za-z ,0-9-]*)', off_html_code_events)
        events_pic_list = findall('<noscript><img src="([A-Z a-z/:-_.0-9 -]+)', off_html_code_events)
        for title in events_title_list:
            events_event_list.append(title)
        for date in events_date_list:
            events_time_list.append(date)
        for pic in events_pic_list:
            events_img_list.append(pic)
        
    events_win = Toplevel()
    events_win.configure(background="light blue")
    banner_events = Label(events_win, text="Belows are what's in the PLAYGROUND", bg="grey",
    font=("fixedsys",30))
    banner_events.grid(column=2, pady=20)
    e_c_1 = Checkbutton(events_win, text=(events_event_list[0], events_time_list[0]), font=("fixedsys",20), variable=var_e, onvalue="Checked", offvalue="Unchecked", command= adding_event)
    e_c_1.grid(row=1, column=2, pady=10)
    e_c_2 = Checkbutton(events_win, text=(events_event_list[1], events_time_list[1]), font=("fixedsys",20), variable=var_e2, onvalue="Checked", offvalue="Unchecked", command= adding_event2)
    e_c_2.grid(row=2, column=2, pady=10)
    e_c_3 = Checkbutton(events_win, text=(events_event_list[2], events_time_list[2]), font=("fixedsys",20), variable=var_e3, onvalue="Checked", offvalue="Unchecked", command= adding_event3)
    e_c_3.grid(row=3, column=2, pady=10)
    e_c_4 = Checkbutton(events_win, text=(events_event_list[3], events_time_list[3]), font=("fixedsys",20), variable=var_e4, onvalue="Checked", offvalue="Unchecked", command= adding_event4)
    e_c_4.grid(row=4, column=2, pady=10)
    e_c_5 = Checkbutton(events_win, text=(events_event_list[4], events_time_list[4]), font=("fixedsys",20), variable=var_e5, onvalue="Checked", offvalue="Unchecked", command= adding_event5)
    e_c_5.grid(row=5, column=2, pady=10)
    e_c_6 = Checkbutton(events_win, text=(events_event_list[5], events_time_list[5]), font=("fixedsys",20), variable=var_e6, onvalue="Checked", offvalue="Unchecked", command= adding_event6)
    e_c_6.grid(row=6, column=2, pady=10)
    website_source_e = Label(events_win, text= "The source is from https://concreteplayground.com/brisbane/events", font=('Comic Sans MS', 8))
    website_source_e.grid(row=7, column=2, pady=30)

def new_w_button_music():
    #Almost as the same from the one above.
    url_music = urlopen(url_3)
    if offline_var.get() == 0:
        html_code_music = url_music.read().decode("UTF-8")
        music_title_list = findall('rel="bookmark">(.*)</a>', html_code_music)
        music_date_list = findall('"date">(.*)</div>', html_code_music)
        music_pic_list = findall('teaser-image">\W*.\s\S*\Wsrc="([=A-Z?/:?.a-z0-9_-]+)', html_code_music)
        for title in music_title_list:
            music_event_list.append(title)
        for date in music_date_list:
            music_time_list.append(date)
        for pic in music_pic_list:
            music_img_list.append(pic)
    elif offline_var.get() == 1:
        off_music = open("Archive/Music.html", encoding="utf8")
        off_html_code_music = off_music.read()
        music_title_list = findall('rel="bookmark">(.*)</a>', off_html_code_music)
        music_date_list = findall('"date">(.*)</div>', off_html_code_music)
        music_pic_list = findall('teaser-image">\W*.\s\S*\Wsrc="([=A-Z?/:?.a-z0-9_-]+)', off_html_code_music)
        for title in music_title_list:
            music_event_list.append(title)
        for date in music_date_list:
            music_time_list.append(date)
        for pic in music_pic_list:
            music_img_list.append(pic)
            
    music_win = Toplevel()
    music_win.configure(background="light green")
    banner_music = Label(music_win, text="Belows are what's in the Queensland Symphony Orchestra", bg="grey",
    font=("fixedsys",30))
    banner_music.grid(column=2, pady= 30)
    m_c_1 = Checkbutton(music_win, text=(music_event_list[0], music_time_list[0]), font=("fixedsys",20), variable=var_m, onvalue="Checked", offvalue="Unchecked", command= adding_music)
    m_c_1.grid(row=1, column=2, pady=10)
    m_c_2 = Checkbutton(music_win, text=(music_event_list[1], music_time_list[1]), font=("fixedsys",20), variable=var_m2, onvalue="Checked", offvalue="Unchecked", command= adding_music2)
    m_c_2.grid(row=2, column=2, pady=10)
    m_c_3 = Checkbutton(music_win, text=(music_event_list[2], music_time_list[2]), font=("fixedsys",20), variable=var_m3, onvalue="Checked", offvalue="Unchecked", command= adding_music3)
    m_c_3.grid(row=3, column=2, pady=10)
    m_c_4 = Checkbutton(music_win, text=(music_event_list[3], music_time_list[3]), font=("fixedsys",20), variable=var_m4, onvalue="Checked", offvalue="Unchecked", command= adding_music4)
    m_c_4.grid(row=4, column=2, pady=10)
    m_c_5 = Checkbutton(music_win, text=(music_event_list[4], music_time_list[4]), font=("fixedsys",20), variable=var_m5, onvalue="Checked", offvalue="Unchecked", command= adding_music5)
    m_c_5.grid(row=5, column=2, pady=10)
    m_c_6 = Checkbutton(music_win, text=(music_event_list[5], music_time_list[5]), font=("fixedsys",20), variable=var_m6, onvalue="Checked", offvalue="Unchecked", command= adding_music6)
    m_c_6.grid(row=6, column=2, pady=10)
    website_source_m = Label(music_win, text= "The source is from https://www.qso.com.au/events/all-events", font=('Comic Sans MS', 8))
    website_source_m.grid(row=7, column=2, pady=30)
    music_win.mainloop()


def amount_select():
    #This is the command for the + 1 and -1 number on the print button.
   total_selected = len(selected_list)
   print_button ['text']= 'Print ( ' + str(total_selected) + ' ) events to your planner'

#-------------------------------------------------------------------------------
#End of all defs

#Start of creating different gui
#-------------------------------------------------------------------------------


#Command for adding the Logo to the main windown
logo = PhotoImage(file="logo.png")
main_logo = Label(main_windown, image=logo, width=700, height=500)
main_logo.grid(row=1, column=2)

#Banner to tell what are these button
banner_1 = Label(main_windown, text="Below are 3 website for you to choose from",
                 bg="grey", font=("Fixedsys",30))
banner_1.grid(row=2, column=2)

#Creating three button for the website

button_1 = Button(main_windown, text= "Art",
                  activeforeground = "purple", font=("Fixedsys",28),
                  command=new_w_button_art)
button_1.grid(row=3, column=1, padx=40, pady=10)

button_2 = Button(main_windown, text= "Events",
                  activeforeground = "purple", font=("Fixedsys",28),
                  command=new_w_button_events)
button_2.grid(row=3, column=2, padx=40, pady=10)

button_3 = Button(main_windown, text= "Music",
                  activeforeground = "purple", font=("Fixedsys",28),
                  command=new_w_button_music)
button_3.grid(row=3, column=3, padx=40, pady=10)

#The command for print button is creating a html file.
print_button = Button(main_windown, text = "Print ( 0 ) events to your planner",
                      activeforeground = "red", font=("Fixedsys", 28),
                      command=generate_html )
print_button.grid(row=4, column = 2, columnspan= 1, pady=20)

offline_button = Checkbutton(main_windown, text = "Offline mode", font=("Fixedsys", 20), variable= offline_var, onvalue=1, offvalue=0)
offline_button.grid(row=5, column= 2)

sql_button = Button(main_windown, text = "Save to Data Base", font=('Fixedsys', 20), command= save_data)
sql_button.grid(row=6, column= 2)


main_windown.mainloop()

# Name of the planner file. To simplify marking, your program should
# generate its entertainment planner using this file name.
planner_file = 'planner.html'

